In Order to get this working you must put vstream.inc into your "pawno/include/" directory

To use you must insert at the top of your script ---> #include <vstream>

insert under OnGameModeInit() OR if using in a filterscript OnFilterScriptInit() ---> tAxI_OnGameModeInit();

insert under OnPlayerEnterVehicle(playerid,vehicleid) ---> tAxI_OnPlayerEnterVehicle(vehicleid);

insert under OnVehicleDeath(vehicleid,reason) ---> tAxI_OnVehicleDeath(vehicleid);

insert under OnVehicleMod(vehicleid,componentid) ---> tAxI_OnVehicleMod(vehicleid,componentid);

insert under OnVehicleRespray(vehicleid,color1,color2) ---> tAxI_OnVehicleRespray(vehicleid,color1,color2);

insert under OnVehiclePaintjob(vehicleid,paintjobid) ---> tAxI_OnVehiclePaintjob(vehicleid,paintjobid);

insert under OnVehicleSpawn(vehicle) ---> tAxI_OnVehicleSpawn(vehicleid);

insert under OnPlayerExitVehicle(playerid,vehicleid) ---> tAxI_OnPlayerExitVehicle(playerid,vehicleid);

insert under OnPlayerStateChange(playerid,newstate,oldstate) ---> tAxI_OnPlayerStateChange(playerid,newstate,oldstate);

insert under OnPlayerKeyStateChange(playerid,newkeys,oldkeys) ---> tAxI_OnPlayerKeyStateChange(playerid,newkeys);



A list of availlable commands will appear on your commands list on the right hand side of your pawno window


Enjoy!!!

tAxI/Necrioss <aka> Chris Johnstone.