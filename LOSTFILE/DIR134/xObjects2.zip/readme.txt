** xObjects v2 BETA
** Simple object streamer

This object streamer has never crashed. Not even during any testing. It has been tested with over 1500 objects with a 1000ms object update timer and has worked fine. However, if you find your CPU cant handle it and you want alot of objects, increase the update timer time.

If you unloadfs this object streamer, it will destroy all objects it is in control of. So if you want to recompile it with some more objects, you can do so easily.


-- INSTALLATION --

Open up the xObjects.pwn file.
Place your objects in the object array, called "Objects".
(Instructions are located in xObjects.pwn for how to use the object array)

You can use one of the converters to help you.

Once you are done, compile the script and put it in your /filterscripts/ directory on your server.
Then, add xObjects to your filterscript line.

When your server starts, information is shown about the objects.
If no errors appear, then everything is working and all objects are loaded.


-- Changes --

Version 1.0 - Inital release
Version 1.1 - This simply changes the distance function to a simpler one which should take up less CPU (Allowing even more objects Cheesy).
Version 1.2 - SetPlayerPosWithObjects function added
Version 2.0 - Objects are now sorted into areas to minimise time taken on each player


-- Object converters --

MTA to xObjects converter: http://up.delux-host.com/1192573787/index.php5 Thanks to deLux
SA-MP to xObjects converter: http://dkimmortal.com/xobject/ Thanks to Darkimmortal


-- SetPlayerPosWithObjects --

Simple put this at the top of your script:

#define SetPlayerPos(%1,%2,%3,%4) CallRemoteFunction("SetPlayerPosWithObjects","ifff",%1,%2,%3,%4)

Now SetPlayerPos will work with xObjects


-- Help needed for testing --

If you can get 2000 objects in a server and 20 players or more, please PM me (Boylett) on SA-MP forums how it managed.
http://forum.sa-mp.com/index.php?action=profile;u=3043

Thanks

Enjoy the streamer!