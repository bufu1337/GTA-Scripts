﻿/*
 *  Image2Textdraw V1.3 beta
 *  Developed by Gamer931215
 *  © 2011
 *  
 *  You can use SMALL parts of this code for your own applications, but please
 *  place credits above the parts (in comments) and NEVER mirror or re-release this
 *  application without my permission.
 *  
 *  www.gamer93.net
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.Windows.Forms;

namespace Img2Pawn
{
    public partial class main : Form
    {
        static Button btn_convert_handler;
        static Button btn_load_handler;
        static ProgressBar pBar_handler;
        static Label lbl_processed_handler;
        static Label lbl_state_handler;
        static Label lbl_tdcount_handler;
        static TrackBar slider_x_handler;
        static TrackBar slider_y_handler;
        static ToolStripMenuItem cb_removetransparancy_handler;
        static ToolStripMenuItem settingsToolStripMenuItem_handler;
        static ToolStripMenuItem loadImageToolStripMenuItem_handler;
        static ToolStripMenuItem RenderImageToolStripMenuItem_handler;

        static string output;

        static int begin_x;
        static int begin_y;

        static Bitmap bitmap_thread_0;

        static int processed_thread_0 = 0;
        static bool finished_thread_0 = false;
        static Thread ProcessorHandler1;
        static string[][][] textdraws_thread_0;
        static Bitmap bitmap_thread_1;

        static int processed_thread_1 = 0;
        static bool finished_thread_1 = false;
        static Thread ProcessorHandler2;
        static string[][][] textdraws_thread_1;

        static int delay = 2;
        static int limit;

        static Thread UpdateStatsHandler;

        public main()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
            btn_load_handler = btn_load;
            btn_convert_handler = btn_convert;
            pBar_handler = pBar;
            lbl_processed_handler = lbl_processed;
            lbl_state_handler= lbl_state;
            lbl_tdcount_handler = lbl_tdcount;
            slider_x_handler = slider_x;
            slider_y_handler = slider_y;
            cb_removetransparancy_handler = removeTransparencyToolStripMenuItem;
            settingsToolStripMenuItem_handler = settingsToolStripMenuItem;
            loadImageToolStripMenuItem_handler = loadImageToolStripMenuItem;
            RenderImageToolStripMenuItem_handler = renderImageToolStripMenuItem;
        }

        private void loadImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (OFD.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    bitmap_thread_0 = new Bitmap(OFD.FileName);
                    bitmap_thread_1 = new Bitmap(OFD.FileName);
                    preview.Load(OFD.FileName);
                    preview.Width = bitmap_thread_0.Width / 2;
                    preview.Height = bitmap_thread_0.Height / 2;
                    limit = bitmap_thread_0.Width * bitmap_thread_0.Height;
                    lbl_state.Text = "Ready";
                    lbl_width.Text = bitmap_thread_0.Width.ToString();
                    lbl_height.Text = bitmap_thread_0.Height.ToString();
                    lbl_pixels.Text = limit.ToString();
                    pBar.Maximum = (bitmap_thread_0.Width * bitmap_thread_0.Height);
                    pBar.Value = 0;
                    btn_convert.Enabled = true;
                    preview.Visible = true;
                    renderImageToolStripMenuItem.Enabled = true;
                }
                catch
                {
                    preview.Visible = false;
                    preview.Image = null;
                    lbl_state_handler.Text = "Ready";
                    lbl_width.Text = "-";
                    lbl_height.Text = "-";
                    lbl_pixels.Text = "-";
                    lbl_processed.Text = "-";
                    lbl_tdcount.Text = "-";
                    pBar.Maximum = 100;
                    pBar.Value = 0;
                    btn_convert.Enabled = false;
                    MessageBox.Show("Oops! Something went wrong opening the picture. Please make sure you selected the right file!");
                }
            }
        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            if (OFD.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    bitmap_thread_0 = new Bitmap(OFD.FileName);
                    bitmap_thread_1 = new Bitmap(OFD.FileName);
                    preview.Load(OFD.FileName);
                    preview.Width = bitmap_thread_0.Width / 2;
                    preview.Height = bitmap_thread_0.Height / 2;
                    limit = bitmap_thread_0.Width * bitmap_thread_0.Height;
                    lbl_state.Text = "Ready";
                    lbl_width.Text = bitmap_thread_0.Width.ToString();
                    lbl_height.Text = bitmap_thread_0.Height.ToString();
                    lbl_pixels.Text = limit.ToString();
                    pBar.Maximum = (bitmap_thread_0.Width * bitmap_thread_0.Height);
                    pBar.Value = 0;
                    btn_convert.Enabled = true;
                    preview.Visible = true;
                    renderImageToolStripMenuItem.Enabled = true;
                }
                catch
                {
                    preview.Visible = false;
                    preview.Image = null;
                    lbl_state_handler.Text = "Ready";
                    lbl_width.Text = "-";
                    lbl_height.Text = "-";
                    lbl_pixels.Text = "-";
                    lbl_processed.Text = "-";
                    lbl_tdcount.Text = "-";
                    pBar.Maximum = 100;
                    pBar.Value = 0;
                    btn_convert.Enabled = false;
                    MessageBox.Show("Oops! Something went wrong opening the picture. Please make sure you selected the right file!");
                }
            }
        }

        private void renderImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.Filter = "Pawn filterscript (*.pwn)|*.pwn";
            if (SFD.ShowDialog() == DialogResult.OK)
            {
                lbl_state_handler.Text = "Preparing...";
                //resetting variables
                pBar.Value = 0;
                finished_thread_0 = false;
                ProcessorHandler1 = new Thread(new ThreadStart(Processor1));
                processed_thread_0 = 0;
                processed_thread_0 = 0;
                textdraws_thread_0 = new string[bitmap_thread_0.Width][][];
                for (int _x = 0; _x < bitmap_thread_0.Width; _x++)
                {
                    textdraws_thread_0[_x] = new string[bitmap_thread_0.Height][];
                    for (int _y = 0; _y < bitmap_thread_1.Height; _y++)
                    {
                        textdraws_thread_0[_x][_y] = new string[6];
                    }
                }

                finished_thread_1 = false;
                ProcessorHandler2 = new Thread(new ThreadStart(Processor2));
                processed_thread_1 = 0;
                processed_thread_1 = 0;
                textdraws_thread_1 = new string[bitmap_thread_1.Width][][];
                for (int _x = 0; _x < bitmap_thread_1.Width; _x++)
                {
                    textdraws_thread_1[_x] = new string[bitmap_thread_1.Height][];
                    for (int _y = 0; _y < bitmap_thread_1.Height; _y++)
                    {
                        textdraws_thread_1[_x][_y] = new string[6];
                    }
                }

                //disabling form controls
                btn_convert.Enabled = false;
                slider_x.Enabled = false;
                slider_y.Enabled = false;
                btn_load.Enabled = false;
                cb_removetransparancy_handler.Enabled = false;
                settingsToolStripMenuItem.Enabled = false;
                loadImageToolStripMenuItem_handler.Enabled = false;
                RenderImageToolStripMenuItem_handler.Enabled = false;

                lbl_state_handler.Text = "Reading and saving pixelcolors into memory...";
                //starting threads
                UpdateStatsHandler = new Thread(new ThreadStart(UpdateStats));
                output = SFD.FileName;
                ProcessorHandler1.Start();
                if (controls.multicore == true) { ProcessorHandler2.Start(); UpdateStatsHandler.Start(); }
            }
        }

        private void btn_convert_Click(object sender, EventArgs e)
        {
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.Filter = "Pawn filterscript (*.pwn)|*.pwn";
            if (SFD.ShowDialog() == DialogResult.OK)
            {
                lbl_state_handler.Text = "Preparing...";
                //resetting variables
                pBar.Value = 0;
                finished_thread_0 = false;
                ProcessorHandler1 = new Thread(new ThreadStart(Processor1));
                processed_thread_0 = 0;
                processed_thread_0 = 0;
                textdraws_thread_0 = new string[bitmap_thread_0.Width][][];
                for (int _x = 0; _x < bitmap_thread_0.Width; _x++)
                {
                    textdraws_thread_0[_x] = new string[bitmap_thread_0.Height][];
                    for (int _y = 0; _y < bitmap_thread_1.Height; _y++)
                    {
                        textdraws_thread_0[_x][_y] = new string[6];
                    }
                }

                finished_thread_1 = false;
                ProcessorHandler2 = new Thread(new ThreadStart(Processor2));
                processed_thread_1 = 0;
                processed_thread_1 = 0;
                textdraws_thread_1 = new string[bitmap_thread_1.Width][][];
                for (int _x = 0; _x < bitmap_thread_1.Width; _x++)
                {
                    textdraws_thread_1[_x] = new string[bitmap_thread_1.Height][];
                    for (int _y = 0; _y < bitmap_thread_1.Height; _y++)
                    {
                        textdraws_thread_1[_x][_y] = new string[6];
                    }
                }

                //disabling form controls
                btn_convert.Enabled = false;
                slider_x.Enabled = false;
                slider_y.Enabled = false;
                btn_load.Enabled = false;
                cb_removetransparancy_handler.Enabled = false;
                settingsToolStripMenuItem.Enabled = false;
                loadImageToolStripMenuItem_handler.Enabled = false;
                RenderImageToolStripMenuItem_handler.Enabled = false;

                lbl_state_handler.Text = "Reading and saving pixelcolors into memory...";
                //starting threads
                UpdateStatsHandler = new Thread(new ThreadStart(UpdateStats));
                output = SFD.FileName;
                ProcessorHandler1.Start();
                if (controls.multicore == true) { ProcessorHandler2.Start(); UpdateStatsHandler.Start(); }
            }
        }

        private void slider_x_Scroll(object sender, EventArgs e)
        {
            preview.Left = (354 + slider_x.Value);
            begin_x = (slider_x.Value * 2);
        }

        private void slider_y_Scroll(object sender, EventArgs e)
        {
            preview.Top = ((12 + 240)) - slider_y.Value;
            begin_y = ((((12 + 240) - slider_y.Value) * 2) - 30);
        }

        private void removeTransparancyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Img2Pawn.controls.remove_transparency == true)
            {
                Img2Pawn.controls.remove_transparency = false;
                cb_removetransparancy_handler.Checked = false;
            }
            else { Img2Pawn.controls.remove_transparency = true; cb_removetransparancy_handler.Checked = true; }
        }

       /*textdraws array (textdraws_thread_*[X][Y]):
       *  [0] = pos x
       *  [1] = pos y
       *  [2] = width
       *  [3] = height
       *  [4] = color
       *  [5] = draw (1 when not transparant)
       */

        static void Processor1()
        {
            Color c;
            if (Img2Pawn.controls.remove_transparency == true) //Transparancy detection
            {
                for (int x = 0; x < bitmap_thread_0.Width; x++)
                {
                    for (int y = 0; y < (controls.multicore == true ? bitmap_thread_0.Height / 2 : bitmap_thread_0.Height); y++)
                    {
                        processed_thread_0++;
                        c = bitmap_thread_0.GetPixel(x, y);
                        string color = ColorTranslator.ToHtml(c).ToString().Replace("#", "") + "ff";
                        if (c.A == Img2Pawn.controls.transparency_limit || c.A > Img2Pawn.controls.transparency_limit)
                        {
                            textdraws_thread_0[x][y][0] = (x + begin_x).ToString();
                            textdraws_thread_0[x][y][1] = (y + begin_y).ToString();
                            textdraws_thread_0[x][y][2] = "1";
                            textdraws_thread_0[x][y][3] = "1";
                            textdraws_thread_0[x][y][4] = "0x" + color;
                            textdraws_thread_0[x][y][5] = "1";
                        }
                        if(Img2Pawn.controls.multicore == false)
                        {
                            pBar_handler.Value = pBar_handler.Value +1;
                            lbl_processed_handler.Text = processed_thread_0.ToString();
                        }
                        System.Threading.Thread.Sleep(delay);
                    }
                }
            }
            else //No transparancy detection
            {
                for (int x = 0; x < bitmap_thread_0.Width; x++)
                {
                    for (int y = 0; y < (controls.multicore == true ? bitmap_thread_0.Height / 2 : bitmap_thread_0.Height); y++)
                    {
                        processed_thread_0++;
                        c = bitmap_thread_0.GetPixel(x, y);
                        string color = ColorTranslator.ToHtml(c).ToString().Replace("#", "") + "ff";

                        textdraws_thread_0[x][y][0] = (x + begin_x).ToString();
                        textdraws_thread_0[x][y][1] = (y + begin_y).ToString();
                        textdraws_thread_0[x][y][2] = "1";
                        textdraws_thread_0[x][y][3] = "1";
                        textdraws_thread_0[x][y][4] = "0x" + color;
                        textdraws_thread_0[x][y][5] = "1";
                        if (controls.multicore == false)
                        {
                            pBar_handler.Value = pBar_handler.Value + 1;
                            lbl_processed_handler.Text = processed_thread_0.ToString();
                        }
                        System.Threading.Thread.Sleep(delay);
                    }
                }
            }
            finished_thread_0 = true;
            if (controls.multicore == false)
            {
                lbl_state_handler.Text = "Preparing filterscript and combining textdraws...";
                int counter = 0;

                string result_thread_0 = null;
                for (int _y = 0; _y < textdraws_thread_0[1].Count(); _y++)
                {
                    for (int _x = 0; _x < textdraws_thread_0.Count(); _x++)
                    {
                        if (textdraws_thread_0[_x][_y][5] != "1") continue; //if pixel hasnt been used (is transparant) then continue

                        int width = 1;
                        //while the colors are the same on the X axe:
                        while ((_x + 1) < textdraws_thread_0.Count() && textdraws_thread_0[_x + 1][_y][4] == textdraws_thread_0[_x][_y][4])
                        {
                            width++;
                            _x++;
                            System.Threading.Thread.Sleep(delay);
                        }

                        result_thread_0 += (result_thread_0 == null ? "\t" : "\r\n\t") + "TextDrawInfo[" + counter.ToString() + "][id] = TextDrawCreate(" + textdraws_thread_0[_x][_y][0] + "," + textdraws_thread_0[_x][_y][1] + ",\".\");TextDrawTextSize(TextDrawInfo[" + counter.ToString() + "][id]," + width.ToString() + "," + textdraws_thread_0[_x][_y][3] + ");TextDrawSetShadow(TextDrawInfo[" + counter.ToString() + "][id],0);TextDrawFont(TextDrawInfo[" + counter.ToString() + "][id],2);TextDrawColor(TextDrawInfo[" + counter.ToString() + "][id]," + textdraws_thread_0[_x][_y][4] + ");TextDrawInfo[" + counter.ToString() + "][used] = 1;";
                        counter++;

                        pBar_handler.Value = counter;
                        System.Threading.Thread.Sleep(1);
                    }
                }

                //Writing the filterscript
                lbl_state_handler.Text = "Saving filterscript...";
                System.Threading.Thread.Sleep(500);
                StreamWriter writer = new StreamWriter(output);
                writer.Write("//Converted with Gamer931215's Image2TextDraw converter\r\n#include <a_samp>\r\n#define USED_DRAWS " + counter.ToString() + "\r\nenum textdraw\r\n{\r\n	Text:id,\r\n	used\r\n}\r\nnew TextDrawInfo[USED_DRAWS][textdraw];\r\npublic OnFilterScriptInit()\r\n{\r\n" + result_thread_0 + "\r\n	return 1;\r\n}\r\npublic OnPlayerConnect(playerid)\r\n{\r\n	for(new i = 0;i<USED_DRAWS;i++)\r\n	{\r\n	    if(TextDrawInfo[i][used] == 1){TextDrawShowForPlayer(playerid,TextDrawInfo[i][id]);}\r\n	}\r\n	return 1;\r\n}\r\n\r\npublic OnFilterScriptExit()\r\n{\r\n	for(new i = 0;i<USED_DRAWS;i++)\r\n	{\r\n	    if(TextDrawInfo[i][used] == 1){TextDrawDestroy(TextDrawInfo[i][id]);}\r\n	}\r\n	return 1;\r\n}");
                writer.Close();

                lbl_tdcount_handler.Text = counter.ToString();
                if (counter > 2048)
                {
                    MessageBox.Show("Warning! Your image is too large (" + counter + "/2048 textdraws). Now every textdraw will appear! Your file has been saved to " + output);
                }
                else MessageBox.Show("Image succesfully converted and saved to " + output);

                //Resetting and Re-enabling form controls
                pBar_handler.Value = 0;
                lbl_state_handler.Text = "Ready";
                btn_convert_handler.Enabled = true;
                btn_load_handler.Enabled = true;
                slider_x_handler.Enabled = true;
                slider_y_handler.Enabled = true;
                settingsToolStripMenuItem_handler.Enabled = true;
                cb_removetransparancy_handler.Enabled = true;
                loadImageToolStripMenuItem_handler.Enabled = true;
                RenderImageToolStripMenuItem_handler.Enabled = true;

                //Stopping threads
                ProcessorHandler1.Abort();
            }
        }

        static void Processor2()
        {
            Color c;
            if (Img2Pawn.controls.remove_transparency == true) //Transparancy detection
            {
                for (int x = 0; x < bitmap_thread_1.Width; x++)
                {
                    for (int y = (bitmap_thread_1.Height / 2); y < bitmap_thread_1.Height; y++)
                    {
                        processed_thread_1++;
                        c = bitmap_thread_1.GetPixel(x, y);
                        string color = ColorTranslator.ToHtml(c).ToString().Replace("#", "") + "ff";
                        if (c.A == Img2Pawn.controls.transparency_limit || c.A > Img2Pawn.controls.transparency_limit)
                        {
                            textdraws_thread_1[x][y][0] = (x + begin_x).ToString();
                            textdraws_thread_1[x][y][1] = (y + begin_y).ToString();
                            textdraws_thread_1[x][y][2] = "1";
                            textdraws_thread_1[x][y][3] = "1";
                            textdraws_thread_1[x][y][4] = "0x" + color;
                            textdraws_thread_1[x][y][5] = "1";
                        }
                        System.Threading.Thread.Sleep(delay +1);
                    }
                }
                finished_thread_1 = true;
            }
            else //No transparancy detection
            {
                for (int x = 0; x < bitmap_thread_1.Width; x++)
                {
                    for (int y = (bitmap_thread_1.Height / 2); y < bitmap_thread_1.Height; y++)
                    {
                        processed_thread_1++;
                        c = bitmap_thread_1.GetPixel(x, y);
                        string color = ColorTranslator.ToHtml(c).ToString().Replace("#", "") + "ff";

                        textdraws_thread_1[x][y][0] = (x + begin_x).ToString();
                        textdraws_thread_1[x][y][1] = (y + begin_y).ToString();
                        textdraws_thread_1[x][y][2] = "1";
                        textdraws_thread_1[x][y][3] = "1";
                        textdraws_thread_1[x][y][4] = "0x" + color;
                        textdraws_thread_1[x][y][5] = "1";

                        System.Threading.Thread.Sleep(delay +1);
                    }
                }
                finished_thread_1 = true;
            }
        }

        /*textdraws array (textdraws_thread_*[X][Y]):
        *  [0] = pos x
        *  [1] = pos y
        *  [2] = width
        *  [3] = height
        *  [4] = color
        *  [5] = draw (1 when not transparant)
        */
        static void UpdateStats()
        {
            while (true)
            {
                int current = (processed_thread_0 + processed_thread_1);
                if (controls.multicore == true && finished_thread_0 == true && finished_thread_1 == true || controls.multicore == false && finished_thread_0 == true)
                {
                    pBar_handler.Value = 0;
                    lbl_processed_handler.Text = current.ToString();
                    int counter = 0;
                    lbl_state_handler.Text = "Preparing filterscript and combining textdraws...";

                    string result_thread_0 = null; 
                    for (int _y = 0; _y < textdraws_thread_0[1].Count(); _y++)
                    {
                        for (int _x = 0; _x < textdraws_thread_0.Count(); _x++)
                        {
                            if (textdraws_thread_0[_x][_y][5] != "1") continue; //if pixel hasnt been used (is transparant) then continue

                            int width = 1;
                            //while the colors are the same on the X axe:
                            while ((_x + 1) < textdraws_thread_0.Count() && textdraws_thread_0[_x + 1][_y][4] == textdraws_thread_0[_x][_y][4])
                            {
                                width++;
                                _x++;
                                System.Threading.Thread.Sleep(delay);
                            }

                            result_thread_0 += (result_thread_0 == null ? "\t" : "\r\n\t") + "TextDrawInfo[" + counter.ToString() + "][id] = TextDrawCreate(" + textdraws_thread_0[_x][_y][0] + "," + textdraws_thread_0[_x][_y][1] + ",\".\");TextDrawTextSize(TextDrawInfo[" + counter.ToString() + "][id]," + width.ToString() + "," + textdraws_thread_0[_x][_y][3] + ");TextDrawSetShadow(TextDrawInfo[" + counter.ToString() + "][id],0);TextDrawFont(TextDrawInfo[" + counter.ToString() + "][id],2);TextDrawColor(TextDrawInfo[" + counter.ToString() + "][id]," + textdraws_thread_0[_x][_y][4] + ");TextDrawInfo[" + counter.ToString() + "][used] = 1;";
                            counter++;

                            pBar_handler.Value = (pBar_handler.Value + 1);
                            System.Threading.Thread.Sleep(1);
                        }
                    }

                    string result_thread_1 = null;
                    for (int _y = 0; _y < textdraws_thread_1[1].Count(); _y++)
                    {
                        for (int _x = 0; _x < textdraws_thread_1.Count(); _x++)
                        {
                            if (textdraws_thread_1[_x][_y][5] != "1") continue; //if pixel hasnt been used (is transparant) then continue
                            if (textdraws_thread_1[_x][_y][1] == null) continue; //bug fix

                            int width = 1;
                            //while the colors are the same on the X axe:
                            while ((_x + 1) < textdraws_thread_1.Count() && textdraws_thread_1[_x + 1][_y][4] == textdraws_thread_1[_x][_y][4])
                            {
                                width++;
                                _x++;
                                System.Threading.Thread.Sleep(delay);
                            }

                            result_thread_1 += (result_thread_1 == null ? "\t" : "\r\n\t") + "TextDrawInfo[" + counter.ToString() + "][id] = TextDrawCreate(" + textdraws_thread_1[_x][_y][0] + "," + textdraws_thread_1[_x][_y][1] + ",\".\");TextDrawTextSize(TextDrawInfo[" + counter.ToString() + "][id]," + width.ToString() + "," + textdraws_thread_1[_x][_y][3] + ");TextDrawSetShadow(TextDrawInfo[" + counter.ToString() + "][id],0);TextDrawFont(TextDrawInfo[" + counter.ToString() + "][id],2);TextDrawColor(TextDrawInfo[" + counter.ToString() + "][id]," + textdraws_thread_1[_x][_y][4] + ");TextDrawInfo[" + counter.ToString() + "][used] = 1;";
                            counter++;

                            pBar_handler.Value = (pBar_handler.Value + 1);
                            System.Threading.Thread.Sleep(1);
                        }
                    }

                    //Writing the filterscript
                    lbl_state_handler.Text = "Saving filterscript...";
                    System.Threading.Thread.Sleep(500);
                    StreamWriter writer = new StreamWriter(output);
                    writer.Write("//Converted with Gamer931215's Image2TextDraw converter\r\n#include <a_samp>\r\n#define USED_DRAWS " + counter.ToString() + "\r\nenum textdraw\r\n{\r\n	Text:id,\r\n	used\r\n}\r\nnew TextDrawInfo[USED_DRAWS][textdraw];\r\npublic OnFilterScriptInit()\r\n{\r\n" + result_thread_0 + "\r\n" + result_thread_1 + "\r\n	return 1;\r\n}\r\npublic OnPlayerConnect(playerid)\r\n{\r\n	for(new i = 0;i<USED_DRAWS;i++)\r\n	{\r\n	    if(TextDrawInfo[i][used] == 1){TextDrawShowForPlayer(playerid,TextDrawInfo[i][id]);}\r\n	}\r\n	return 1;\r\n}\r\n\r\npublic OnFilterScriptExit()\r\n{\r\n	for(new i = 0;i<USED_DRAWS;i++)\r\n	{\r\n	    if(TextDrawInfo[i][used] == 1){TextDrawDestroy(TextDrawInfo[i][id]);}\r\n	}\r\n	return 1;\r\n}");
                    writer.Close();

                    lbl_tdcount_handler.Text = counter.ToString();
                    if (counter > 2048)
                    {
                        MessageBox.Show("Warning! Your image is too large (" + counter + "/2048 textdraws). Now every textdraw will appear! Your file has been saved to " + output);
                    }
                    else MessageBox.Show("Image succesfully converted and saved to " + output);

                    //Resetting and Re-enabling form controls
                    pBar_handler.Value = 0;
                    lbl_state_handler.Text = "Ready";
                    btn_convert_handler.Enabled = true;
                    btn_load_handler.Enabled = true;
                    slider_x_handler.Enabled = true;
                    slider_y_handler.Enabled = true;
                    settingsToolStripMenuItem_handler.Enabled = true;
                    cb_removetransparancy_handler.Enabled = true;
                    loadImageToolStripMenuItem_handler.Enabled = true;
                    RenderImageToolStripMenuItem_handler.Enabled = true;

                    //Stopping threads
                    ProcessorHandler1.Abort();
                    ProcessorHandler2.Abort();
                    UpdateStatsHandler.Abort();
                }
                else
                {
                    pBar_handler.Value = current;
                    lbl_processed_handler.Text = current.ToString();
                }
                System.Threading.Thread.Sleep(1);
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try{ProcessorHandler1.Abort();}catch { }
            try{ProcessorHandler2.Abort();} catch { }
            try { UpdateStatsHandler.Abort(); }catch { }
            Application.Exit();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try { ProcessorHandler1.Abort(); }
            catch { }
            try { ProcessorHandler2.Abort(); }
            catch { }
            try { UpdateStatsHandler.Abort(); }
            catch { }
            Application.Exit();
        }

        private void applicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //update status
            if (Img2Pawn.controls.remove_transparency == true)
            {
                removeTransparencyToolStripMenuItem.Checked = true;
            }
            else removeTransparencyToolStripMenuItem.Checked = false;
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //update status
            if (Img2Pawn.controls.remove_transparency == true)
            {
                removeTransparencyToolStripMenuItem.Checked = true;
            }
            else removeTransparencyToolStripMenuItem.Checked = false;
        }

        private void editTransparencyKeyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            edit_transparency_settings edit_transparency_key = new edit_transparency_settings();
            edit_transparency_key.Show();
        }

        private void lowFastRenderingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lowFastRenderingToolStripMenuItem.Checked = true;
            normalDefaultToolStripMenuItem.Checked = false;
            highSlowerToolStripMenuItem.Checked = false;
            delay = 2;
        }

        private void normalDefaultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lowFastRenderingToolStripMenuItem.Checked = false;
            normalDefaultToolStripMenuItem.Checked = true;
            highSlowerToolStripMenuItem.Checked = false;
            delay = 11;
        }

        private void highSlowerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lowFastRenderingToolStripMenuItem.Checked = false;
            normalDefaultToolStripMenuItem.Checked = false;
            highSlowerToolStripMenuItem.Checked = true;
            delay = 25;
        }

        private void donateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("iexplore.exe"," http://www.gamer93.net/donate.html");
        }

        private void onToolStripMenuItem_Click(object sender, EventArgs e)
        {
            onToolStripMenuItem.Checked = true;
            offToolStripMenuItem.Checked = false;
            controls.multicore = true;
        }

        private void offToolStripMenuItem_Click(object sender, EventArgs e)
        {
            onToolStripMenuItem.Checked = false;
            offToolStripMenuItem.Checked = true;
            controls.multicore = false;
        }

        private void preview_size_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to change the preview image?", "Changing preview image", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                OpenFileDialog OFD = new OpenFileDialog();
                if (OFD.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        preview_size.Load(OFD.FileName);
                    }
                    catch
                    {
                        MessageBox.Show("Error! The image you have selected is not valid!");
                    }
                }
            }
        }

        private void howToAvoidemptyPixelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            avoid_broken_pixel_s avoid = new avoid_broken_pixel_s();
            avoid.Show();
        }

        private void howToUseImg2TextdrawToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Step 1: Click on \"Load Image\" and select the image you want ingame.\r\nStep 2: Use the slidebars to select the position where you want to draw it.\r\nStep 3: Click render and select the path and name where you want to save the filterscript.\r\nStep 4: Wait until the program is finished and then open the generated filterscript with Pawno and compile it!");
        }
    }
}
