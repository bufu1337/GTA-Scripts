﻿namespace Img2Pawn
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_width = new System.Windows.Forms.Label();
            this.lbl_height = new System.Windows.Forms.Label();
            this.lbl_pixels = new System.Windows.Forms.Label();
            this.btn_load = new System.Windows.Forms.Button();
            this.OFD = new System.Windows.Forms.OpenFileDialog();
            this.pBar = new System.Windows.Forms.ProgressBar();
            this.btn_convert = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_processed = new System.Windows.Forms.Label();
            this.slider_x = new System.Windows.Forms.TrackBar();
            this.slider_y = new System.Windows.Forms.TrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_state = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.applicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accuracyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lowFastRenderingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalDefaultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highSlowerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transparencyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeTransparencyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edittransparencysettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.donateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_tdcount = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.multithreadingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.onToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.offToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.howToAvoidemptyPixelsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.howToUseImg2TextdrawToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.preview = new System.Windows.Forms.PictureBox();
            this.preview_size = new System.Windows.Forms.PictureBox();
            this.loadImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renderImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.slider_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slider_y)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.preview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.preview_size)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Width:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Height:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Pixels:";
            // 
            // lbl_width
            // 
            this.lbl_width.AutoSize = true;
            this.lbl_width.Location = new System.Drawing.Point(74, 67);
            this.lbl_width.Name = "lbl_width";
            this.lbl_width.Size = new System.Drawing.Size(10, 13);
            this.lbl_width.TabIndex = 4;
            this.lbl_width.Text = "-";
            // 
            // lbl_height
            // 
            this.lbl_height.AutoSize = true;
            this.lbl_height.Location = new System.Drawing.Point(74, 90);
            this.lbl_height.Name = "lbl_height";
            this.lbl_height.Size = new System.Drawing.Size(10, 13);
            this.lbl_height.TabIndex = 5;
            this.lbl_height.Text = "-";
            // 
            // lbl_pixels
            // 
            this.lbl_pixels.AutoSize = true;
            this.lbl_pixels.Location = new System.Drawing.Point(74, 113);
            this.lbl_pixels.Name = "lbl_pixels";
            this.lbl_pixels.Size = new System.Drawing.Size(10, 13);
            this.lbl_pixels.TabIndex = 6;
            this.lbl_pixels.Text = "-";
            // 
            // btn_load
            // 
            this.btn_load.Location = new System.Drawing.Point(12, 200);
            this.btn_load.Name = "btn_load";
            this.btn_load.Size = new System.Drawing.Size(88, 23);
            this.btn_load.TabIndex = 7;
            this.btn_load.Text = "Load image";
            this.btn_load.UseVisualStyleBackColor = true;
            this.btn_load.Click += new System.EventHandler(this.btn_load_Click);
            // 
            // OFD
            // 
            this.OFD.Filter = "Image files (*.*) | *.*";
            // 
            // pBar
            // 
            this.pBar.Location = new System.Drawing.Point(12, 229);
            this.pBar.Name = "pBar";
            this.pBar.Size = new System.Drawing.Size(293, 23);
            this.pBar.TabIndex = 8;
            // 
            // btn_convert
            // 
            this.btn_convert.Enabled = false;
            this.btn_convert.Location = new System.Drawing.Point(217, 200);
            this.btn_convert.Name = "btn_convert";
            this.btn_convert.Size = new System.Drawing.Size(88, 23);
            this.btn_convert.TabIndex = 9;
            this.btn_convert.Text = "Render image";
            this.btn_convert.UseVisualStyleBackColor = true;
            this.btn_convert.Click += new System.EventHandler(this.btn_convert_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Processed:";
            // 
            // lbl_processed
            // 
            this.lbl_processed.AutoSize = true;
            this.lbl_processed.Location = new System.Drawing.Point(74, 136);
            this.lbl_processed.Name = "lbl_processed";
            this.lbl_processed.Size = new System.Drawing.Size(10, 13);
            this.lbl_processed.TabIndex = 11;
            this.lbl_processed.Text = "-";
            // 
            // slider_x
            // 
            this.slider_x.AutoSize = false;
            this.slider_x.Location = new System.Drawing.Point(354, 258);
            this.slider_x.Maximum = 320;
            this.slider_x.Name = "slider_x";
            this.slider_x.Size = new System.Drawing.Size(320, 45);
            this.slider_x.TabIndex = 14;
            this.slider_x.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.slider_x.Scroll += new System.EventHandler(this.slider_x_Scroll);
            // 
            // slider_y
            // 
            this.slider_y.AutoSize = false;
            this.slider_y.Location = new System.Drawing.Point(324, 12);
            this.slider_y.Maximum = 240;
            this.slider_y.Name = "slider_y";
            this.slider_y.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.slider_y.Size = new System.Drawing.Size(45, 240);
            this.slider_y.TabIndex = 15;
            this.slider_y.Value = 240;
            this.slider_y.Scroll += new System.EventHandler(this.slider_y_Scroll);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 277);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(212, 26);
            this.label6.TabIndex = 19;
            this.label6.Text = "Please donate if you want futher updates ;)!\r\n© Gamer931215 - 2011";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "State:";
            // 
            // lbl_state
            // 
            this.lbl_state.AutoSize = true;
            this.lbl_state.Location = new System.Drawing.Point(74, 45);
            this.lbl_state.Name = "lbl_state";
            this.lbl_state.Size = new System.Drawing.Size(38, 13);
            this.lbl_state.TabIndex = 23;
            this.lbl_state.Text = "Ready";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.applicationToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.donateToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(677, 24);
            this.menuStrip1.TabIndex = 24;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // applicationToolStripMenuItem
            // 
            this.applicationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadImageToolStripMenuItem,
            this.renderImageToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.applicationToolStripMenuItem.Name = "applicationToolStripMenuItem";
            this.applicationToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.applicationToolStripMenuItem.Text = "File";
            this.applicationToolStripMenuItem.Click += new System.EventHandler(this.applicationToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accuracyToolStripMenuItem,
            this.transparencyToolStripMenuItem,
            this.multithreadingToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "Settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // accuracyToolStripMenuItem
            // 
            this.accuracyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lowFastRenderingToolStripMenuItem,
            this.normalDefaultToolStripMenuItem,
            this.highSlowerToolStripMenuItem});
            this.accuracyToolStripMenuItem.Name = "accuracyToolStripMenuItem";
            this.accuracyToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.accuracyToolStripMenuItem.Text = "Delay (to avoid freezes)";
            // 
            // lowFastRenderingToolStripMenuItem
            // 
            this.lowFastRenderingToolStripMenuItem.Checked = true;
            this.lowFastRenderingToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.lowFastRenderingToolStripMenuItem.Name = "lowFastRenderingToolStripMenuItem";
            this.lowFastRenderingToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.lowFastRenderingToolStripMenuItem.Text = "Low (Fast rendering)";
            this.lowFastRenderingToolStripMenuItem.Click += new System.EventHandler(this.lowFastRenderingToolStripMenuItem_Click);
            // 
            // normalDefaultToolStripMenuItem
            // 
            this.normalDefaultToolStripMenuItem.Name = "normalDefaultToolStripMenuItem";
            this.normalDefaultToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.normalDefaultToolStripMenuItem.Text = "Normal (Default)";
            this.normalDefaultToolStripMenuItem.Click += new System.EventHandler(this.normalDefaultToolStripMenuItem_Click);
            // 
            // highSlowerToolStripMenuItem
            // 
            this.highSlowerToolStripMenuItem.Name = "highSlowerToolStripMenuItem";
            this.highSlowerToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.highSlowerToolStripMenuItem.Text = "High (Slower)";
            this.highSlowerToolStripMenuItem.Click += new System.EventHandler(this.highSlowerToolStripMenuItem_Click);
            // 
            // transparencyToolStripMenuItem
            // 
            this.transparencyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.removeTransparencyToolStripMenuItem,
            this.edittransparencysettingsToolStripMenuItem});
            this.transparencyToolStripMenuItem.Name = "transparencyToolStripMenuItem";
            this.transparencyToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.transparencyToolStripMenuItem.Text = "Transparency";
            // 
            // removeTransparencyToolStripMenuItem
            // 
            this.removeTransparencyToolStripMenuItem.Checked = true;
            this.removeTransparencyToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.removeTransparencyToolStripMenuItem.Name = "removeTransparencyToolStripMenuItem";
            this.removeTransparencyToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.removeTransparencyToolStripMenuItem.Text = "Remove Transparency";
            this.removeTransparencyToolStripMenuItem.Click += new System.EventHandler(this.removeTransparancyToolStripMenuItem_Click);
            // 
            // edittransparencysettingsToolStripMenuItem
            // 
            this.edittransparencysettingsToolStripMenuItem.Name = "edittransparencysettingsToolStripMenuItem";
            this.edittransparencysettingsToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.edittransparencysettingsToolStripMenuItem.Text = "Edit Transparency settings";
            this.edittransparencysettingsToolStripMenuItem.Click += new System.EventHandler(this.editTransparencyKeyToolStripMenuItem_Click);
            // 
            // donateToolStripMenuItem
            // 
            this.donateToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.donateToolStripMenuItem.Name = "donateToolStripMenuItem";
            this.donateToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.donateToolStripMenuItem.Text = "Donate!";
            this.donateToolStripMenuItem.ToolTipText = "Go to gamer93.net/donate.html";
            this.donateToolStripMenuItem.Click += new System.EventHandler(this.donateToolStripMenuItem_Click);
            // 
            // lbl_tdcount
            // 
            this.lbl_tdcount.AutoSize = true;
            this.lbl_tdcount.Location = new System.Drawing.Point(74, 158);
            this.lbl_tdcount.Name = "lbl_tdcount";
            this.lbl_tdcount.Size = new System.Drawing.Size(10, 13);
            this.lbl_tdcount.TabIndex = 26;
            this.lbl_tdcount.Text = "-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Textdraws:";
            // 
            // multithreadingToolStripMenuItem
            // 
            this.multithreadingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.onToolStripMenuItem,
            this.offToolStripMenuItem});
            this.multithreadingToolStripMenuItem.Name = "multithreadingToolStripMenuItem";
            this.multithreadingToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.multithreadingToolStripMenuItem.Text = "Multithreading";
            // 
            // onToolStripMenuItem
            // 
            this.onToolStripMenuItem.Checked = true;
            this.onToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.onToolStripMenuItem.Name = "onToolStripMenuItem";
            this.onToolStripMenuItem.Size = new System.Drawing.Size(91, 22);
            this.onToolStripMenuItem.Text = "On";
            this.onToolStripMenuItem.Click += new System.EventHandler(this.onToolStripMenuItem_Click);
            // 
            // offToolStripMenuItem
            // 
            this.offToolStripMenuItem.Name = "offToolStripMenuItem";
            this.offToolStripMenuItem.Size = new System.Drawing.Size(91, 22);
            this.offToolStripMenuItem.Text = "Off";
            this.offToolStripMenuItem.Click += new System.EventHandler(this.offToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.howToAvoidemptyPixelsToolStripMenuItem,
            this.howToUseImg2TextdrawToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // howToAvoidemptyPixelsToolStripMenuItem
            // 
            this.howToAvoidemptyPixelsToolStripMenuItem.Name = "howToAvoidemptyPixelsToolStripMenuItem";
            this.howToAvoidemptyPixelsToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.howToAvoidemptyPixelsToolStripMenuItem.Text = "How to avoid \"empty\" pixels";
            this.howToAvoidemptyPixelsToolStripMenuItem.Click += new System.EventHandler(this.howToAvoidemptyPixelsToolStripMenuItem_Click);
            // 
            // howToUseImg2TextdrawToolStripMenuItem
            // 
            this.howToUseImg2TextdrawToolStripMenuItem.Name = "howToUseImg2TextdrawToolStripMenuItem";
            this.howToUseImg2TextdrawToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.howToUseImg2TextdrawToolStripMenuItem.Text = "How to use Img2Textdraw";
            this.howToUseImg2TextdrawToolStripMenuItem.Click += new System.EventHandler(this.howToUseImg2TextdrawToolStripMenuItem_Click);
            // 
            // preview
            // 
            this.preview.BackColor = System.Drawing.Color.Black;
            this.preview.Location = new System.Drawing.Point(354, 12);
            this.preview.MaximumSize = new System.Drawing.Size(160, 123);
            this.preview.Name = "preview";
            this.preview.Size = new System.Drawing.Size(38, 32);
            this.preview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.preview.TabIndex = 0;
            this.preview.TabStop = false;
            this.preview.Visible = false;
            // 
            // preview_size
            // 
            this.preview_size.Image = global::Img2Pawn.Properties.Resources.img;
            this.preview_size.Location = new System.Drawing.Point(354, 12);
            this.preview_size.Name = "preview_size";
            this.preview_size.Size = new System.Drawing.Size(320, 240);
            this.preview_size.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.preview_size.TabIndex = 16;
            this.preview_size.TabStop = false;
            this.preview_size.Click += new System.EventHandler(this.preview_size_Click);
            // 
            // loadImageToolStripMenuItem
            // 
            this.loadImageToolStripMenuItem.Name = "loadImageToolStripMenuItem";
            this.loadImageToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.loadImageToolStripMenuItem.Text = "Load image";
            this.loadImageToolStripMenuItem.Click += new System.EventHandler(this.loadImageToolStripMenuItem_Click);
            // 
            // renderImageToolStripMenuItem
            // 
            this.renderImageToolStripMenuItem.Enabled = false;
            this.renderImageToolStripMenuItem.Name = "renderImageToolStripMenuItem";
            this.renderImageToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.renderImageToolStripMenuItem.Text = "Render image";
            this.renderImageToolStripMenuItem.Click += new System.EventHandler(this.renderImageToolStripMenuItem_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 307);
            this.Controls.Add(this.lbl_tdcount);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lbl_state);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.preview);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.preview_size);
            this.Controls.Add(this.slider_y);
            this.Controls.Add(this.slider_x);
            this.Controls.Add(this.lbl_processed);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn_convert);
            this.Controls.Add(this.pBar);
            this.Controls.Add(this.btn_load);
            this.Controls.Add(this.lbl_pixels);
            this.Controls.Add(this.lbl_height);
            this.Controls.Add(this.lbl_width);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Img2TextDraw";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.slider_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slider_y)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.preview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.preview_size)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox preview;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_width;
        private System.Windows.Forms.Label lbl_height;
        private System.Windows.Forms.Label lbl_pixels;
        private System.Windows.Forms.Button btn_load;
        private System.Windows.Forms.OpenFileDialog OFD;
        private System.Windows.Forms.ProgressBar pBar;
        private System.Windows.Forms.Button btn_convert;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_processed;
        private System.Windows.Forms.TrackBar slider_x;
        private System.Windows.Forms.TrackBar slider_y;
        private System.Windows.Forms.PictureBox preview_size;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_state;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem applicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transparencyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeTransparencyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem edittransparencysettingsToolStripMenuItem;
        private System.Windows.Forms.Label lbl_tdcount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ToolStripMenuItem accuracyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lowFastRenderingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalDefaultToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highSlowerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem donateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multithreadingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem onToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem offToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem howToAvoidemptyPixelsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem howToUseImg2TextdrawToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadImageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renderImageToolStripMenuItem;
    }
}

