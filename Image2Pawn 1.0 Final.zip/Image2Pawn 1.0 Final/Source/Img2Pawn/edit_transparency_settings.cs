﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Img2Pawn
{
    public partial class edit_transparency_settings : Form
    {

        public edit_transparency_settings()
        {
            InitializeComponent();
        }

        private void edit_transparency_settings_Load(object sender, EventArgs e)
        {
            lbl_limit.Text = Img2Pawn.controls.transparency_limit.ToString();
            if (Img2Pawn.controls.remove_transparency == true)
            {
                cb_removetransparency.Checked = true;
                slider_alpha.Enabled = true;
                slider_alpha.Value = Img2Pawn.controls.transparency_limit;
            }
            else
            {
                cb_removetransparency.Checked = false;
                slider_alpha.Enabled = false;
                slider_alpha.Value = Img2Pawn.controls.transparency_limit;
            }
        }

        private void slider_alpha_Scroll(object sender, EventArgs e)
        {
            Img2Pawn.controls.transparency_limit = slider_alpha.Value;
            lbl_limit.Text = slider_alpha.Value.ToString();
        }

        private void cb_removetransparency_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_removetransparency.Checked == true)
            {
                slider_alpha.Enabled = true;
                slider_alpha.Value = Img2Pawn.controls.transparency_limit;
                Img2Pawn.controls.remove_transparency = true;
            }
            else
            {
                slider_alpha.Enabled = false;
                Img2Pawn.controls.remove_transparency = false;
            }
        }
    }
}
