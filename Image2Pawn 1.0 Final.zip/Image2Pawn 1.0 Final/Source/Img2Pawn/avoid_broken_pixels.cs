﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Img2Pawn
{
    public partial class avoid_broken_pixel_s : Form
    {
        public avoid_broken_pixel_s()
        {
            InitializeComponent();
        }
    }
}
