﻿namespace Img2Pawn
{
    partial class edit_transparency_settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.group_basic = new System.Windows.Forms.GroupBox();
            this.cb_removetransparency = new System.Windows.Forms.CheckBox();
            this.lbl_limit = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.slider_alpha = new System.Windows.Forms.TrackBar();
            this.group_basic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slider_alpha)).BeginInit();
            this.SuspendLayout();
            // 
            // group_basic
            // 
            this.group_basic.Controls.Add(this.cb_removetransparency);
            this.group_basic.Controls.Add(this.lbl_limit);
            this.group_basic.Controls.Add(this.label1);
            this.group_basic.Controls.Add(this.slider_alpha);
            this.group_basic.Location = new System.Drawing.Point(3, 12);
            this.group_basic.Name = "group_basic";
            this.group_basic.Size = new System.Drawing.Size(273, 126);
            this.group_basic.TabIndex = 1;
            this.group_basic.TabStop = false;
            this.group_basic.Text = "Transparency settings";
            // 
            // cb_removetransparency
            // 
            this.cb_removetransparency.AutoSize = true;
            this.cb_removetransparency.Location = new System.Drawing.Point(12, 100);
            this.cb_removetransparency.Name = "cb_removetransparency";
            this.cb_removetransparency.Size = new System.Drawing.Size(134, 17);
            this.cb_removetransparency.TabIndex = 3;
            this.cb_removetransparency.Text = "Remove Transparency";
            this.cb_removetransparency.UseVisualStyleBackColor = true;
            this.cb_removetransparency.CheckedChanged += new System.EventHandler(this.cb_removetransparency_CheckedChanged);
            // 
            // lbl_limit
            // 
            this.lbl_limit.AutoSize = true;
            this.lbl_limit.Location = new System.Drawing.Point(228, 32);
            this.lbl_limit.Name = "lbl_limit";
            this.lbl_limit.Size = new System.Drawing.Size(10, 13);
            this.lbl_limit.TabIndex = 2;
            this.lbl_limit.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Remove from alpha key:";
            // 
            // slider_alpha
            // 
            this.slider_alpha.Location = new System.Drawing.Point(6, 48);
            this.slider_alpha.Maximum = 255;
            this.slider_alpha.Name = "slider_alpha";
            this.slider_alpha.Size = new System.Drawing.Size(258, 45);
            this.slider_alpha.TabIndex = 0;
            this.slider_alpha.Scroll += new System.EventHandler(this.slider_alpha_Scroll);
            // 
            // edit_transparency_settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(283, 146);
            this.Controls.Add(this.group_basic);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "edit_transparency_settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit transparency key";
            this.Load += new System.EventHandler(this.edit_transparency_settings_Load);
            this.group_basic.ResumeLayout(false);
            this.group_basic.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slider_alpha)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox group_basic;
        private System.Windows.Forms.Label lbl_limit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar slider_alpha;
        private System.Windows.Forms.CheckBox cb_removetransparency;


    }
}