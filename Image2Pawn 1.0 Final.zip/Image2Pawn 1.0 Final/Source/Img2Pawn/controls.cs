﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Img2Pawn
{
    public static class controls
    {
        public static int transparency_limit = 100;
        public static bool remove_transparency = true;
        public static bool multicore = true;
    }
}
