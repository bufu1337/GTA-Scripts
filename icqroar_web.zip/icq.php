<?php
/**
 * Klasse zur Kommunikation mit Messaging-Servern �ber das ICQ-Protokoll.
 * @author Filip Dal�ge <filip-www@daluege.de>
 * @copyright Filip Dal�ge, ver�ffentlicht unter der GPL.
 * @package default
 */

require_once('default.php');
require_once('conversion.php');

define('ICQ_DEFAULT_TIMEOUT',ini_get('default_socket_timeout')?intval(ini_get('default_socket_timeout')):60);

define('ICQ_STATUS_OFFLINE',0xffff);
define('ICQ_STATUS_ONLINE',0x0);
define('ICQ_STATUS_AWAY',0x1);
define('ICQ_STATUS_DND',0x2);
define('ICQ_STATUS_NA',0x4);
define('ICQ_STATUS_OCCUPIED',0x11);
define('ICQ_STATUS_FFC',0x20);
define('ICQ_STATUS_INVISIBLE',0x100);

define('ICQ_DC_DISABLED',0x0);
define('ICQ_DC_HTTPS',0x1);
define('ICQ_DC_SOCKS',0x2);
define('ICQ_DC_NORMAL',0x4);
define('ICQ_DC_WEB',0x6);

define('ICQ_HELLO',1);
define('ICQ_FLAP',2);
define('ICQ_TLV',3);
define('ICQ_DISCONNECT',4);
define('ICQ_SNAC',6);

define('ICQ_SRV_RECVMSG',5);

define('ICQ_RECV_OK',1);
define('ICQ_RECV_RECONNECT',2);

class icq_unknown{
}
class icq_particle{
	var $data;
	var $obj;
}
class icq_hello extends icq_particle{
	var $hello=1;
	var $cookie;
	var $uin;
	var $password;
	var $version;
	var $clientid;
	var $ver_major;
	var $ver_minor;
	var $ver_lesser;
	var $ver_build;
	var $ver_distrib;
	var $language;
	var $country;
}
class icq_flap extends icq_particle{
	var $id=0x2a;
	var $channel;
	var $sequence;
	var $length;
}
class icq_tlv extends icq_particle{
	var $type;
	var $length;
}
class icq_disconnect extends icq_particle{
	var $uin;
	var $url;
	var $server;
	var $cookie;
	var $error;
	var $description;
}
class icq_snac extends icq_particle{
	var $family;
	var $command;
	var $flags;
	var $reference;
}
class icq_srv_newuin{
	var $cookie;
	var $uin;
	var $ip;
	var $port;
}
class icq_srv_useronline{
	var $uin;
	var $ip;
	var $status;
	var $membersince;
	var $onlinesince;
}
class icq_srv_useroffline{
	var $uin;
}
class icq_srv_fromicqsrv extends icq_particle{
	var $length;
	var $uin;
	var $type;
	var $sequence;
	var $command;
}
class icq_srv_meta{
	var $success;
}
class icq_srv_metageneral extends icq_srv_meta{
	var $nick;
	var $first;
	var $last;
	var $email;
	var $city;
	var $state;
	var $phone;
	var $fax;
	var $street;
	var $cellular;
	var $zip;
	var $country;
	var $tz;
	var $flags;
	var $web;
}
class icq_srv_metawork extends icq_srv_meta{
	var $city;
	var $state;
	var $phone;
	var $fax;
	var $address;
	var $zip;
	var $country;
	var $company;
	var $department;
	var $position;
	var $occupation;
	var $homepage;
}
class icq_srv_metamore extends icq_srv_meta{
	var $age;
	var $gender;
	var $homepage;
	var $year;
	var $month;
	var $day;
	var $lang1;
	var $lang2;
	var $lang3;
	var $city;
	var $country;
	var $marital;
}
class icq_srv_metafound extends icq_srv_meta{
	var $datalen;
	var $uin;
	var $nick;
	var $first;
	var $last;
	var $email;
	var $flags;
	var $status;
	var $gender;
	var $age;
	var $missed;
}
class icq_srv_recvmsg{
	var $time;
	var $id;
	var $type;
	var $uin;
	var $warning;
	var $count;
	var $status;
	var $message;
	var $messagetext;
}
class icq_sub_msg_type1{
	var $capabilities;
	var $encoding;
	var $message;
}
class icq_sub_msg_type4{
	var $uin;
	var $msgtype;
	var $message;
	var $obj;
}
class icq_sub_url{
	var $description;
	var $url;
}
class icq_cli_searchbypersinf{
	var $first;
	var $last;
	var $nick;
	var $email;
	var $online;
}

class icq{
	var $sck;
	var $state=0;
	var $flapcount=0;
	var $refcount=0;
	var $displaydata=false;
	var $timeout=ICQ_DEFAULT_TIMEOUT;
	var $blocking=true;

	var $errors=array();

	var $server;
	var $uin;
	var $password;
	var $cookie;
	var $status;

	var $flap_parsers=array(
		1=>'get_hello',
		2=>'get_snac',
		4=>'get_disconnect'
	);
	var $snac_parsers=array(
		3=>array(
			11=>'get_srv_useronline',
			12=>'get_srv_useroffline'
		),
		4=>array(
			7=>'get_srv_recvmsg'
		),
		21=>array(
			3=>'get_srv_fromicqsrv'
		),
		23=>array(
			5=>'get_srv_newuin'
		)
	);
	var $fromicqsrv_parsers=array(
		2010=>array(
			200=>'get_srv_metageneral',
			210=>'get_srv_metawork',
			220=>'get_srv_metamore'
		)
	);

	function icq($timeout=NULL,$uin=NULL,$pass=NULL){
		if($timeout!==NULL){
			$this->set_timeout($timeout);
		}
		if($uin!==NULL&&$pass!==NULL){
			$res=@$this->login($uin,$pass);
			if($res===false){
				trigger_error(trigger_message('Could not login to ICQ; could not create class'),E_USER_ERROR);
			}
		}
	}

	function set_timeout($timeout){
		$this->timeout=$timeout;
		if($this->sck){
			socket_set_timeout($this->sck,ceil($timeout),fmod($timeout,1)*1000000);
		}
	}
	function set_blocking($blocking=true){
		$this->blocking=$blocking;
		if($this->sck){
			socket_set_blocking($this->sck,$blocking);
		}
	}

	function _get_errorstr($code){
		$strs=array(
			0x00=>'no error',
			0x01=>'multiple logins (on same UIN)',
			0x04=>'bas password',
			0x05=>'bad password',
			0x07=>'non-existant UIN',
			0x08=>'non-existant UIN',
			0x15=>'too many clients from same IP',
			0x16=>'too many clients from same IP',
			0x18=>'rate exceeded (turboing), this means you\'re been connecting and disconnecting too quickly with the same login - the server temporarily bans you',
			0x1B=>'old version of ICQ, need to upgrade',
			0x1D=>'you are reconnecting too fast',
			0x1E=>'can\'t register on ICQ network, try again soon'
		);
		return $strs[$code];
	}

	function _encrypt($str){
		$xor=array(0xF3,0x26,0x81,0xC4,0x39,0x86,0xDB,0x92,0x71,0xA3,0xB9,0xE6,0x53,0x7A,0x95,0x7C);
		$nstr="";
		$len=strlen($str);
		for($i=0;$i<$len;$i++)$nstr.=(substr($str,$i,1)^chr($xor[$i]));
		return $nstr;
	}
	function _fwrite($str,$bold=0){
		if($this->displaydata){
			echo "<span style='font-family:courier;color:blue;".($bold?"font-weight:bold;":"")."'>";
			hecho($str);
			echo "</span>";
			flush();
		}
		return fwrite($this->sck,$str);
	}
	function _fread($len,$bold=0){
		$str=fread($this->sck,$len);
		if($this->displaydata){
			echo "<span style='font-family:courier;color:red;".($bold?"font-weight:bold;":"")."'>";
			hecho($str);
			echo "</span>";
			flush();
		}
		return $str;
	}
	function _update_sequence(&$c){
		$c++;
		if($c>=256*256)$c%=128*256;
		return $c;
	}

	function create_byte($int){
		return intbyte($int);
	}
	function create_wordl($int){
		return strrev(intbytes($int,2));
	}
	function create_dwordl($int){
		return strrev(intbytes($int,4));
	}
	function create_wordb($int){
		return intbytes($int,2);
	}
	function create_dwordb($int){
		return intbytes($int,4);
	}
	function create_ls($str){
		$str=$this->create_byte(strlen($str)).$str;
		return $str;
	}
	function create_lnts($str){
		$str.=chr(0);
		$str=$this->create_wordl(strlen($str)).$str;
		return $str;
	}
	function create_llnts($str){
		$str=$this->create_lnts($str);
		return $this->create_wordl(strlen($str)).$str;
	}
	function create_buin($uin){
		return intbyte(strlen($uin)).$uin;
	}
	function create_bstr($str){
		return $this->create_wordb(strlen($str)).$str;
	}
	function create_ip($ip){
		$ip=explode('.',$ip);
		if(count($ip)==1)
			settype($ip,'integer');
		else
			$ip=$ip[3]+256*$ip[2]+256*256*$ip[1]+256*256*256*$ip[0];
		return intbytes($ip,4);
	}
	function create_tlv($type,$data){
		$str=
			intbytes($type,2).
			intbytes(strlen($data),2).
			$data
		;
		return $str;
	}
	function create_flap($channel,$data){
		$str=intbyte(0x2A);
		$str.=intbyte($channel);
		$str.=$this->create_wordb($this->_update_sequence($this->flapcount));
		$str.=intbytes(strlen($data),2);
		$str.=$data;
		return $str;
	}
	function create_hello_login($uin,$password){
		$str=intbytes(1,4);
		$str.=$this->create_tlv(1,$uin);
		$str.=$this->create_tlv(2,$this->_encrypt($password));
		$str.=$this->create_tlv(3,"ICQ Inc. - Product of ICQ (TM).2002a.5.37.1.3728.85");
		$str.=$this->create_tlv(22,intbytes(0x010A,2));
		$str.=$this->create_tlv(23,intbytes(5,2));
		$str.=$this->create_tlv(24,intbytes(37,2));
		$str.=$this->create_tlv(25,intbytes(1,2));
		$str.=$this->create_tlv(26,intbytes(3828,2));
		$str.=$this->create_tlv(20,intbytes(85,4));
		$str.=$this->create_tlv(15,"de");
		$str.=$this->create_tlv(14,"de");
		return $str;
	}
	function create_hello_cookie($cookie){
		$str=intbytes(1,4);
		$str.=$this->create_tlv(6,$cookie);
		return $str;
	}
	function create_snac($family,$command,$data,$flags=0,$ref=NULL){
		$str=$this->create_wordb($family);
		$str.=$this->create_wordb($command);
		$str.=$this->create_wordb($flags);
		if($ref===NULL)
			$ref=$this->_update_sequence($this->refcount);
		$str.=$this->create_wordb($ref);
		$str.=$this->create_wordb(0);
		$str.=$data;
		return $str;
	}
	function create_cli_toicqsrv($type,$command,$data,$seq=NULL){
		$str=$this->create_wordl(strlen($data)+10);
		$str.=$this->create_dwordl($this->uin);
		$str.=$this->create_wordl($type);
		if($seq===NULL)
			$seq=$this->_update_sequence($this->refcount);
		$str.=$this->create_wordl($seq);
		$str.=$this->create_wordl($command);
		$str.=$data;
		$str=$this->create_tlv(1,$str);
		return $str;
	}
	function create_cli_ready(){
		return
			chr(00).chr(0x01).chr(0x00).chr(0x03).chr(0x01).chr(0x10).
			chr(0x04).chr(0x7B).chr(0x00).chr(0x13).chr(0x00).chr(0x02).
			chr(0x01).chr(0x10).chr(0x04).chr(0x7B).chr(0x00).chr(0x02).
			chr(0x00).chr(0x01).chr(0x01).chr(0x01).chr(0x04).chr(0x7B).
			chr(0x00).chr(0x03).chr(0x00).chr(0x01).chr(0x01).chr(0x10).
			chr(0x04).chr(0x7B).chr(0x00).chr(0x15).chr(0x00).chr(0x01).
			chr(0x01).chr(0x10).chr(0x04).chr(0x7B).chr(0x00).chr(0x04).
			chr(0x00).chr(0x01).chr(0x01).chr(0x10).chr(0x04).chr(0x7B).
			chr(0x00).chr(0x06).chr(0x00).chr(0x01).chr(0x01).chr(0x10).
			chr(0x04).chr(0x7B).chr(0x00).chr(0x09).chr(0x00).chr(0x01).
			chr(0x01).chr(0x10).chr(0x04).chr(0x7B).chr(0x00).chr(0x0A).
			chr(0x00).chr(0x01).chr(0x01).chr(0x10).chr(0x04).chr(0x7B).
			chr(0x00).chr(0x0B).chr(0x00).chr(0x01).chr(0x01).chr(0x10).
			chr(0x04).chr(0x7B)
		;
	}
	function create_cli_reqauth($uin,$message){
		return $this->create_buin($uin).$this->create_bstr($message).$this->create_wordb(0);
	}
	function create_cli_setstatus($status,$ip=NULL,$port=0,$type=ICQ_DC_WEB,$version=8,$webport=80,$timestamps=array(0,0,0)){
		$str=$this->create_tlv(6,$this->create_dwordb($status));
		$str.=$this->create_tlv(8,$this->create_wordb(0));

/*
		$tlvstr=
			$this->create_ip($ip!==NULL?$ip:var_get('SERVER','SERVER_ADDR')).
			$this->create_dwordb($port).
			$this->create_byte($type).
			$this->create_wordb($version).
			$this->create_dwordb(0x14564566).
			$this->create_wordb(0).
			$this->create_wordb($webport).
			$this->create_wordb(0).
			$this->create_wordb(count($timestamps));
		foreach($timestamps as $timestamp)
			$tlvstr.=$this->create_dwordb($timestamp);
		$tlvstr.=$this->create_wordb(0);
		$str.=$this->create_tlv(12,$tlvstr);
*/

		return $str;
	}
	function create_uinlist($uins=array()){
		$str='';
		foreach($uins as $uin)$str.=$this->create_ls($uin);
		return $str;
	}
	function create_cli_addvisible($uins=array()){
		return $this->create_uinlist($uins);
	}
	function create_cli_remvisible($uins=array()){
		return $this->create_uinlist($uins);
	}
	function create_cli_addcontact($uins=array()){
		return $this->create_uinlist($uins);
	}
	function create_cli_remcontact($uins=array()){
		return $this->create_uinlist($uins);
	}
	function create_cli_sendmsg_simple($uin,$text){
		$str=substr(md5(time()),-8);		// MID
		$str.=intbytes(1,2);			// FORMAT: TEXT
		$str.=$this->create_buin($uin);
		$str.=$this->create_tlv(			// MESSAGE
			2,
			(
				$this->create_tlv(1281,intbyte(1)).
				$this->create_tlv(
					257,
					(
						intbytes(0,4).
						$text
					)
				)
			)
		);
		$str.=$this->create_tlv(6,"");
		return $str;
	}
	function create_cli_sendmsg_server($uin,$type,$message){
		$str=$this->create_dwordb(time());
		$str.=substr(md5(time()),-4);
		$str.=$this->create_wordb(4);
		$str.=$this->create_buin($uin);
		$str.=$this->create_tlv(
			5,
			(
				$this->create_dwordl($this->uin).
				$this->create_wordl($type).
				implode(chr(254),$message)
			)
		);
		$str.=$this->create_tlv(6,'');
		return $str;
	}
	function create_cli_registeruser($password){
		phpextension('key');

		$cookie=$this->create_dwordl(unique_key(0,2));
		$null=$this->create_dwordl(0);
		return $this->create_tlv(
			1,
			(
				$null.
				$this->create_wordl(40).
				$this->create_wordl(3).
				$null.$null.
				$cookie.$cookie.
				$null.$null.$null.$null.
				$this->create_lnts($password).
				$cookie.
				chr(0).chr(0).chr(207).chr(1)
			)
		);
	}
	function create_cli_searchbypersinf($form,$online=0){
		$keys=array('first'=>320,'last'=>330,'nick'=>340,'email'=>350);
		$str='';
		foreach($form as $key=>$value){
			if(!isset($keys[$key]))continue;
			$key=$this->create_wordl($keys[$key]);
			$value=$this->create_lnts($value);
			if($key<340)$value=$this->create_wordl(strlen($value)).$value;
			$str.=$key.$value;
		}
		$str.=chr($online);
		return $str;
	}
	function create_cli_metasetemails($emails=array(),$visibility=0){
		$str=$this->create_byte(count($emails));
		for($i=0,$l=count($emails);$i<$l;$i++){
			$str.=$this->create_byte($visibility);
			$str.=$this->create_lnts($emails[$i]);
		}
		return $str;
	}
	function create_cli_metasetgeneral(
		$nick='',
		$first='',
		$last='',
		$email='',
		$city='',
		$state='',
		$phone='',
		$fax='',
		$street='',
		$cellular='',
		$zip='',
		$country=0,
		$tz=236,
		$flags=0
	){
		$str=$this->create_lnts($nick);
		$str.=$this->create_lnts($first);
		$str.=$this->create_lnts($last);
		$str.=$this->create_lnts($email);
		$str.=$this->create_lnts($city);
		$str.=$this->create_lnts($state);
		$str.=$this->create_lnts($phone);
		$str.=$this->create_lnts($fax);
		$str.=$this->create_lnts($street);
		$str.=$this->create_lnts($cellular);
		$str.=$this->create_lnts($zip);
		$str.=$this->create_wordl($country);
		$str.=$this->create_byte($tz);
		$str.=$this->create_byte($flags);
		return $str;
	}
	function create_cli_metasetsecurity(
		$auth=0,
		$webaware=0,
		$direct=0,
		$kind=0
	){
		$str=$this->create_byte($auth);
		$str.=$this->create_byte($webaware);
		$str.=$this->create_byte($direct);
		$str.=$this->create_byte($kind);
		return $str;
	}
	function create_cli_searchbyuin($uin){
		$str=$this->create_wordl(310);
		$str.=$this->create_lnts($this->create_dwordl(intval($uin)));
		return $str;
	}
	function create_cli_searchbyemail($email){
		$str=$this->create_wordl(350);
		$str.=$this->create_llnts($email);
		return $str;
	}
	function create_cli_metareqinfo($uin){
		$str=$this->create_dwordl($uin);
		return $str;
	}
	function send_flap($channel,$data){
		return $this->_send(
			$this->create_flap($channel,$data)
		);
	}
	function send_snac($family,$command,$data,$flags=0){
		return $this->_send(
			$this->create_flap(2,$this->create_snac($family,$command,$data,$flags=0))
		);
	}
	function send_toicqsrv($type,$command,$data){
		$ref=$this->_update_sequence($this->refcount);
		$res=$this->_send(
			$this->create_flap(2,
				$this->create_snac(21,2,
					$this->create_cli_toicqsrv($type,$command,$data,$ref)
				,0,$ref)
			)
		);
		if($res!==false)
			return $ref;
		else return false;
	}
	function extract_lnts($str,&$pos){
		$len=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$str=substr($str,$pos,$len-1);
		$pos+=$len;
		return $str;
	}
	function extract_buin($str,&$pos){
		$len=$this->get_byte($str[$pos]);
		$pos++;
		$str=substr($str,$pos,$len);
		$pos+=$len;
		return $str;
	}
	function extract_llnts(&$str,&$pos){
		$pos+=2;
		return $this->extract_lnts($str,$pos);
	}
	// unused
	function extract_string(&$str,&$pos){
		$startpos=$pos;
		$endpos=strpos($str,chr(0),$pos);
		if($endpos===false)$endpos=strlen($str);
		else $endpos++;
		$pos=$endpos;
		return substr($str,$startpos,$endpos-$startpos-1);
	}
	function extract_tlv(&$str,&$pos){
		$obj=new icq_tlv;
		$obj->type=bytesint(substr($str,$pos,2));
		$obj->length=$len=bytesint(substr($str,$pos+2,2));
		$obj->data=substr($str,$pos+4,$len);
		$pos+=$len+4;
		return $obj;
	}
	function get_byte($str){
		return byteint($str);
	}
	function get_wordl($str){
		return bytesint(strrev(substr($str,0,2)));
	}
	function get_dwordl($str){
		return bytesint(strrev(substr($str,0,4)));
	}
	function get_wordb($str){
		return bytesint(substr($str,0,2));
	}
	function get_dwordb($str){
		return bytesint(substr($str,0,4));
	}
	function get_hello($str){
		$obj=new icq_hello;
		$obj->hello=bytesint(substr($str,0,4));
		for($pos=4,$len=strlen($str);$pos<$len;){
			$tlv=$this->extract_tlv($str,$pos);
			if(!$tlv)break;
			$type=$tlv->type;
			$data=$tlv->data;
			switch($type){
				case 6:$obj->cookie=$data;break;
				case 1:$obj->uin=$data;break;
				case 2:$obj->password=$data;break;
				case 3:$obj->version=$data;break;
				case 22:$obj->clientid=bytesint($data);break;
				case 23:$obj->ver_major=bytesint($data);break;
				case 24:$obj->ver_minor=bytesint($data);break;
				case 25:$obj->ver_lesser=bytesint($data);break;
				case 26:$obj->ver_build=bytesint($data);break;
				case 27:$obj->ver_distrib=bytesint($data);break;
				case 15:$obj->language=$data;break;
				case 14:$obj->country=$data;break;
			}
		}
		return $obj;
	}
	function get_disconnect($str){
		$obj=new icq_disconnect;
		for($pos=0,$len=strlen($str);$pos<$len;){
			$tlv=$this->extract_tlv($str,$pos);
			if(!$tlv)break;
			$type=$tlv->type;
			$data=$tlv->data;
			switch($type){
				case 1:$obj->uin=$data;break;
				case 4:$obj->url=$data;break;
				case 5:$obj->server=$data;break;
				case 6:$obj->cookie=$data;break;
				case 8:$obj->error=bytesint($data);break;
				case 11:$obj->description=$data;break;
			}
		}
		return $obj;
	}
	function get_snac($str){
		$parsers=&$this->snac_parsers;

		$obj=new icq_snac;
		$pos=0;
		$obj->family=bytesint(substr($str,$pos,2));
		$pos+=2;
		$obj->command=bytesint(substr($str,$pos,2));
		$pos+=2;
		$obj->flags=bytesint(substr($str,$pos,2));
		$pos+=2;
		$obj->reference=bytesint(substr($str,$pos,2));
		$pos+=4;
		$obj->data=substr($str,$pos);

		if(isset($parsers[$obj->family])&&isset($parsers[$obj->family][$obj->command])){
			$obj->obj=call_user_method($parsers[$obj->family][$obj->command],&$this,$obj->data);
		}
		else{
			$obj->obj=new icq_unknown;
		}
		return $obj;
	}
	function get_srv_newuin($str){
		$obj=new icq_srv_newuin;
		for($pos=0,$len=strlen($str);$pos<$len;){
			$tlv=$this->extract_tlv($str,$pos);
			if(!$tlv)break;
			switch($tlv->type){
				case 1:
					$tstr=$tlv->data;
					$tpos=22;
					$obj->cookie=$this->get_dwordl(substr($tstr,$tpos,4));
					$tpos+=20;
					$obj->uin=$this->get_dwordl(substr($tstr,$tpos,4));
					break;
			}
		}
		return $obj;
	}
	function get_srv_useronline($str){
		$obj=new icq_srv_useronline;
		$obj->uin=$this->extract_buin($str,$pos=0);
		$pos+=2;
		$count=$this->get_wordb(substr($str,$pos,2));
		$pos+=2;
		for($i=0;$i<$count;$i++){
			$tlv=$this->extract_tlv($str,$pos);
			switch($tlv->type){
				case 10:
					$obj->ip=long2ip($this->get_dwordb($tlv->data));
					break;
				case 6:
					$obj->status=$this->get_dwordb($tlv->data);
					break;
				case 2:
					$obj->membersince=$this->get_dwordb($tlv->data);
					break;
				case 3:
					$obj->onlinesince=$this->get_dwordb($tlv->data);
					break;
			}
		}
		return $obj;
	}
	function get_srv_useroffline($str){
		$obj=new icq_srv_useroffline;
		$obj->uin=$this->extract_buin($str,$pos=0);
		return $obj;
	}
	function get_srv_fromicqsrv($str){
		$parsers=&$this->fromicqsrv_parsers;

		$obj=new icq_srv_fromicqsrv;
		$tlv=$this->extract_tlv($str,$pos=0);
		$str=$tlv->data;
		$pos=0;
		$obj->length=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->uin=$this->get_dwordl(substr($str,$pos,4));
		$pos+=4;
		$obj->type=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->sequence=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->command=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->data=substr($str,$pos);

		if(isset($parsers[$obj->type])&&isset($parsers[$obj->type][$obj->command])){
			$obj->obj=call_user_method($parsers[$obj->type][$obj->command],&$this,$obj->data);
		}
		else{
			$obj->obj=new icq_unknown;
		}
		return $obj;
	}
	function get_srv_metageneral($str){
		$obj=new icq_srv_metageneral;
		$pos=0;
		$obj->success=$this->get_byte($str[$pos]);
		$pos++;
		$obj->nick=$this->extract_lnts($str,$pos);
		$obj->first=$this->extract_lnts($str,$pos);
		$obj->last=$this->extract_lnts($str,$pos);
		$obj->email=$this->extract_lnts($str,$pos);
		$obj->city=$this->extract_lnts($str,$pos);
		$obj->state=$this->extract_lnts($str,$pos);
		$obj->phone=$this->extract_lnts($str,$pos);
		$obj->fax=$this->extract_lnts($str,$pos);
		$obj->street=$this->extract_lnts($str,$pos);
		$obj->cellular=$this->extract_lnts($str,$pos);
		$obj->zip=$this->extract_lnts($str,$pos);
		$obj->country=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->tz=$this->get_byte(substr($str,$pos,1));
		$pos++;
		$obj->flags=$this->get_byte(substr($str,$pos,1));
		$pos++;
		$obj->web=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		return $obj;
	}
	function get_srv_metamore($str){
		$obj=new icq_srv_metawork;
		$pos=0;
		$obj->success=$this->get_byte($str[$pos]);
		$pos++;
		$obj->age=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->gender=$this->get_byte($str[$pos]);
		$pos++;
		$obj->homepage=$this->extract_lnts($str,$pos);
		$obj->year=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->month=$this->get_byte($str[$pos]);
		$pos++;
		$obj->day=$this->get_byte($str[$pos]);
		$pos++;
		$obj->lang1=$this->get_byte($str[$pos]);
		$pos++;
		$obj->lang2=$this->get_byte($str[$pos]);
		$pos++;
		$obj->lang3=$this->get_byte($str[$pos]);
		$pos++;
		$obj->city=$this->extract_lnts($str,$pos);
		$obj->state=$this->extract_lnts($str,$pos);
		$obj->country=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->marital=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		return $obj;
	}
	function get_srv_metawork($str){
		$obj=new icq_srv_metawork;
		$pos=0;
		$obj->success=$this->get_byte($str[$pos]);
		$pos++;
		$obj->city=$this->extract_lnts($str,$pos);
		$obj->state=$this->extract_lnts($str,$pos);
		$obj->phone=$this->extract_lnts($str,$pos);
		$obj->fax=$this->extract_lnts($str,$pos);
		$obj->address=$this->extract_lnts($str,$pos);
		$obj->zip=$this->extract_lnts($str,$pos);
		$obj->country=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->company=$this->extract_lnts($str,$pos);
		$obj->department=$this->extract_lnts($str,$pos);
		$obj->position=$this->extract_lnts($str,$pos);
		$obj->occupation=$this->get_wordl(substr($str,$pos,2));
		$pos+=2;
		$obj->homepage=$this->extract_lnts($str,$pos);
		return $obj;
	}
	function get_srv_recvmsg($str){
		$obj=new icq_srv_recvmsg;
		$pos=0;
		$obj->time=substr($str,$pos,4);
		$pos+=4;
		$obj->id=substr($str,$pos,4);
		$pos+=4;
		$obj->type=bytesint(substr($str,$pos,2));
		$pos+=2;
		$uinlen=byteint(substr($str,$pos,1));
		$pos++;
		$obj->uin=substr($str,$pos,$uinlen);
		$pos+=$uinlen;
		$obj->warning=bytesint(substr($str,$pos,2));
		$pos+=2;
		$count=$obj->count=bytesint(substr($str,$pos,2));
		$pos+=2;
		while($pos<strlen($str)){
			$tlv=$this->extract_tlv($str,$pos);
			switch($tlv->type){
				case 6:$obj->status=$tlv;break;
				case 2:
					$obj->message=new icq_sub_msg_type1;
					$str2=$tlv->data;
					$pos2=0;
					while($pos2<strlen($str2)){
						if($obj->type==1){
							$tlv=$this->extract_tlv($str2,$pos2);
							switch($tlv->type){
								case 1281:
									$obj->message->capabilities=$tlv->data;
									break;
								case 257:
									$obj->message->encoding=bytesint(substr($tlv->data,0,2));
									$obj->message->message=$obj->messagetext=substr($tlv->data,4);
									break;
							}
						}
					}
					break;
				case 5:
					if($obj->type==2){
					}
					elseif($obj->type==4){
						$obj->message=new icq_sub_msg_type4;
						$message=&$obj->message;
						$str2=$tlv->data;
						$pos2=0;
						$message->uin=$this->get_dwordl(substr($str2,$pos2,4));
						$pos2+=4;
						$message->msgtype=$this->get_wordl(substr($str2,$pos2,2));
						$pos2+=2;
						$message->message=$this->extract_lnts(&$str2,$pos2);
						switch($message->msgtype){
							case 4:
								$split=explode(chr(254),$message->message);
								$message->obj=new icq_sub_url;
								$message->obj->description=$split[0];
								$message->obj->url=$split[1];
								break;
							case 19:
								$contacts=array();
								$split=explode(chr(254),$message->message);
								for($j=1,$l=count($split)-1;$j<$l;$j+=2)$contacts[$split[$j+1]]=$split[$j];
								$message->obj=$contacts;
								break;
						}
					}
					break;
			}
		}
		return $obj;
	}

	function connected(){
		if($this->state<1){
			return false;
		}
		if(!$this->sck||feof($this->sck)){
			$this->state=0;
			return false;
		}
		return true;
	}
	function loggedin(){
		return $this->state>1&&$this->connected();
	}
	function _send($str){
		if(!$this->connected()){
			trigger_error(trigger_message('Not connected'),E_USER_WARNING);
			return false;
		}
		return @$this->_fwrite($str);
	}
	function _recv_flap(){
		$data=$this->_fread(1,1);
		if(!strlen($data)){
			trigger_error(trigger_message('No flap in receive-buffer'),E_USER_NOTICE);
			return false;
		}
		$obj=new icq_flap;
		$obj->id=byteint($data);
		$obj->channel=$chan=byteint($this->_fread(1,1));
		$obj->sequence=bytesint($this->_fread(2,1));
		$len=bytesint($this->_fread(2,1));
		$obj->length=$len;
		$obj->data=$this->_fread($len);
		return $obj;
	}
	function _recv(&$flap){
		$flap_parsers=&$this->flap_parsers;

		if(!$this->connected()){
			trigger_error(trigger_message('Not connected'),E_USER_WARNING);
			return false;
		}
		$flap=@$this->_recv_flap();
		if($flap===false){
			trigger_error(trigger_message('No flap received'),E_USER_NOTICE);
			return false;
		}

		if(isset($flap_parsers[$flap->channel])){
			$flap->obj=call_user_method($flap_parsers[$flap->channel],&$this,$flap->data);
		}
		else{
			$flap->obj=new icq_unknown;
		}

		switch($flap->channel){
			case 1:
				$cookie=$flap->obj->cookie;
				$uin=$flap->obj->uin;
				$password=$flap->obj->password;

				if($cookie!=NULL)$this->cookie=$cookie;
				if($uin!=NULL)$this->uin=$uin;
				if($password!=NULL)$this->password=$this->_decrypt($password);
				break;
			case 3:
				$this->errors[]=$error;
				break;
			case 4:
				$server=$flap->obj->server;
				$cookie=$flap->obj->cookie;

				$this->server=$server;
				$this->cookie=$cookie;

				$this->state=1;
				break;
			case 5:
				trigger_error(trigger_message('What shall I do now?'),E_USER_NOTICE);
				break;
			default:
				break;
		}
		return true;
	}
	function _connect(){
		$server=($this->server!=NULL)?($this->server):'login.icq.com';
		$server=explode(':',$server);
		$host=$server[0];
		$port=isset($server[1])?$server[1]:5190;
		$cookie=$this->cookie;
		$uin=$this->uin;
		$password=$this->password;
		$status=$this->status;

		$this->close();
		$this->sck=@fsockopen($host,$port,$errno,$errstr);
		if($this->sck===false){
			trigger_error(trigger_message("ICQ server not reachable: $errstr"),E_USER_WARNING);
			return false;
		}
		$this->set_timeout($this->timeout);
		$this->state=1;

		$res=@$this->_recv($flap);
		if($res===false||$flap->channel!=1){
			trigger_error(trigger_message("No welcome message received by '$host'"),E_USER_WARNING);
			$this->close();
			// Agenda: close
			return false;
		}

		if($cookie!=NULL)
			$this->send_flap(1,$this->create_hello_cookie($cookie));
		else
			$this->send_flap(1,$this->create_hello_login($uin,$password));

		$res=@$this->_recv($flap);
		if($res===false){
			trigger_error(trigger_message('No reply'),E_USER_WARNING);
			$this->close();
			return false;
		}
		elseif($flap->channel==4&&$flap->obj->error){
			trigger_error(trigger_message('Could not login: '.$this->_get_errorstr($flap->obj->error)),E_USER_WARNING);
			$this->close();
			return false;
		}
		elseif(
			$res!==false&&
			$flap->channel==4&&
			!$flap->obj->error&&
			$this->cookie!=NULL&&$this->server!=NULL
		){
			$this->close();
			return $this->_connect();
		}

		if($status==ICQ_STATUS_INVISIBLE)
			$this->send_flap(2,$this->create_snac(9,5,$this->create_cli_addvisible()));
		if($status!=ICQ_STATUS_ONLINE)
			$this->send_flap(2,
				$this->create_snac(1,30,$this->create_cli_setstatus($status))
			);

		$this->send_flap(2,$this->create_snac(1,2,$this->create_cli_ready()));

		$res=$this->_recv($flap);

		$this->state=2;
		return true;
	}

	function close(){
		if($this->connected()){
			$this->_send($this->create_flap(4,''));
			fclose($this->sck);
			$this->state=0;
		}
	}
	function connect($server='login.icq.com'){
		$this->server=$server;

		$server=explode(':',$server);
		$host=$server[0];
		$port=isset($server[1])?$server[1]:5190;

		$this->close();
		$this->sck=@fsockopen($host,$port,$errno,$errstr);
		if($this->sck===false){
			trigger_error(trigger_message("ICQ server not reachable: $errstr"),E_USER_WARNING);
			return false;
		}
		$this->set_timeout($this->timeout);
		$this->state=1;

		$res=@$this->_recv($flap);
		if($res===false||$flap->channel!=1){
			trigger_error(trigger_message("No welcome message received by '$host'"),E_USER_WARNING);
			$this->close();
			// Agenda: close
			return false;
		}
		$this->send_flap(1,chr(0).chr(0).chr(0).chr(1));
		return true;
	}
	function login($uin,$password,$server='login.icq.com',$status=ICQ_STATUS_ONLINE){
		$this->uin=$uin;
		$this->password=$password;
		$this->server=$server;
		$this->status=$status;

		return $this->_connect();
	}
	function relogin($server='login.icq.com'){
		settype($server,'string');
		$this->cookie='';
		$this->server=$server;

		return $this->_connect();
	}
	function recv(&$flap,$wait=NULL){
		if(!$this->connected()){
			trigger_error(trigger_message('Not connected'),E_USER_WARNING);
			return false;
		}
		if($wait===false){
			$rec_blocking=$this->blocking;
			$this->set_blocking(false);
		}
		elseif($wait!==NULL){
			$rec_timeout=$this->timeout;
			$this->set_timeout($wait);
		}
		$res=$this->_recv($flap,$wait);
		if($wait===false){
			$this->set_blocking($rec_blocking);
		}
		elseif($wait!==NULL){
			$this->set_timeout($rec_timeout);
		}
		if(
			$res!==false&&
			$flap->channel==4&&
			!$flap->obj->error
		){
			$this->close($this->sck);
			if($this->cookie!=NULL&&$this->server!=NULL)$this->_connect();
		}
		return $res;
	}

	function send_msg_simple($uin,$message){
		if(!$this->loggedin()){
			trigger_error(trigger_message('Not logged in'),E_USER_WARNING);
			return false;
		}
		return $this->_send(
			$this->create_flap(2,$this->create_snac(4,6,$this->create_cli_sendmsg_simple($uin,$message)))
		);
	}
	function send_msg_server($uin,$type,$message){
		if(!$this->loggedin()){
			trigger_error(trigger_message('Not logged in'),E_USER_WARNING);
			return false;
		}
		return $this->_send(
			$this->create_flap(2,$this->create_snac(4,6,$this->create_cli_sendmsg_server($uin,$type,$message)))
		);
	}
	function send_reqauth($uin,$message){
		if(!$this->loggedin()){
			trigger_error(trigger_message('Not logged in'),E_USER_WARNING);
			return false;
		}
		return $this->_send(
			$this->create_flap(2,$this->create_snac(19,24,$this->create_cli_reqauth($uin,$message)))
		);
	}
	function send_setstatus($status,$ip=NULL,$port=0,$type=ICQ_DC_WEB,$version=8,$webport=80,$timestamps=array(0,0,0)){
		/*
		if(!$this->loggedin()){
			trigger_error(trigger_message('Not logged in'),E_USER_WARNING);
			return false;
		}
		*/
		hecho($this->create_flap(2,$this->create_snac(1,30,$this->create_cli_setstatus(
					$status,$ip,$port,$type,$version,$webport,$timestamps
			))));
		return $this->_send(
			$this->create_flap(2,$this->create_snac(1,30,
				$this->create_cli_setstatus(
					$status,$ip,$port,$type,$version,$webport,$timestamps
				)
			))
		);
	}
	function send_metareqinfo($uin){
		return $this->send_toicqsrv(2000,1202,$this->create_cli_metareqinfo($uin));
	}
	function send_metasetgeneral(
		$nick='',
		$first='',
		$last='',
		$email='',
		$city='',
		$state='',
		$phone='',
		$fax='',
		$street='',
		$cellular='',
		$zip='',
		$country=0,
		$tz=236,
		$flags=0
	){
		return $this->send_toicqsrv(2000,1002,$this->create_cli_metasetgeneral(
			$nick,$first,$last,$email,$city,$state,$phone,
			$fax,$street,$cellular,$zip,$country,$tz,$flags
		));
	}
	function send_metasetsecurity(
		$auth=0,
		$webaware=0,
		$direct=0,
		$kind=0
	){
		return $this->send_toicqsrv(2000,1060,$this->create_cli_metasetsecurity(
			$auth,$webaware,$direct,$kind
		));
	}
	function send_metasetemails($emails=array(),$visibility=0){
		return $this->send_toicqsrv(2000,1035,$this->create_cli_metasetemails(
			$emails,$visibility
		));
	}

	function search_by_persinf($form,$online=0,&$metas,&$missed,$wait=false){
		return $this->send_toicqsrv(2000,1375,$this->create_cli_searchbypersinf($form,$online));
	}
	function search_by_uin($uin,&$meta,$wait=false){
		return $this->send_toicqsrv(2000,1385,$this->create_cli_searchbyuin($uin));
	}
	function search_by_email($email,&$metas,&$missed,$wait=false){
		return $this->send_toicqsrv(2000,1395,$this->create_cli_searchbyemail($email));
	}
}

class icq_client extends icq{
	var $flap_handlers=array();
	var $snac_handlers=array();
	var $fromicqsrv_handlers=array();

	function icq_client($timeout=NULL){
		$this->icq($timeout);
		$this->set_snac_handler(3,11,array(NULL,'handle_srv_useronline'));
		$this->set_snac_handler(3,12,array(NULL,'handle_srv_useroffline'));
	}

	function set_flap_handler($channel,$callback){
		$handlers=&$this->flap_handlers;
		if(!isset($handlers[$channel]))$handlers[$channel]=array();
		array_unshift($handlers[$channel],$callback);
		return true;
	}
	function set_snac_handler($family,$command,$callback){
		$handlers=&$this->snac_handlers;
		if(!isset($handlers[$family]))$handlers[$family]=array();
		if(!isset($handlers[$family][$command]))$handlers[$family][$command]=array();
		array_unshift($handlers[$family][$command],$callback);
		return true;
	}
	function set_fromicqsrv_handler($type,$command,$callback){
		$handlers=&$this->fromicqsrv_handlers;
		if(!isset($handlers[$type]))$handlers[$type]=array();
		if(!isset($handlers[$type][$command]))$handlers[$type][$command]=array();
		array_unshift($handlers[$type][$command],$callback);
		return true;
	}
	function restore_flap_handler($channel){
		$handlers=&$this->flap_handlers;
		if(isset($handlers[$channel]))
			array_shift($handlers[$channel]);
	}
	function restore_snac_handler($family,$command){
		$handlers=&$this->snac_handlers;
		if(isset($handlers[$family])&&isset($handlers[$family][$command]))
			array_shift($handlers[$family][$command]);
	}
	function restore_fromicqsrv_handler($type,$command){
		$handlers=&$this->fromicqsrv_handlers;
		if(isset($handlers[$type])&&isset($handlers[$type][$command]))
			array_shift($handlers[$type][$command]);
	}

	function accept(&$ret,$wait=NULL){
		$flap_handlers=&$this->flap_handlers;
		$snac_handlers=&$this->snac_handlers;
		$fromicqsrv_handlers=&$this->fromicqsrv_handlers;

		if(!$this->connected()){
			trigger_error(trigger_message('Not connected'),E_USER_WARNING);
			return false;
		}

		$res=$this->recv($flap,$wait);
		if(!$res)return;

		if(isset($flap_handlers[$flap->channel])){
			$handler=$flap_handlers[$flap->channel][0];
			if($handler[0]===NULL)$handler=array(&$this,$handler[1]);
			$res=callback($handler,&$flap->obj,&$flap);
			return $res;
		}

		if($flap->channel==2){
			$snac=&$flap->obj;

			if(
				isset($snac_handlers[$snac->family])&&
				isset($snac_handlers[$snac->family][$snac->command])
			){
				$handler=$snac_handlers[$snac->family][$snac->command][0];
				if($handler[0]===NULL)$handler=array(&$this,$handler[1]);
				$res=callback($handler,&$snac->obj,&$snac,&$flap);
				return $res;
			}

			if($snac->family==21&&$snac->command==3){
				$fromicqsrv=&$snac->obj;

				if(
					isset($fromicqsrv_handlers[$fromicqsrv->type])&&
					isset($fromicqsrv_handlers[$fromicqsrv->type][$fromicqsrv->command])
				){
					$handler=$fromicqsrv_handlers[$fromicqsrv->type][$fromicqsrv->command][0];
					if($handler[0]===NULL)$handler=array(&$this,$handler[1]);
					$res=callback($handler,&$fromicqsrv->obj,&$fromicqsrv,&$snac,&$flap);
					return $res;
				}

				trigger_error(trigger_message('No handle for fromicqsrv-message '.get_class($fromicqsrv->obj)." (type $fromicqsrv->type/command $fromicqsrv->command)"),E_USER_WARNING);
				return;
			}

			trigger_error(trigger_message('No handle for snac '.get_class($snac->obj)." (family $snac->family/command $snac->command)"),E_USER_WARNING);
			return;
		}

		trigger_error(trigger_message('No handle for flap '.get_class($flap->obj)." (channel $flap->channel)"),E_USER_WARNING);
		return;
	}

	function listen($callback=NULL,$timeout=NULL){
		if($timeout===NULL)$timeout=$this->timeout;

		for(
			$time=time(),$stop=$time+$timeout,$res=NULL;
			$time<$stop;
			$time=time(),$stop=$res?$time+$timeout:$stop
		){
			if($callback){
				$res=callback($callback);
				if($res===false)return false;
			}
			$res=$this->accept($ret,$timeout);
			if($res===false||$ret===false)return false;
		}
	}

	function check($callback=NULL){
		do{
			if($callback){
				$res=callback($callback);
				if($res===false)return false;
			}
			$res=$this->accept($ret,false);
			if($res===false||$ret===false)return false;
		}
		while($res);
		return $res;
	}

	var $meta;
	function handle_srv_fromicqsrv($obj,$snac){
		switch($obj->command){
			case 200:
				$this->meta->general=$obj->obj;
				break;
			case 210:
				$this->meta->work=$obj->obj;
				break;
			case 220:
				$this->meta->more=$obj->obj;
				break;
		}
		if($snac->flags==0){
			return false;
		}
	}
	function &get_meta($uin){
		$this->meta=new stdClass;
		$this->set_snac_handler(21,3,array(&$this,'handle_srv_fromicqsrv'));
		$this->send_metareqinfo($uin);
		$this->listen();
		$this->restore_snac_handler(21,3);
		return $this->meta;
	}

	var $user_status=array();
	function handle_srv_useronline($obj){
		$this->user_status[$obj->uin]=0xffff&$obj->status;
	}
	function handle_srv_useroffline($obj){
		$this->user_status[$obj->uin]=ICQ_STATUS_OFFLINE;
	}
	function add_visible(){
		$uins=func_get_args();
		$this->send_flap(2,$this->create_snac(9,5,$this->create_cli_addvisible($uins)));
	}
	function remove_visible(){
		$uins=func_get_args();
		$this->send_flap(2,$this->create_snac(9,6,$this->create_cli_remvisible($uins)));
	}
	function add_contact(){
		$uins=func_get_args();
		foreach($uins as $uin)
			if(!isset($this->user_status[$uin]))$this->user_status[$uin]=ICQ_STATUS_OFFLINE;
		$this->send_flap(2,$this->create_snac(3,4,$this->create_cli_addcontact($uins)));
	}
	function remove_contact(){
		$uins=func_get_args();
		foreach($uins as $uin)
			unset($this->user_status[$uin]);
		$this->send_flap(2,$this->create_snac(3,5,$this->create_cli_remcontact($uins)));
	}
	function get_status($uin){
		return isset($this->user_status[$uin])?$this->user_status[$uin]:NULL;
	}

	var $newuin;
	function handle_srv_regerror($obj,$snac,$flap){
		trigger_error(trigger_message('Error creating user'),E_USER_WARNING);
		$this->newuin=false;
		return false;
	}
	function handle_srv_newuin($obj,$snac,$flap){
		$this->newuin=$obj->uin;
		return false;
	}
	function create_uin($password){
		if($this->state!=1){
			trigger_error(trigger_message('Invalid connection-state'),E_USER_WARNING);
			return false;
		}
		$this->newuin=NULL;
		$this->set_snac_handler(23,1,array(&$this,'handle_srv_regerror'));
		$this->set_snac_handler(23,5,array(&$this,'handle_srv_newuin'));
		$this->send_flap(2,$this->create_snac(23,4,$this->create_cli_registeruser($password)));
		$this->listen(NULL,20);
		$this->restore_snac_handler(23,1);
		$this->restore_snac_handler(23,5);
		return $this->newuin;
	}

	function recv_debug($wait=NULL){
		while(true){
			$res=$this->recv($flap,$wait);
			if($res===false)break;
			echo "<pre>\n";
			var_dump($flap);
			echo "</pre>\n";
			if($flap->obj){
				if($flap->obj->obj)hecho($flap->obj->obj->data);
				else hecho($flap->obj->data);
			}
			else hecho($flap->data);
			flush();
		}
	}
}
?>
