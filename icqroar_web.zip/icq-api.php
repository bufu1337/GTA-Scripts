<?php
require_once('icq.php');
header('Content-Type: text/plain');

// timeout is 10
// that means: on default, the client waits 10 seconds for every reply
// if unset, the default socket timeout is used
$icq = new icq_client(10);

// $uin refers to an ICQ number
// you can set your status on login by setting $status to another value
// (for example ICQ_STATUS_AWAY)
function login($uin, $password, $host = 'login.icq.com', $status = ICQ_STATUS_ONLINE) {
	global $icq;

	//echo("Logging in...\n");
	$res = @$icq->login($uin, $password, $host, $status);
	if(!$res) die("[login]0[/login]");
	else echo "[login]1[/login]";
}

// $uin refers to an ICQ number
function sendMessage($uin,$text)
{
	global $icq;

	echo "[send][uid]".$uin."[/uid][msg]".$text."[/msg][/send]";
	$icq->send_msg_simple($uin, $text);
}


// receives any flap message
// read "http://www.micq.org/ICQ-OSCAR-Protocol-v7-v8-v9/" if you want
// to know what flaps and snacs are
function receiveAnything($wait = 10)
{
	global $icq;

	$res = $icq->recv($flap,$wait);
	if($res)
	{
		//var_dump($flap);
		$msg = $flap->obj->obj->message->message;
		echo "[recv]".$msg."[/recv]";
	}
}

function setMyGeneralProfile() {
	global $icq;

	// for information on what arguments to pass see icq.php line 1265 to 1278
	echo("Updating profile...\n");
	$icq->send_metasetgeneral('New-Nickname', 'John','Harrison', 'any@email.org', 'New York');
}

// $uin refers to an ICQ number
function getUserStatus($uin) {
	global $icq;

	echo("Trying to get a user's status...\n");
	// add user to contact list
	$icq->add_contact($uin);

	// listen for incoming messages for 4 seconds
	// if a status information is received, it will be passed to
	// the handler 'handle_srv_useronline' that is registered on default
	// handlers can be set using methods 'set_snac_handler' and
	// 'set_flap_handler'
	// read "http://www.micq.org/ICQ-OSCAR-Protocol-v7-v8-v9/" if you want
	// to know what flaps and snacs are
	$icq->listen(NULL, 4);

	// get status from the in-memory status information cache
	$status = $icq->get_status($uin);

	switch($status) {
		case ICQ_STATUS_ONLINE:
			echo "User $uin is online\n"; break;
		case ICQ_STATUS_OFFLINE:
			echo "User $uin is offline\n"; break;
		case ICQ_STATUS_AWAY:
			echo "User $uin is away\n"; break;
		case ICQ_STATUS_DND:
			echo "User $uin is in do-not-disturb mode\n"; break;
		default:
			echo "I know $uin's status, but I'm to lazy to look it up\n";
	}
}




// login with correct account here...

login($_POST['uid'], $_POST['pw'], 'login.icq.com', ICQ_STATUS_ONLINE);
sleep(1);
if(!strcmp($_POST['action'],"send"))
{
	if(strpos($_POST['senduid'],"|") === false)
	{
		sendMessage($_POST['senduid'],$_POST['sendmsg']);
	}
	else
	{
		$explo = explode("|",$_POST['senduid']);
		foreach($explo as $val)
		{
			sendMessage($val,$_POST['sendmsg']);
		}
	}
}
sleep(1);

$icq->close();
?>