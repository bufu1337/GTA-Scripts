<?php
set_magic_quotes_runtime(false);
ini_set('session.auto_start',false);
ini_set('session.referer_check','');
ini_set('session.use_cookies',true);
ini_set('session.use_trans_sid',false);
set_magic_quotes_runtime(false);
global $trigger_message;
$trigger_message=NULL;

if(!isset($_SESSION)&&isset($HTTP_SESSION_VARS))$_SESSION=&$HTTP_SESSION_VARS;

if(!defined('DEFAULT_DIR'))define('DEFAULT_DIR','.');
if(!isset($debug))$debug=false;

if(!function_exists('file_get_contents')){
	function file_get_contents($path){
		$res=file($path);
		if($res===false)return false;
		return implode("\n",$res);
	}
}
if(!function_exists('file_put_contents')){
	function file_put_contents($path,$data){
		$file=fopen($path,'w');
		fwrite($file,$data);
		fclose($file);
	}
}
if(!function_exists('html_entity_decode')){
	if(!defined('ENT_COMPAT'))define('ENT_COMPAT',0);
	function html_entity_decode($str,$quote_style=ENT_COMPAT){
		$trans_tbl=get_html_translation_table(HTML_ENTITIES,ENT_COMPAT);
		$trans_tbl=array_flip($trans_tbl);
		$ret=strtr($str,$trans_tbl);
		return preg_replace('/&#(\d+);/me',"chr('\\1')",$ret);
	}
}

if(!function_exists('usleep')){
	function usleep($microseconds){
		sleep(ceil($microseconds/1000000));
	}
}

function fsleep($seconds){
	if(windows()){
		$seconds=ceil($seconds);
		sleep($seconds);
	}
	else{
		usleep($seconds*1000000);
	}
	return $seconds;
}

$phpextension_loaded=array();
function phpextension($name){
	global $phpextension_loaded,$debug;
	$name=strtolower($name);
	if(!isset($phpextension_loaded[$name])){
		$path=get_root_path().'/library/'.strtr($name,'_','.').'.php';
		if(!file_exists($path)){
			trigger_error(trigger_message("Failed loading extension '$name' - File '$path' not found"),E_USER_ERROR);
		}
		require_once $path;
		$phpextension_loaded[$name]=true;
	}
}
function phpextension_loaded($name){
	global $phpextension_loaded;
	$name=strtolower($name);
	return $phpextension_loaded[$name]?true:false;
}
define('PEAR_PATH','E:\\PHP\\PEAR');
function pearextension($folder,$name){
	$folfile=PEAR_PATH."/$folder.php";
	if(file_exists($folfile))require_once $folfile;
	$file=PEAR_PATH."/$folder/$name.php";
	if(!file_exists($file)){
		trigger_error(trigger_message("Failed loading pear extension '$folder"."_$name' - File not found"),E_USER_ERROR);
	}
	require_once $file;
}
function extension($name){
	if(!extension_loaded($name)){
		trigger_error(trigger_message("Extension '$name' is not supported by PHP"),E_USER_ERROR);
	}
}

// Zeit in Millisekunden
function mtime(){
	list($msec,$sec)=explode(' ',microtime());
	return (float)$msec+(float)$sec;
}
// Float-f�higer Ganzzahlen-Modulus
if(function_exists('fmod')){
	function mod($x,$y){
		return fmod(round($x),round($y));
	}
}
else{
	function mod($x,$y){
		if(intval($x)!=$x)$x-=$y*floor($x/$y);
		return $x%$y;
	}
}

function sql_is($a,$b,$null=true){
	return '`'.$a.'`='.($null&&$b===NULL?'NULL':'"'.addslashes($b).'"');
}
function sql_is_null($name){
	return "`$name` IS NULL";
}
function sql_isnot($a,$b,$null=true){
	return '`'.$a.'`!='.($null&&$b===NULL?'NULL':'"'.addslashes($b).'"');
}
function sql_and(/*...*/){
	$args=func_get_args();
	return '('.implode(' AND ',$args).')';
}
function sql_or(/*...*/){
	$args=func_get_args();
	return '('.implode(' OR ',$args).')';
}
function sql_any(){
	return '1';
}

define('VAR_GLOBALS',get_cfg_var('register_globals'));
define('VAR_QUOTES',get_magic_quotes_gpc());
function get_var($name,$space='REQUEST'){
	trigger_error(trigger_message('get_var(): This function is deprecated - use var_get() instead'),E_USER_NOTICE);
	return var_get($space,$name);
}
function &var_get($space_name,$name){
	$space=&var_space($space_name);
	if(!isset($space[$name]))return NULL;
	$space_name=strtoupper($space_name);
	if(
		($space_name=='GET'||$space_name=='POST'||$space_name=='COOKIE')&&
		VAR_QUOTES&&gettype($space[$name])=='string'
	)
		return stripslashes($space[$name]);
	return $space[$name];
}
function &var_set($space_name,$name,$value){
	if(VAR_GLOBALS)$GLOBALS[$name]=$value;
	$space=&var_space($space_name);
	$space[$name]=$value;
	return $space[$name];
}
function var_isset($space_name,$name){
	$space=&var_space($space_name);
	return isset($space[$name]);
}
function &var_space($name){
	$name=strtoupper($name);
	if(isset($GLOBALS["_$name"]))return $GLOBALS["_$name"];
	elseif(isset($GLOBALS["HTTP_$name_VARS"]))return $GLOBALS["HTTP_$name_VARS"];
	elseif(isset($GLOBALS["HTTP_POST_$name"]))return $GLOBALS["HTTP_POST_$name"];
	return ($GLOBALS["_$name"]=array());
}
function var_list($space_name){
	$space=&var_space($space_name);
	return array_keys($space);
}

function phpini_set($name,$value){
	var_set('SETTINGS',$name,&$value);
}
function phpini_get($name){
	return var_get('SETTINGS',$name);
}

function get_root_path(){
	return defined('ROOT_PATH')?ROOT_PATH:'.';
}
function set_root_path($path){
	include_path($path);
	define('ROOT_PATH',realpath($path));
}
function include_path($path){
	$path=realpath($path);
	$splitter=windows()?';':':';
	$paths=explode($splitter,ini_get('include_path'));
	if(!in_array($path,$paths)){
		array_push($paths,$path);
		ini_set('include_path',implode($splitter,$paths));
	}
}
function relative_path ($targetfile, $basedir = '.') {
   $basedir    = realpath ($basedir);
   $targetfile = realpath ($targetfile);
  
   // on windows, check that both paths are on the same drive
   if (substr ($basedir, 0, 1) != substr ($targetfile, 0, 1)) {
       return false;
   }
  
   // split each path into its directories
   $base_parts  = split ('\/', str_replace ('\\', '/', $basedir));
   $target_parts = split ('\/', str_replace ('\\', '/', $targetfile));
  
   // ensure that there are no empty elements at the end (c:\ would cause it)
   for ($i = count($base_parts) - 1; $i >= 0; $i--) {
       if ($base_parts[$i] == '') {
           unset ($base_parts[$i]);
       } else {
           break;
       }
   }
   for ($i = count($target_parts) - 1; $i >= 0; $i--) {
       if ($target_parts[$i] == '') {
           unset ($target_parts[$i]);
       } else {
           break;
       }
   }
  
   // get rid of the common directories at the beginning of the paths
   $common_count = 0;
   for ($i = 0; $i < count($base_parts); $i++) {
       if ($target_parts[$i] == $base_parts[$i]) {
           $common_count++;
       } else {
           break;
       }
   }
   for ($i = 0; $i < $common_count; $i++) {
       unset ($base_parts[$i]);
       unset ($target_parts[$i]);
   }
  
   // build the resulting string
   return str_repeat ('../', count($base_parts)) . implode ('/', $target_parts);
}

function windows(){
	return substr(realpath('.'),0,1)!='/';
}
function cgi(){
	return php_sapi_name()=='cgi';
}

function no_cache(){
	if(headers_sent()){
		trigger_error(trigger_message('No-cache can only be set before content starts'),E_USER_WARNING);
		return false;
	}
	header('Pragma: no-cache');
	header('Expires: 0');
	return true;
}

function callback($callback){
	$args=&func_get_args();
	array_shift($args);

	return callback_array(&$callback,&$args);
}
function callback_array($callback,$args=array()){
	if(gettype($callback)=='array')
		return call_user_method_array($callback[1],&$callback[0],$args);
	else
		return call_user_func_array($callback,$args);
}
function repair_callback(&$callback,&$object){
	if(gettype($callback)=='array'&&$callback[0]===NULL)$callback[0]=&$object;
}

// Blinde Zeichen abschneiden
function chopcmd($str){
	for($i=strlen($str);$i>0;$i--){
		if(ord($str[$i-1])>=32)break;
	}
	return substr($str,0,$i);
}
function is_lower($str){
	return strtolower($str)==$str;
}
function is_upper($str){
	return strtoupper($str)==$str;
}
function removeaccents($str){
	return strtr(
		strtr($str,
			'����������������������������������������������������',
			'SZszYAAAAACEEEEIIIINOOOOUUUYaaaaaceeeeiiiinoooouuuyy'),
		array('�'=>'TH','�'=>'th','�'=>'DH','�'=>'dh','�'=>'ss',
			'�'=>'OE','�'=>'oe','�'=>'AE','�'=>'ae','�'=>'u',
			'�'=>'ae','�'=>'oe','�'=>'ue','�'=>'oe',
			'�'=>'AE','�'=>'OE','�'=>'UE','�'=>'OE'));
}

global $xmlentities_trans;
function xmlentities($str){
	global $xmlentities_trans;
	if($xmlentities_trans===NULL){
		$xmlentities_trans=array();
		for($i=128;$i<256;$i++)$xmlentities_trans[chr($i)]="&#$i;";
		foreach(array(chr('<'),chr('>'),chr('&')) as $i)$xmlentities_trans[chr($i)]="&#$i;";
	}
	return strtr($str,$xmlentities_trans);
}
function xmltext($text){
	echo xmlentities($text);
}
function xmlhref($uri,$base=NULL){
	phpextension('uri');
	echo xmlentities(uri($uri,$base));
}
function htmltext($text){
	echo htmlentities($text);
}
function htmlhref($uri,$base=NULL){
	phpextension('uri');
	echo htmlentities(uri($uri,$base));
}

function session_set_root_uri($uri=NULL){
	phpextension('uri');
	$uri=parse_url(uri_normalize($uri));
	ini_set('session.cookie_path',$uri['path']);
	ini_set('session.cookie_domain',$uri['host']);
}
function session_cookies($set=NULL){
	if($set!==NULL){
		ini_set('session.use_cookies',$set);
		return $set;
	}
	else{
		return ini_get('session.use_cookies');
	}
}
if(!function_exists('session_readonly')){
	function session_readonly(){
		$use_cookies=ini_get('session.use_cookies');
		$use_trans_sid=ini_get('session.use_trans_sid');
		ini_set('session.use_cookies',false);
		ini_set('session.use_trans_sid',false);
		$level=ob_get_level();
		session_start();
		session_write_close();
		while(ob_get_level()>$level)ob_get_length()?ob_end_flush():ob_end_clean();
		ini_set('session.use_cookies',$use_cookies);
		ini_set('session.use_trans_sid',$use_trans_sid);
	}
}
function session_open($id){
	ini_set('session.use_cookies',false);
	ini_set('session.use_trans_sid',false);
	session_id($id);
	session_start();
}

function status($status){
	if(cgi()){
		return header("Status: $status");
	}
	else{
		$protocol=var_isset('SERVER','SERVER_PROTOCOL')?
			var_get('SERVER','SERVER_PROTOCOL'):
			'HTTP/1.1';
		return header("$protocol $status");
	}
}


function trigger_message($str){
	global $trigger_message;
	return $trigger_message=$str;
}
function trigger_get_message(){
	global $trigger_message;
	return $trigger_message;
}
?>