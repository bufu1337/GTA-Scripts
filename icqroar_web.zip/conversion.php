<?php
/**
 * Enth�lt Funktionen zur Konversion zwischen verschiedenen Datentypen.
 * @author Filip Dal�ge <filip-www@daluege.de>
 * @copyright Filip Dal�ge, ver�ffentlicht unter der GPL.
 * @package default
 */

function intbytes($int,$len=NULL){
	$hexstr=dechex($int);
	if($len===NULL){
		if(strlen($hexstr)%2)$hexstr="0$hexstr";
	}
	else $hexstr=str_repeat("0",$len*2-strlen($hexstr)).$hexstr;
	$bytes=strlen($hexstr)/2;
	$bin="";
	for($i=0;$i<$bytes;$i++){
		$code=hexdec(substr($hexstr,$i*2,2));
		$bin.=chr($code);
	};
	return $bin;
}
function intbyte($int){
	return chr($int);
}
function byteint($byte){
	return ord($byte);
}
function bytesint($str){
	$int=0;
	$len=strlen($str);
	for($i=0;$i<$len;$i++){
		$int+=ord(substr($str,$i,1))*pow(256,$len-$i-1);
	};
	return $int;
}
function hecho($str){
	echo "<pre>\n";
	for($i=0;$i<strlen($str);$i++){
		echo (ord(substr($str,$i,1))<16?"0":"").dechex(ord(substr($str,$i,1)))." ";
		if(($i+1)%8==0)echo ' ';
		if(($i+1)%16==0)echo "\n";
	};
	echo "</pre>\n";
}
?>