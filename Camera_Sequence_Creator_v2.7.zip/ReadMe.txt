Made my southclaw :)

Simple copy the two folders into your server directory, put the filterscript in your server.cfg line
When you want to use the camera sequences in your main script, put

	#include <CameraMover>

at the top of your gamemode (Below "#include <a_samp>") now you can use LoadCameraMover() to load camera data.
Return this function to a variable:

	myCamVar = LoadCameraMover("Location");

Now you can use this variable in functions like

	PlayCameraMover(myCamVar);



If there are any bugs or you need help setting up or using this script, let me know on the forums,
In the form of a PM, profile message or post on the release topic!


Thank you for using this script! Enjoy :)