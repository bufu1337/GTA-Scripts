                                         Advance Dynamic Dialog Gang System by Crime life Team
		            ---------------------------------------------------------------------------------------



Script Creator - Crime Life New Scripter Laars
Script Released Date - 03/24/2011 [MM/DD/YYYY]
Script Version - 0.5 [BETA]
Script Lines - 910
Next Script Released Date - 04/02/2011 [MM/DD/YYYY]
Next Script Version - 1.0 [STABLE]
Website - http://crimelife.10001mb.com/

F.A.Q
------

Q.1: Can I Upload it on other site?

Ans: Yes you can. But you have to take our permission first

--

Q.2: Can I Copy/paste the code in my gamemode?

Ans: Ofcourse, you can

--

Q.3: Where were you guys these days?

Ans: We were scripting, so we were busy to share script

--

Q.4: Do you guys need admins in server?

Ans: Ofcourse we do. Please post your application in forum in the STAFF section

--

Q.5: Will you released more scripts?

Ans: Yes we will do, if we have time.

--







What is this:
---------------------

It is a filterscript. This filterscript is very very useful for Deathmatch and Roleplay, With this script, you can create gang Dynamically and with ease. All main things is in Dialog and it's very advance. This script produces many features

--------------------

How it works:
------------------------

Video


--------------------------



Features:
---------------

Easy Configuration
Createable Gang
Changeable Gang Spawn
Gang Cash System
Gang Skin system
Gang Weapon System
Gang Kills system
Gang Deaths System
Gang House System
Gang Rank System
Gang Leader System
Gang Member System
Gang Saving System
Gang Chat System
Gang Stats System
Gang Invite System
Gang Kick System
Gang Promote System
Gang Denote System
Everything In Dialog

---------------

Installaton:
----------------

It's easy to install. Just copy/paste the file in your server directory
And add gang in your filterscript line

----------------


CREDITS:
----------------
WackoX             ||          For Fixing /gangs
DarCoBlue         ||          For making din
Crime Life Team ||          For making the half script
DogZone            ||          For the idea and some script help