   NNNNNNNN        NNNNNNNNPPPPPPPPPPPPPPPPP           CCCCCCCCCCCCC
   N:::::::N       N::::::NP::::::::::::::::P       CCC::::::::::::C
   N::::::::N      N::::::NP::::::PPPPPP:::::P    CC:::::::::::::::C
   N:::::::::N     N::::::NPP:::::P     P:::::P  C:::::CCCCCCCC::::C
   N::::::::::N    N::::::N  P::::P     P:::::P C:::::C       CCCCCC
   N:::::::::::N   N::::::N  P::::P     P:::::PC:::::C              
   N:::::::N::::N  N::::::N  P::::PPPPPP:::::P C:::::C              
   N::::::N N::::N N::::::N  P:::::::::::::PP  C:::::C              
   N::::::N  N::::N:::::::N  P::::PPPPPPPPP    C:::::C              
   N::::::N   N:::::::::::N  P::::P            C:::::C              
   N::::::N    N::::::::::N  P::::P            C:::::C              
   N::::::N     N:::::::::N  P::::P             C:::::C       CCCCCC
   N::::::N      N::::::::NPP::::::PP            C:::::CCCCCCCC::::C
   N::::::N       N:::::::NP::::::::P             CC:::::::::::::::C
   N::::::N        N::::::NP::::::::P               CCC::::::::::::C
   NNNNNNNN         NNNNNNNPPPPPPPPPP                  CCCCCCCCCCCCC
                                                                         
88888888ba   88888888ba   88  88888888ba,      ,ad8888ba,   88888888888  
88      "8b  88      "8b  88  88      `"8b    d8"'    `"8b  88           
88      ,8P  88      ,8P  88  88        `8b  d8'            88           
88aaaaaa8P'  88aaaaaa8P'  88  88         88  88             88aaaaa      
88""""""8b,  88""""88'    88  88         88  88      88888  88"""""      
88      `8b  88    `8b    88  88         8P  Y8,        88  88           
88      a8P  88     `8b   88  88      .a8P    Y8a.    .a88  88           
88888888P"   88      `8b  88  88888888Y"'      `"Y88888P"   88888888888  


                       Developed by Whiteagle

   License: http://creativecommons.org/licenses/by-nc-nd/2.5/legalcode

 Test GameMod Commands:
 /car - Get a car near the bot!
 /message - Runs SendChat("This is a sample SendChat");
 /command - Runs SendCommand("/mycommand");
 /start - Runs StartRecordingPlayback(2,"square");
 /stop - Runs StopRecordingPlayback();
 /pause - Runs PauseRecordingPlayback();
 /resume - Runs ResumeRecordingPlayback();
 /mycommand - Runned by the bot & sending the bot to say A Bot running
                                         a command, how fancy is that?


 Thank you and read the license!
 Whiteagle