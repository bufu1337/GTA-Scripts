CarTheft v1.0 By [NL]Mox 2008

This is my first SA:MP gamemode. Enjoy! Please send bugreports to samp@mox.designt.nl
Cartheft is a team-based CTF type gameplay.
Each team has a garage filled with cars they cannot enter.
The other team can enter these cars and steal them by driving them to a checkpoint.
Money and points are awarded for car-steals (depending on the cars health) or defensive actions.
Weapons or vehicles can be bought using the /buy command.

Known bugs:

    * Server crashes once in a while. (no clue why, segfault probably SA:MP bug)
    * Clients crash sometimes.
    * /rcon gmx will crash the server (textdraws). use /restart instead.

    Copyright (C) 2008 Jesper Jeeninga

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see http://www.gnu.org/licenses/.

To install, copy the amx file to your samp\gamemodes directory.
Edit server.cfg and change the line beginning with gamemode0 to:

gamemode0 cartheft 1

Thats it! Enjoy playing!

= Credits =
Thanks to Joost for testing and feedback.
Thanks to the SA:MP team for their great project and WIKI

= Changelog =

Version 1.0 (25-03-2008)

- Initial version.


