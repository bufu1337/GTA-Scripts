Letterbox Mode
By GTA44 (2008)
tux44@msn.com
Do not edit and/or re-release this script without permission from GTA44.

------------------------------

Installation:

1) Put 'lbm.amx' into your filterscripts folder.
2) Open your 'server.cfg' and goto step 3 OR when ingame, login to RCON, then type '/rcon loadfs lbm' (without speechmarks) and ignore step 3.
3) Add 'lbm' (without speechmarks) onto your 'filterscripts' line then save and exit.

------------------------------

Commands:

'/lbhelp' = Letterbox Help
'/lbon' = Letterbox On
'/lboff' = Letterbox Off

------------------------------

Letterbox Mode
By GTA44 (2008)
tux44@msn.com
Do not edit and/or re-release this script without permission from GTA44.