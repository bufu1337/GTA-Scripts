<?php
	// ServerOnlineList v1.1 bY MultiGamer... PHP-script!
	$ip = "127.0.0.1:7777"; // your server's IP-address (not checked anywhere)
	$host = "localhost"; // your server's FTP's host
	$user = "root"; // your server's FTP's username
	$pass = ""; // your server's FTP's user's password
	$file = "scriptfiles/online.txt"; // modify only if your host's FTP doesn't go to the server's dir on connect
	$lang = "en"; // choose your preferred language here; supported: en, hu, sr
	// DON'T CHANGE ANYTHING AFTER THIS LINE!!!
	$conn = ftp_connect($host);
	ftp_login($conn, $user, $pass);
	ftp_get($conn, "online.txt", $file, FTP_ASCII);
	switch ($lang)
	{
		case "en":
			echo ("<b>IP-address: $ip</b><br>Online players:<br>");
			break;
		case "hu":
			echo ("<b>IP-cím: $ip</b><br>Online játékosok:<br>");
			break;
		case "sr":
			echo ("<b>IP-адреса: $ip</b><br>Онлајн играчи:<br>");
			break;
	}
	$temp = file_get_contents("online.txt");
	if (strlen($temp) < 1)
	{
		switch ($lang)
		{
			case "en":
				echo ("There is nobody playing on the server.");
				break;
			case "hu":
				echo ("Senki se játszik a szerveren.");
				break;
			case "sr":
				echo ("Нико не игра на сервер.");
				break;
		}
	}
	else
	{
		echo ("<table width='100%' cols='3' border='0'>");
		switch ($lang)
		{
			case "en":	
				echo ("<tr><td>Name</td><td>Score</td><td>Ping</td>");
				break;
			case "hu":	
				echo ("<tr><td>Név</td><td>Pont</td><td>Ping</td>");
				break;
			case "se":	
				echo ("<tr><td>Име</td><td>Бода</td><td>Ping</td>");
				break;
		}
		echo $temp;
		echo "</table>";
	}
	ftp_close($conn);
?>