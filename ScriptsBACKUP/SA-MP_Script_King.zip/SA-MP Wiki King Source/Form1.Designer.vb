﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabPage11 = New System.Windows.Forms.TabPage
        Me.ListBox21 = New System.Windows.Forms.ListBox
        Me.TabPage10 = New System.Windows.Forms.TabPage
        Me.Callbacks = New System.Windows.Forms.ListBox
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.TabPage9 = New System.Windows.Forms.TabPage
        Me.Label17 = New System.Windows.Forms.Label
        Me.ListBox19 = New System.Windows.Forms.ListBox
        Me.ListBox20 = New System.Windows.Forms.ListBox
        Me.TabPage8 = New System.Windows.Forms.TabPage
        Me.ListBox18 = New System.Windows.Forms.ListBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.TabPage7 = New System.Windows.Forms.TabPage
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.Button10 = New System.Windows.Forms.Button
        Me.Button11 = New System.Windows.Forms.Button
        Me.Button12 = New System.Windows.Forms.Button
        Me.Button13 = New System.Windows.Forms.Button
        Me.Button14 = New System.Windows.Forms.Button
        Me.Button15 = New System.Windows.Forms.Button
        Me.ListBox17 = New System.Windows.Forms.ListBox
        Me.ListBox16 = New System.Windows.Forms.ListBox
        Me.ListBox15 = New System.Windows.Forms.ListBox
        Me.ListBox14 = New System.Windows.Forms.ListBox
        Me.ListBox13 = New System.Windows.Forms.ListBox
        Me.ListBox12 = New System.Windows.Forms.ListBox
        Me.ListBox11 = New System.Windows.Forms.ListBox
        Me.ListBox10 = New System.Windows.Forms.ListBox
        Me.ListBox9 = New System.Windows.Forms.ListBox
        Me.ListBox8 = New System.Windows.Forms.ListBox
        Me.ListBox7 = New System.Windows.Forms.ListBox
        Me.ListBox6 = New System.Windows.Forms.ListBox
        Me.ListBox5 = New System.Windows.Forms.ListBox
        Me.TabPage6 = New System.Windows.Forms.TabPage
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.ListBox4 = New System.Windows.Forms.ListBox
        Me.ListBox3 = New System.Windows.Forms.ListBox
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.TabPage5 = New System.Windows.Forms.TabPage
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.ListBox22 = New System.Windows.Forms.ListBox
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.SoundBox = New System.Windows.Forms.ListBox
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.BikesBox = New System.Windows.Forms.ListBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.PlaneBox = New System.Windows.Forms.ListBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.BoatBox = New System.Windows.Forms.ListBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.CarBox = New System.Windows.Forms.ListBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.MonsterBox = New System.Windows.Forms.ListBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.TrainBox = New System.Windows.Forms.ListBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Trailers = New System.Windows.Forms.ListBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.BicycleBox = New System.Windows.Forms.ListBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.Helicopters = New System.Windows.Forms.ListBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Button35 = New System.Windows.Forms.Button
        Me.PictureBox3 = New System.Windows.Forms.PictureBox
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage12 = New System.Windows.Forms.TabPage
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser
        Me.Button16 = New System.Windows.Forms.Button
        Me.Button17 = New System.Windows.Forms.Button
        Me.Button18 = New System.Windows.Forms.Button
        Me.Button19 = New System.Windows.Forms.Button
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.TabPage11.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.ListBox21)
        Me.TabPage11.Location = New System.Drawing.Point(4, 22)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage11.Size = New System.Drawing.Size(770, 373)
        Me.TabPage11.TabIndex = 10
        Me.TabPage11.Text = "Weapons"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'ListBox21
        '
        Me.ListBox21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox21.FormattingEnabled = True
        Me.ListBox21.Items.AddRange(New Object() {"0 - Unarmed", "1 - Brass Knuckles", "2 - Golf Club", "3 - Night Stick", "4 - Knife", "5 - Baseball Bat", "6 - Shovel", "7 - Pool cue", "8 - Katana", "9 - Chainsaw", "10 - Purple Dildo", "11 - White Dildo", "12 - Long White Dildo", "13 - White Dildo 2", "14 - Flowers", "15 - Cane", "16 - Grenades", "17 - Tear Gas", "18 - Molotovs", "22 - Pistol", "23 - Silenced Pistol", "24 - Desert Eagle", "25 - Shotgun", "26 - Sawn Off Shotgun", "27 - Combat Shotgun", "28 - Micro Uzi (Mac 10)", "29 - MP5", "30 - AK47", "31 - M4", "32 - Tec9", "33 - Rifle", "34 - Sniper Rifle", "35 - RPG", "36 - Missile Launcher", "37 - Flame Thrower", "38 - Minigun", "39 - Sachel Charges", "40 - Detonator", "41 - Spray Paint", "42 - Fire Extinguisher", "43 - Camera", "44 - Nightvision Goggles", "45 - Thermal Goggles", "46 - Parachute"})
        Me.ListBox21.Location = New System.Drawing.Point(3, 3)
        Me.ListBox21.Name = "ListBox21"
        Me.ListBox21.Size = New System.Drawing.Size(764, 355)
        Me.ListBox21.TabIndex = 0
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.TextBox3)
        Me.TabPage10.Controls.Add(Me.Callbacks)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(770, 373)
        Me.TabPage10.TabIndex = 9
        Me.TabPage10.Text = "Callbacks"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'Callbacks
        '
        Me.Callbacks.FormattingEnabled = True
        Me.Callbacks.Items.AddRange(New Object() {"OnGameModeInit", "OnGameModeExit", "OnFilterScriptInit", "OnFilterScriptExit", "OnPlayerConnect", "OnPlayerDisconnect", "OnPlayerSpawn", "OnPlayerDeath", "OnVehicleSpawn", "OnVehicleDeath", "OnPlayerText", "OnPlayerCommandText", "OnPlayerInfoChange", "OnPlayerRequestClass", "OnPlayerEnterVehicle", "OnPlayerExitVehicle", "OnPlayerStateChange", "OnPlayerEnterCheckpoint", "OnPlayerLeaveCheckpoint", "OnPlayerEnterRaceCheckpoint", "OnPlayerLeaveRaceCheckpoint", "OnRconCommand", "OnPlayerPrivmsg", "OnPlayerRequestSpawn", "OnObjectMoved", "OnPlayerObjectMoved", "OnPlayerPickUpPickup", "OnVehiclePaintjob", "OnVehicleRespray", "OnVehicleMod", "OnPlayerSelectedMenuRow", "OnPlayerExitedMenu", "OnPlayerInteriorChange", "OnPlayerKeyStateChange"})
        Me.Callbacks.Location = New System.Drawing.Point(524, 6)
        Me.Callbacks.Name = "Callbacks"
        Me.Callbacks.Size = New System.Drawing.Size(238, 355)
        Me.Callbacks.TabIndex = 0
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(8, 6)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(510, 355)
        Me.TextBox3.TabIndex = 1
        Me.TextBox3.Text = "Callbacks will be displayed here once a selection is made."
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.ListBox20)
        Me.TabPage9.Controls.Add(Me.ListBox19)
        Me.TabPage9.Controls.Add(Me.Label17)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(770, 373)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Animations"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(319, 3)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(97, 13)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "Raw Animation List"
        '
        'ListBox19
        '
        Me.ListBox19.FormattingEnabled = True
        Me.ListBox19.Items.AddRange(New Object() {"       thrw_barl_thrw", "       Stepsit_in", "       Stepsit_loop", "       Stepsit_out", "       Barcustom_get", "       Barcustom_loop", "       Barcustom_order", "       BARman_idle", "       Barserve_bottle", "       Barserve_give", "       Barserve_glass", "       Barserve_in", "       Barserve_loop", "       Barserve_order", "       dnk_stndF_loop", "       dnk_stndM_loop", "       Bat_1", "       Bat_2", "       Bat_3", "       Bat_4", "       Bat_block", "       Bat_Hit_1", "       Bat_Hit_2", "       Bat_Hit_3", "       Bat_IDLE", "       Bat_M", "       BAT_PART", "       BD_Fire1", "       BD_Fire2", "       BD_Fire3", "       BD_GF_Wave", "       BD_Panic_01", "       BD_Panic_02", "       BD_Panic_03", "       BD_Panic_04", "       BD_Panic_Loop", "       Grlfrd_Kiss_03", "       M_smklean_loop", "       Playa_Kiss_03", "       wash_up", "       bather", "       Lay_Bac_Loop", "       ParkSit_M_loop", "       ParkSit_W_loop", "       SitnWait_loop_W", "       gym_bp_celebrate", "       gym_bp_down", "       gym_bp_getoff", "       gym_bp_geton", "       gym_bp_up_A", "       gym_bp_up_B", "       gym_bp_up_smooth", "       BF_getin_LHS", "       BF_getin_RHS", "       BF_getout_LHS", "       BF_getout_RHS", "       BIKEd_Back", "       BIKEd_drivebyFT", "       BIKEd_drivebyLHS", "       BIKEd_drivebyRHS", "       BIKEd_Fwd", "       BIKEd_getoffBACK", "       BIKEd_getoffLHS", "       BIKEd_getoffRHS", "       BIKEd_hit", "       BIKEd_jumponL", "       BIKEd_jumponR", "       BIKEd_kick", "       BIKEd_Left", "       BIKEd_passenger", "       BIKEd_pushes", "       BIKEd_Ride", "       BIKEd_Right", "       BIKEd_shuffle", "       BIKEd_Still", "       BIKEh_Back", "       BIKEh_drivebyFT", "       BIKEh_drivebyLHS", "       BIKEh_drivebyRHS", "       BIKEh_Fwd", "       BIKEh_getoffBACK", "       BIKEh_getoffLHS", "       BIKEh_getoffRHS", "       BIKEh_hit", "       BIKEh_jumponL", "       BIKEh_jumponR", "       BIKEh_kick", "       BIKEh_Left", "       BIKEh_passenger", "       BIKEh_pushes", "       BIKEh_Ride", "       BIKEh_Right", "       BIKEh_Still", "       bk_blnce_in", "       bk_blnce_out", "       bk_jmp", "       bk_rdy_in", "       bk_rdy_out", "       struggle_cesar", "       struggle_driver", "       truck_driver", "       truck_getin", "       BIKEs_Back", "       BIKEs_drivebyFT", "       BIKEs_drivebyLHS", "       BIKEs_drivebyRHS", "       BIKEs_Fwd", "       BIKEs_getoffBACK", "       BIKEs_getoffLHS", "       BIKEs_getoffRHS", "       BIKEs_hit", "       BIKEs_jumponL", "       BIKEs_jumponR", "       BIKEs_kick", "       BIKEs_Left", "       BIKEs_passenger", "       BIKEs_pushes", "       BIKEs_Ride", "       BIKEs_Right", "       BIKEs_Snatch_L", "       BIKEs_Snatch_R", "       BIKEs_Still", "       BIKEv_Back", "       BIKEv_drivebyFT", "       BIKEv_drivebyLHS", "       BIKEv_drivebyRHS", "       BIKEv_Fwd", "       BIKEv_getoffBACK", "       BIKEv_getoffLHS", "       BIKEv_getoffRHS", "       BIKEv_hit", "       BIKEv_jumponL", "       BIKEv_jumponR", "       BIKEv_kick", "       BIKEv_Left", "       BIKEv_passenger", "       BIKEv_pushes", "       BIKEv_Ride", "       BIKEv_Right", "       BIKEv_Still", "       Pass_Driveby_BWD", "       Pass_Driveby_FWD", "       Pass_Driveby_LHS", "       Pass_Driveby_RHS", "       BMX_back", "       BMX_bunnyhop", "       BMX_drivebyFT", "       BMX_driveby_LHS", "       BMX_driveby_RHS", "       BMX_fwd", "       BMX_getoffBACK", "       BMX_getoffLHS", "       BMX_getoffRHS", "       BMX_jumponL", "       BMX_jumponR", "       BMX_Left", "       BMX_pedal", "       BMX_pushes", "       BMX_Ride", "       BMX_Right", "       BMX_sprint", "       BMX_still", "       BOM_Plant", "       BOM_Plant_2Idle", "       BOM_Plant_Crouch_In", "       BOM_Plant_Crouch_Out", "       BOM_Plant_In", "       BOM_Plant_Loop", "       boxhipin", "       boxhipup", "       boxshdwn", "       boxshup", "       bxhipwlk", "       bxhwlki", "       bxshwlk", "       bxshwlki", "       bxwlko", "       catch_box", "       BBALL_def_jump_shot", "       BBALL_def_loop", "       BBALL_def_stepL", "       BBALL_def_stepR", "       BBALL_Dnk", "       BBALL_Dnk_Gli", "       BBALL_Dnk_Gli_O", "       BBALL_Dnk_Lnch", "       BBALL_Dnk_Lnch_O", "       BBALL_Dnk_Lnd", "       BBALL_Dnk_O", "       BBALL_idle", "       BBALL_idle2", "       BBALL_idle2_O", "       BBALL_idleloop", "       BBALL_idleloop_O", "       BBALL_idle_O", "       BBALL_Jump_Cancel", "       BBALL_Jump_Cancel_O", "       BBALL_Jump_End", "       BBALL_Jump_Shot", "       BBALL_Jump_Shot_O", "       BBALL_Net_Dnk_O", "       BBALL_pickup", "       BBALL_pickup_O", "       BBALL_react_miss", "       BBALL_react_score", "       BBALL_run", "       BBALL_run_O", "       BBALL_SkidStop_L", "       BBALL_SkidStop_L_O", "       BBALL_SkidStop_R", "       BBALL_SkidStop_R_O", "       BBALL_walk", "       BBALL_WalkStop_L", "       BBALL_WalkStop_L_O", "       BBALL_WalkStop_R", "       BBALL_WalkStop_R_O", "       BBALL_walk_O", "       BBALL_walk_start", "       BBALL_walk_start_O", "       buddy_crouchfire", "       buddy_crouchreload", "       buddy_fire", "       buddy_fire_poor", "       buddy_reload", "       BUS_close", "       BUS_getin_LHS", "       BUS_getin_RHS", "       BUS_getout_LHS", "       BUS_getout_RHS", "       BUS_jacked_LHS", "       BUS_open", "       BUS_open_RHS", "       BUS_pullout_LHS", "       camcrch_cmon", "       camcrch_idleloop", "       camcrch_stay", "       camcrch_to_camstnd", "       camstnd_cmon", "       camstnd_idleloop", "       camstnd_lkabt", "       camstnd_to_camcrch", "       piccrch_in", "       piccrch_out", "       piccrch_take", "       picstnd_in", "       picstnd_out", "       picstnd_take", "       Fixn_Car_Loop", "       Fixn_Car_Out", "       flag_drop", "       Sit_relaxed", "       Tap_hand", "       Tyd2car_bump", "       Tyd2car_high", "       Tyd2car_low", "       Tyd2car_med", "       Tyd2car_TurnL", "       Tyd2car_TurnR", "       crry_prtial", "       liftup", "       liftup05", "       liftup105", "       putdwn", "       putdwn05", "       putdwn105", "       carfone_in", "       carfone_loopA", "       carfone_loopA_to_B", "       carfone_loopB", "       carfone_loopB_to_A", "       carfone_out", "       CAR_Sc1_BL", "       CAR_Sc1_BR", "       CAR_Sc1_FL", "       CAR_Sc1_FR", "       CAR_Sc2_FL", "       CAR_Sc3_BR", "       CAR_Sc3_FL", "       CAR_Sc3_FR", "       CAR_Sc4_BL", "       CAR_Sc4_BR", "       CAR_Sc4_FL", "       CAR_Sc4_FR", "       car_talkm_in", "       car_talkm_loop", "       car_talkm_out", "       cards_in", "       cards_loop", "       cards_lose", "       cards_out", "       cards_pick_01", "       cards_pick_02", "       cards_raise", "       cards_win", "       dealone", "       manwinb", "       manwind", "       Roulette_bet", "       Roulette_in", "       Roulette_loop", "       Roulette_lose", "       Roulette_out", "       Roulette_win", "       Slot_bet_01", "       Slot_bet_02", "       Slot_in", "       Slot_lose_out", "       Slot_Plyr", "       Slot_wait", "       Slot_win_out", "       wof", "       CSAW_1", "       CSAW_2", "       CSAW_3", "       CSAW_G", "       CSAW_Hit_1", "       CSAW_Hit_2", "       CSAW_Hit_3", "       csaw_part", "       IDLE_csaw", "       WEAPON_csaw", "       WEAPON_csawlo", "       CHOPPA_back", "       CHOPPA_bunnyhop", "       CHOPPA_drivebyFT", "       CHOPPA_driveby_LHS", "       CHOPPA_driveby_RHS", "       CHOPPA_fwd", "       CHOPPA_getoffBACK", "       CHOPPA_getoffLHS", "       CHOPPA_getoffRHS", "       CHOPPA_jumponL", "       CHOPPA_jumponR", "       CHOPPA_Left", "       CHOPPA_pedal", "       CHOPPA_Pushes", "       CHOPPA_ride", "       CHOPPA_Right", "       CHOPPA_sprint", "       CHOPPA_Still", "       CLO_Buy", "       CLO_In", "       CLO_Out", "       CLO_Pose_Hat", "       CLO_Pose_In", "       CLO_Pose_In_O", "       CLO_Pose_Legs", "       CLO_Pose_Loop", "       CLO_Pose_Out", "       CLO_Pose_Out_O", "       CLO_Pose_Shoes", "       CLO_Pose_Torso", "       CLO_Pose_Watch", "       COACH_inL", "       COACH_inR", "       COACH_opnL", "       COACH_opnR", "       COACH_outL", "       COACH_outR", "       2guns_crouchfire", "       colt45_crouchfire", "       colt45_crouchreload", "       colt45_fire", "       colt45_fire_2hands", "       colt45_reload", "       sawnoff_reload", "       Copbrowse_in", "       Copbrowse_loop", "       Copbrowse_nod", "       Copbrowse_out", "       Copbrowse_shake", "       Coplook_in", "       Coplook_loop", "       Coplook_nod", "       Coplook_out", "       Coplook_shake", "       Coplook_think", "       Coplook_watch", "       COP_Dvby_B", "       COP_Dvby_FT", "       COP_Dvby_L", "       COP_Dvby_R", "       Bbalbat_Idle_01", "       Bbalbat_Idle_02", "       crckdeth1", "       crckdeth2", "       crckdeth3", "       crckdeth4", "       crckidle1", "       crckidle2", "       crckidle3", "       crckidle4", "       CRIB_Console_Loop", "       CRIB_Use_Switch", "       PED_Console_Loop", "       PED_Console_Loose", "       PED_Console_Win", "       DAM_Dive_Loop", "       DAM_Land", "       DAM_Launch", "       Jump_Roll", "       SF_JumpWall", "       bd_clap", "       bd_clap1", "       dance_loop", "       DAN_Down_A", "       DAN_Left_A", "       DAN_Loop_A", "       DAN_Right_A", "       DAN_Up_A", "       dnce_M_a", "       dnce_M_b", "       dnce_M_c", "       dnce_M_d", "       dnce_M_e", "       DEALER_DEAL", "       DEALER_IDLE", "       DEALER_IDLE_01", "       DEALER_IDLE_02", "       DEALER_IDLE_03", "       DRUGS_BUY", "       shop_pay", "       DILDO_1", "       DILDO_2", "       DILDO_3", "       DILDO_block", "       DILDO_G", "       DILDO_Hit_1", "       DILDO_Hit_2", "       DILDO_Hit_3", "       DILDO_IDLE", "       Cover_Dive_01", "       Cover_Dive_02", "       Crushed", "       Crush_Jump", "       DOZER_Align_LHS", "       DOZER_Align_RHS", "       DOZER_getin_LHS", "       DOZER_getin_RHS", "       DOZER_getout_LHS", "       DOZER_getout_RHS", "       DOZER_Jacked_LHS", "       DOZER_Jacked_RHS", "       DOZER_pullout_LHS", "       DOZER_pullout_RHS", "       Gang_DrivebyLHS", "       Gang_DrivebyLHS_Bwd", "       Gang_DrivebyLHS_Fwd", "       Gang_DrivebyRHS", "       Gang_DrivebyRHS_Bwd", "       Gang_DrivebyRHS_Fwd", "       Gang_DrivebyTop_LHS", "       Gang_DrivebyTop_RHS", "       FatIdle", "       FatIdle_armed", "       FatIdle_Csaw", "       FatIdle_Rocket", "       FatRun", "       FatRun_armed", "       FatRun_Csaw", "       FatRun_Rocket", "       FatSprint", "       FatWalk", "       FatWalkstart", "       FatWalkstart_Csaw", "       FatWalkSt_armed", "       FatWalkSt_Rocket", "       FatWalk_armed", "       FatWalk_Csaw", "       FatWalk_Rocket", "       IDLE_tired", "       FightB_1", "       FightB_2", "       FightB_3", "       FightB_block", "       FightB_G", "       FightB_IDLE", "       FightB_M", "       HitB_1", "       HitB_2", "       HitB_3", "       FightC_1", "       FightC_2", "       FightC_3", "       FightC_block", "       FightC_blocking", "       FightC_G", "       FightC_IDLE", "       FightC_M", "       FightC_Spar", "       HitC_1", "       HitC_2", "       HitC_3", "       FightD_1", "       FightD_2", "       FightD_3", "       FightD_block", "       FightD_G", "       FightD_IDLE", "       FightD_M", "       HitD_1", "       HitD_2", "       HitD_3", "       FightKick", "       FightKick_B", "       Hit_fightkick", "       Hit_fightkick_B", "       FIN_Climb_In", "       FIN_Cop1_ClimbOut2", "       FIN_Cop1_Loop", "       FIN_Cop1_Stomp", "       FIN_Hang_L", "       FIN_Hang_Loop", "       FIN_Hang_R", "       FIN_Hang_Slip", "       FIN_Jump_On", "       FIN_Land_Car", "       FIN_Land_Die", "       FIN_LegsUp", "       FIN_LegsUp_L", "       FIN_LegsUp_Loop", "       FIN_LegsUp_R", "       FIN_Let_Go", "       FIN_Cop1_ClimbOut", "       FIN_Cop1_Fall", "       FIN_Cop1_Loop", "       FIN_Cop1_Shot", "       FIN_Cop1_Swing", "       FIN_Cop2_ClimbOut", "       FIN_Switch_P", "       FIN_Switch_S", "       FLAME_fire", "       Flower_attack", "       Flower_attack_M", "       Flower_Hit", "       EAT_Burger", "       EAT_Chicken", "       EAT_Pizza", "       EAT_Vomit_P", "       EAT_Vomit_SK", "       FF_Dam_Bkw", "       FF_Dam_Fwd", "       FF_Dam_Left", "       FF_Dam_Right", "       FF_Die_Bkw", "       FF_Die_Fwd", "       FF_Die_Left", "       FF_Die_Right", "       FF_Sit_Eat1", "       FF_Sit_Eat2", "       FF_Sit_Eat3", "       FF_Sit_In", "       FF_Sit_In_L", "       FF_Sit_In_R", "       FF_Sit_Look", "       FF_Sit_Loop", "       FF_Sit_Out_180", "       FF_Sit_Out_L_180", "       FF_Sit_Out_R_180", "       SHP_Thank", "       SHP_Tray_In", "       SHP_Tray_Lift", "       SHP_Tray_Lift_In", "       SHP_Tray_Lift_Loop", "       SHP_Tray_Lift_Out", "       SHP_Tray_Out", "       SHP_Tray_Pose", "       SHP_Tray_Return", "       gym_barbell", "       gym_free_A", "       gym_free_B", "       gym_free_celebrate", "       gym_free_down", "       gym_free_loop", "       gym_free_pickup", "       gym_free_putdown", "       gym_free_up_smooth", "       DEALER_DEAL", "       DEALER_IDLE", "       drnkbr_prtl", "       drnkbr_prtl_F", "       DRUGS_BUY", "       hndshkaa", "       hndshkba", "       hndshkca", "       hndshkcb", "       hndshkda", "       hndshkea", "       hndshkfa", "       hndshkfa_swt", "       Invite_No", "       Invite_Yes", "       leanIDLE", "       leanIN", "       leanOUT", "       prtial_gngtlkA", "       prtial_gngtlkB", "       prtial_gngtlkC", "       prtial_gngtlkD", "       prtial_gngtlkE", "       prtial_gngtlkF", "       prtial_gngtlkG", "       prtial_gngtlkH", "       prtial_hndshk_01", "       prtial_hndshk_biz_01", "       shake_cara", "       shake_carK", "       shake_carSH", "       smkcig_prtl", "       smkcig_prtl_F", "       gsign1", "       gsign1LH", "       gsign2", "       gsign2LH", "       gsign3", "       gsign3LH", "       gsign4", "       gsign4LH", "       gsign5", "       gsign5LH", "       LHGsign1", "       LHGsign2", "       LHGsign3", "       LHGsign4", "       LHGsign5", "       RHGsign1", "       RHGsign2", "       RHGsign3", "       RHGsign4", "       RHGsign5", "       GDB_Car2_PLY", "       GDB_Car2_SMO", "       GDB_Car2_SWE", "       GDB_Car_PLY", "       GDB_Car_RYD", "       GDB_Car_SMO", "       GDB_Car_SWE", "       goggles_put_on", "       graffiti_Chkout", "       spraycan_fire", "       mrnF_loop", "       mrnM_loop", "       prst_loopa", "       WEAPON_start_throw", "       WEAPON_throw", "       WEAPON_throwu", "       GYMshadowbox", "       gym_bike_celebrate", "       gym_bike_fast", "       gym_bike_faster", "       gym_bike_getoff", "       gym_bike_geton", "       gym_bike_pedal", "       gym_bike_slow", "       gym_bike_still", "       gym_jog_falloff", "       gym_shadowbox", "       gym_tread_celebrate", "       gym_tread_falloff", "       gym_tread_getoff", "       gym_tread_geton", "       gym_tread_jog", "       gym_tread_sprint", "       gym_tread_tired", "       gym_tread_walk", "       gym_walk_falloff", "       Pedals_fast", "       Pedals_med", "       Pedals_slow", "       Pedals_still", "       BRB_Beard_01", "       BRB_Buy", "       BRB_Cut", "       BRB_Cut_In", "       BRB_Cut_Out", "       BRB_Hair_01", "       BRB_Hair_02", "       BRB_In", "       BRB_Loop", "       BRB_Out", "       BRB_Sit_In", "       BRB_Sit_Loop", "       BRB_Sit_Out", "       CAS_G2_GasKO", "       swt_wllpk_L", "       swt_wllpk_L_back", "       swt_wllpk_R", "       swt_wllpk_R_back", "       swt_wllshoot_in_L", "       swt_wllshoot_in_R", "       swt_wllshoot_out_L", "       swt_wllshoot_out_R", "       Use_SwipeCard", "       BED_In_L", "       BED_In_R", "       BED_Loop_L", "       BED_Loop_R", "       BED_Out_L", "       BED_Out_R", "       LOU_In", "       LOU_Loop", "       LOU_Out", "       wash_up", "       FF_Dam_Fwd", "       OFF_Sit_2Idle_180", "       OFF_Sit_Bored_Loop", "       OFF_Sit_Crash", "       OFF_Sit_Drink", "       OFF_Sit_Idle_Loop", "       OFF_Sit_In", "       OFF_Sit_Read", "       OFF_Sit_Type_Loop", "       OFF_Sit_Watch", "       shop_cashier", "       shop_in", "       shop_lookA", "       shop_lookB", "       shop_loop", "       shop_out", "       shop_pay", "       shop_shelf", "       girl_01", "       girl_02", "       player_01", "       smoke_01", "       KART_getin_LHS", "       KART_getin_RHS", "       KART_getout_LHS", "       KART_getout_RHS", "       BD_GF_Wave", "       gfwave2", "       GF_CarArgue_01", "       GF_CarArgue_02", "       GF_CarSpot", "       GF_StreetArgue_01", "       GF_StreetArgue_02", "       gift_get", "       gift_give", "       Grlfrd_Kiss_01", "       Grlfrd_Kiss_02", "       Grlfrd_Kiss_03", "       Playa_Kiss_01", "       Playa_Kiss_02", "       Playa_Kiss_03", "       KILL_Knife_Ped_Damage", "       KILL_Knife_Ped_Die", "       KILL_Knife_Player", "       KILL_Partial", "       knife_1", "       knife_2", "       knife_3", "       Knife_4", "       knife_block", "       Knife_G", "       knife_hit_1", "       knife_hit_2", "       knife_hit_3", "       knife_IDLE", "       knife_part", "       WEAPON_knifeidle", "       LAPDAN_D", "       LAPDAN_P", "       LAPDAN_D", "       LAPDAN_P", "       LAPDAN_D", "       LAPDAN_P", "       F_smklean_loop", "       lrgirl_bdbnce", "       lrgirl_hair", "       lrgirl_hurry", "       lrgirl_idleloop", "       lrgirl_idle_to_l0", "       lrgirl_l0_bnce", "       lrgirl_l0_loop", "       lrgirl_l0_to_l1", "       lrgirl_l12_to_l0", "       lrgirl_l1_bnce", "       lrgirl_l1_loop", "       lrgirl_l1_to_l2", "       lrgirl_l2_bnce", "       lrgirl_l2_loop", "       lrgirl_l2_to_l3", "       lrgirl_l345_to_l1", "       lrgirl_l3_bnce", "       lrgirl_l3_loop", "       lrgirl_l3_to_l4", "       lrgirl_l4_bnce", "       lrgirl_l4_loop", "       lrgirl_l4_to_l5", "       lrgirl_l5_bnce", "       lrgirl_l5_loop", "       M_smklean_loop", "       M_smkstnd_loop", "       prtial_gngtlkB", "       prtial_gngtlkC", "       prtial_gngtlkD", "       prtial_gngtlkE", "       prtial_gngtlkF", "       prtial_gngtlkG", "       prtial_gngtlkH", "       RAP_A_Loop", "       RAP_B_Loop", "       RAP_C_Loop", "       Sit_relaxed", "       Tap_hand", "       Carhit_Hangon", "       Carhit_Tumble", "       donutdrop", "       Fen_Choppa_L1", "       Fen_Choppa_L2", "       Fen_Choppa_L3", "       Fen_Choppa_R1", "       Fen_Choppa_R2", "       Fen_Choppa_R3", "       Hangon_Stun_loop", "       Hangon_Stun_Turn", "       MD_BIKE_2_HANG", "       MD_BIKE_Jmp_BL", "       MD_BIKE_Jmp_F", "       MD_BIKE_Lnd_BL", "       MD_BIKE_Lnd_Die_BL", "       MD_BIKE_Lnd_Die_F", "       MD_BIKE_Lnd_F", "       MD_BIKE_Lnd_Roll", "       MD_BIKE_Lnd_Roll_F", "       MD_BIKE_Punch", "       MD_BIKE_Punch_F", "       MD_BIKE_Shot_F", "       MD_HANG_Lnd_Roll", "       MD_HANG_Loop", "       END_SC1_PLY", "       END_SC1_RYD", "       END_SC1_SMO", "       END_SC1_SWE", "       END_SC2_PLY", "       END_SC2_RYD", "       END_SC2_SMO", "       END_SC2_SWE", "       CPR", "       bitchslap", "       BMX_celebrate", "       BMX_comeon", "       bmx_idleloop_01", "       bmx_idleloop_02", "       bmx_talkleft_in", "       bmx_talkleft_loop", "       bmx_talkleft_out", "       bmx_talkright_in", "       bmx_talkright_loop", "       bmx_talkright_out", "       bng_wndw", "       bng_wndw_02", "       Case_pickup", "       door_jet", "       GRAB_L", "       GRAB_R", "       Hiker_Pose", "       Hiker_Pose_L", "       Idle_Chat_02", "       KAT_Throw_K", "       KAT_Throw_O", "       KAT_Throw_P", "       PASS_Rifle_O", "       PASS_Rifle_Ped", "       PASS_Rifle_Ply", "       pickup_box", "       Plane_door", "       Plane_exit", "       Plane_hijack", "       Plunger_01", "       Plyrlean_loop", "       plyr_shkhead", "       Run_Dive", "       Scratchballs_01", "       SEAT_LR", "       Seat_talk_01", "       Seat_talk_02", "       SEAT_watch", "       smalplane_door", "       smlplane_door", "       MTB_back", "       MTB_bunnyhop", "       MTB_drivebyFT", "       MTB_driveby_LHS", "       MTB_driveby_RHS", "       MTB_fwd", "       MTB_getoffBACK", "       MTB_getoffLHS", "       MTB_getoffRHS", "       MTB_jumponL", "       MTB_jumponR", "       MTB_Left", "       MTB_pedal", "       MTB_pushes", "       MTB_Ride", "       MTB_Right", "       MTB_sprint", "       MTB_still", "       MscleWalkst_armed", "       MscleWalkst_Csaw", "       Mscle_rckt_run", "       Mscle_rckt_walkst", "       Mscle_run_Csaw", "       MuscleIdle", "       MuscleIdle_armed", "       MuscleIdle_Csaw", "       MuscleIdle_rocket", "       MuscleRun", "       MuscleRun_armed", "       MuscleSprint", "       MuscleWalk", "       MuscleWalkstart", "       MuscleWalk_armed", "       Musclewalk_Csaw", "       Musclewalk_rocket", "       NEVADA_getin", "       NEVADA_getout", "       lkaround_in", "       lkaround_loop", "       lkaround_out", "       lkup_in", "       lkup_loop", "       lkup_out", "       lkup_point", "       panic_cower", "       panic_hide", "       panic_in", "       panic_loop", "       panic_out", "       panic_point", "       panic_shout", "       Pointup_in", "       Pointup_loop", "       Pointup_out", "       Pointup_shout", "       point_in", "       point_loop", "       point_out", "       shout_01", "       shout_02", "       shout_in", "       shout_loop", "       shout_out", "       wave_in", "       wave_loop", "       wave_out", "       betslp_in", "       betslp_lkabt", "       betslp_loop", "       betslp_out", "       betslp_tnk", "       wtchrace_cmon", "       wtchrace_in", "       wtchrace_loop", "       wtchrace_lose", "       wtchrace_out", "       wtchrace_win", "       FALL_skyDive", "       FALL_SkyDive_Accel", "       FALL_skyDive_DIE", "       FALL_SkyDive_L", "       FALL_SkyDive_R", "       PARA_decel", "       PARA_decel_O", "       PARA_float", "       PARA_float_O", "       PARA_Land", "       PARA_Land_O", "       PARA_Land_Water", "       PARA_Land_Water_O", "       PARA_open", "       PARA_open_O", "       PARA_Rip_Land_O", "       PARA_Rip_Loop_O", "       PARA_Rip_O", "       PARA_steerL", "       PARA_steerL_O", "       PARA_steerR", "       PARA_steerR_O", "       Tai_Chi_in", "       Tai_Chi_Loop", "       Tai_Chi_Out", "       Piss_in", "       Piss_loop", "       Piss_out", "       PnM_Argue1_A", "       PnM_Argue1_B", "       PnM_Argue2_A", "       PnM_Argue2_B", "       PnM_Loop_A", "       PnM_Loop_B", "       wank_in", "       wank_loop", "       wank_out", "       abseil", "       ARRESTgun", "       ATM", "       BIKE_elbowL", "       BIKE_elbowR", "       BIKE_fallR", "       BIKE_fall_off", "       BIKE_pickupL", "       BIKE_pickupR", "       BIKE_pullupL", "       BIKE_pullupR", "       bomber", "       CAR_alignHI_LHS", "       CAR_alignHI_RHS", "       CAR_align_LHS", "       CAR_align_RHS", "       CAR_closedoorL_LHS", "       CAR_closedoorL_RHS", "       CAR_closedoor_LHS", "       CAR_closedoor_RHS", "       CAR_close_LHS", "       CAR_close_RHS", "       CAR_crawloutRHS", "       CAR_dead_LHS", "       CAR_dead_RHS", "       CAR_doorlocked_LHS", "       CAR_doorlocked_RHS", "       CAR_fallout_LHS", "       CAR_fallout_RHS", "       CAR_getinL_LHS", "       CAR_getinL_RHS", "       CAR_getin_LHS", "       CAR_getin_RHS", "       CAR_getoutL_LHS", "       CAR_getoutL_RHS", "       CAR_getout_LHS", "       CAR_getout_RHS", "       car_hookertalk", "       CAR_jackedLHS", "       CAR_jackedRHS", "       CAR_jumpin_LHS", "       CAR_LB", "       CAR_LB_pro", "       CAR_LB_weak", "       CAR_LjackedLHS", "       CAR_LjackedRHS", "       CAR_Lshuffle_RHS", "       CAR_Lsit", "       CAR_open_LHS", "       CAR_open_RHS", "       CAR_pulloutL_LHS", "       CAR_pulloutL_RHS", "       CAR_pullout_LHS", "       CAR_pullout_RHS", "       CAR_Qjacked", "       CAR_rolldoor", "       CAR_rolldoorLO", "       CAR_rollout_LHS", "       CAR_rollout_RHS", "       CAR_shuffle_RHS", "       CAR_sit", "       CAR_sitp", "       CAR_sitpLO", "       CAR_sit_pro", "       CAR_sit_weak", "       CAR_tune_radio", "       CLIMB_idle", "       CLIMB_jump", "       CLIMB_jump2fall", "       CLIMB_jump_B", "       CLIMB_Pull", "       CLIMB_Stand", "       CLIMB_Stand_finish", "       cower", "       Crouch_Roll_L", "       Crouch_Roll_R", "       DAM_armL_frmBK", "       DAM_armL_frmFT", "       DAM_armL_frmLT", "       DAM_armR_frmBK", "       DAM_armR_frmFT", "       DAM_armR_frmRT", "       DAM_LegL_frmBK", "       DAM_LegL_frmFT", "       DAM_LegL_frmLT", "       DAM_LegR_frmBK", "       DAM_LegR_frmFT", "       DAM_LegR_frmRT", "       DAM_stomach_frmBK", "       DAM_stomach_frmFT", "       DAM_stomach_frmLT", "       DAM_stomach_frmRT", "       DOOR_LHinge_O", "       DOOR_RHinge_O", "       DrivebyL_L", "       DrivebyL_R", "       Driveby_L", "       Driveby_R", "       DRIVE_BOAT", "       DRIVE_BOAT_back", "       DRIVE_BOAT_L", "       DRIVE_BOAT_R", "       Drive_L", "       Drive_LO_l", "       Drive_LO_R", "       Drive_L_pro", "       Drive_L_pro_slow", "       Drive_L_slow", "       Drive_L_weak", "       Drive_L_weak_slow", "       Drive_R", "       Drive_R_pro", "       Drive_R_pro_slow", "       Drive_R_slow", "       Drive_R_weak", "       Drive_R_weak_slow", "       Drive_truck", "       DRIVE_truck_back", "       DRIVE_truck_L", "       DRIVE_truck_R", "       Drown", "       DUCK_cower", "       endchat_01", "       endchat_02", "       endchat_03", "       EV_dive", "       EV_step", "       facanger", "       facgum", "       facsurp", "       facsurpm", "       factalk", "       facurios", "       FALL_back", "       FALL_collapse", "       FALL_fall", "       FALL_front", "       FALL_glide", "       FALL_land", "       FALL_skyDive", "       Fight2Idle", "       FightA_1", "       FightA_2", "       FightA_3", "       FightA_block", "       FightA_G", "       FightA_M", "       FIGHTIDLE", "       FightShB", "       FightShF", "       FightSh_BWD", "       FightSh_FWD", "       FightSh_Left", "       FightSh_Right", "       flee_lkaround_01", "       FLOOR_hit", "       FLOOR_hit_f", "       fucku", "       gang_gunstand", "       gas_cwr", "       getup", "       getup_front", "       gum_eat", "       GunCrouchBwd", "       GunCrouchFwd", "       GunMove_BWD", "       GunMove_FWD", "       GunMove_L", "       GunMove_R", "       Gun_2_IDLE", "       GUN_BUTT", "       GUN_BUTT_crouch", "       Gun_stand", "       handscower", "       handsup", "       HitA_1", "       HitA_2", "       HitA_3", "       HIT_back", "       HIT_behind", "       HIT_front", "       HIT_GUN_BUTT", "       HIT_L", "       HIT_R", "       HIT_walk", "       HIT_wall", "       Idlestance_fat", "       idlestance_old", "       IDLE_armed", "       IDLE_chat", "       IDLE_csaw", "       Idle_Gang1", "       IDLE_HBHB", "       IDLE_ROCKET", "       IDLE_stance", "       IDLE_taxi", "       IDLE_tired", "       Jetpack_Idle", "       JOG_femaleA", "       JOG_maleA", "       JUMP_glide", "       JUMP_land", "       JUMP_launch", "       JUMP_launch_R", "       KART_drive", "       KART_L", "       KART_LB", "       KART_R", "       KD_left", "       KD_right", "       KO_shot_face", "       KO_shot_front", "       KO_shot_stom", "       KO_skid_back", "       KO_skid_front", "       KO_spin_L", "       KO_spin_R", "       pass_Smoke_in_car", "       phone_in", "       phone_out", "       phone_talk", "       Player_Sneak", "       Player_Sneak_walkstart", "       roadcross", "       roadcross_female", "       roadcross_gang", "       roadcross_old", "       run_1armed", "       run_armed", "       run_civi", "       run_csaw", "       run_fat", "       run_fatold", "       run_gang1", "       run_left", "       run_old", "       run_player", "       run_right", "       run_rocket", "       Run_stop", "       Run_stopR", "       Run_Wuzi", "       SEAT_down", "       SEAT_idle", "       SEAT_up", "       SHOT_leftP", "       SHOT_partial", "       SHOT_partial_B", "       SHOT_rightP", "       Shove_Partial", "       Smoke_in_car", "       sprint_civi", "       sprint_panic", "       Sprint_Wuzi", "       swat_run", "       Swim_Tread", "       Tap_hand", "       Tap_handP", "       turn_180", "       Turn_L", "       Turn_R", "       WALK_armed", "       WALK_civi", "       WALK_csaw", "       Walk_DoorPartial", "       WALK_drunk", "       WALK_fat", "       WALK_fatold", "       WALK_gang1", "       WALK_gang2", "       WALK_old", "       WALK_player", "       WALK_rocket", "       WALK_shuffle", "       WALK_start", "       WALK_start_armed", "       WALK_start_csaw", "       WALK_start_rocket", "       Walk_Wuzi", "       WEAPON_crouch", "       woman_idlestance", "       woman_run", "       WOMAN_runbusy", "       WOMAN_runfatold", "       woman_runpanic", "       WOMAN_runsexy", "       WOMAN_walkbusy", "       WOMAN_walkfatold", "       WOMAN_walknorm", "       WOMAN_walkold", "       WOMAN_walkpro", "       WOMAN_walksexy", "       WOMAN_walkshop", "       XPRESSscratch", "       Plyr_DrivebyBwd", "       Plyr_DrivebyFwd", "       Plyr_DrivebyLHS", "       Plyr_DrivebyRHS", "       shift", "       shldr", "       stretch", "       strleg", "       time", "       CopTraf_Away", "       CopTraf_Come", "       CopTraf_Left", "       CopTraf_Stop", "       COP_getoutcar_LHS", "       Cop_move_FWD", "       crm_drgbst_01", "       Door_Kick", "       plc_drgbst_01", "       plc_drgbst_02", "       POOL_ChalkCue", "       POOL_Idle_Stance", "       POOL_Long_Shot", "       POOL_Long_Shot_O", "       POOL_Long_Start", "       POOL_Long_Start_O", "       POOL_Med_Shot", "       POOL_Med_Shot_O", "       POOL_Med_Start", "       POOL_Med_Start_O", "       POOL_Place_White", "       POOL_Short_Shot", "       POOL_Short_Shot_O", "       POOL_Short_Start", "       POOL_Short_Start_O", "       POOL_Walk", "       POOL_Walk_Start", "       POOL_XLong_Shot", "       POOL_XLong_Shot_O", "       POOL_XLong_Start", "       POOL_XLong_Start_O", "       WINWASH_Start", "       WINWASH_Wash2Beg", "       python_crouchfire", "       python_crouchreload", "       python_fire", "       python_fire_poor", "       python_reload", "       QUAD_back", "       QUAD_driveby_FT", "       QUAD_driveby_LHS", "       QUAD_driveby_RHS", "       QUAD_FWD", "       QUAD_getoff_B", "       QUAD_getoff_LHS", "       QUAD_getoff_RHS", "       QUAD_geton_LHS", "       QUAD_geton_RHS", "       QUAD_hit", "       QUAD_kick", "       QUAD_Left", "       QUAD_passenger", "       QUAD_reverse", "       QUAD_ride", "       QUAD_Right", "       Pass_Driveby_BWD", "       Pass_Driveby_FWD", "       Pass_Driveby_LHS", "       Pass_Driveby_RHS", "       Laugh_01", "       RAP_A_IN", "       RAP_A_Loop", "       RAP_A_OUT", "       RAP_B_IN", "       RAP_B_Loop", "       RAP_B_OUT", "       RAP_C_Loop", "       RIFLE_crouchfire", "       RIFLE_crouchload", "       RIFLE_fire", "       RIFLE_fire_poor", "       RIFLE_load", "       RIOT_ANGRY", "       RIOT_ANGRY_B", "       RIOT_challenge", "       RIOT_CHANT", "       RIOT_FUKU", "       RIOT_PUNCHES", "       RIOT_shout", "       CAT_Safe_End", "       CAT_Safe_Open", "       CAT_Safe_Open_O", "       CAT_Safe_Rob", "       SHP_HandsUp_Scr", "       idle_rocket", "       RocketFire", "       run_rocket", "       walk_rocket", "       WALK_start_rocket", "       Plane_align_LHS", "       Plane_close", "       Plane_getin", "       Plane_getout", "       Plane_open", "       RYD_Beckon_01", "       RYD_Beckon_02", "       RYD_Beckon_03", "       RYD_Die_PT1", "       RYD_Die_PT2", "       Van_Crate_L", "       Van_Crate_R", "       Van_Fall_L", "       Van_Fall_R", "       Van_Lean_L", "       Van_Lean_R", "       VAN_PickUp_E", "       VAN_PickUp_S", "       Van_Stand", "       Van_Stand_Crate", "       Van_Throw", "       scdldlp", "       scdlulp", "       scdrdlp", "       scdrulp", "       sclng_l", "       sclng_r", "       scmid_l", "       scmid_r", "       scshrtl", "       scshrtr", "       sc_ltor", "       sc_rtol", "       SHAMAL_align", "       SHAMAL_getin_LHS", "       SHAMAL_getout_LHS", "       SHAMAL_open", "       ROB_2Idle", "       ROB_Loop", "       ROB_Loop_Threat", "       ROB_Shifty", "       ROB_StickUp_In", "       SHP_Duck", "       SHP_Duck_Aim", "       SHP_Duck_Fire", "       SHP_Gun_Aim", "       SHP_Gun_Duck", "       SHP_Gun_Fire", "       SHP_Gun_Grab", "       SHP_Gun_Threat", "       SHP_HandsUp_Scr", "       SHP_Jump_Glide", "       SHP_Jump_Land", "       SHP_Jump_Launch", "       SHP_Rob_GiveCash", "       SHP_Rob_HandsUp", "       SHP_Rob_React", "       SHP_Serve_End", "       SHP_Serve_Idle", "       SHP_Serve_Loop", "       SHP_Serve_Start", "       Smoke_RYD", "       shotgun_crouchfire", "       shotgun_fire", "       shotgun_fire_poor", "       CrouchReload", "       SilenceCrouchfire", "       Silence_fire", "       Silence_reload", "       skate_idle", "       skate_run", "       skate_sprint", "       F_smklean_loop", "       M_smklean_loop", "       M_smkstnd_loop", "       M_smk_drag", "       M_smk_in", "       M_smk_loop", "       M_smk_out", "       M_smk_tap", "       WEAPON_sniper", "       spraycan_fire", "       spraycan_full", "       PLY_CASH", "       PUN_CASH", "       PUN_HOLLER", "       PUN_LOOP", "       strip_A", "       strip_B", "       strip_C", "       strip_D", "       strip_E", "       strip_F", "       strip_G", "       STR_A2B", "       STR_B2A", "       STR_B2C", "       STR_C1", "       STR_C2", "       STR_C2B", "       STR_Loop_A", "       STR_Loop_B", "       STR_Loop_C", "       batherdown", "       batherup", "       Lay_Bac_in", "       Lay_Bac_out", "       ParkSit_M_IdleA", "       ParkSit_M_IdleB", "       ParkSit_M_IdleC", "       ParkSit_M_in", "       ParkSit_M_out", "       ParkSit_W_idleA", "       ParkSit_W_idleB", "       ParkSit_W_idleC", "       ParkSit_W_in", "       ParkSit_W_out", "       SBATHE_F_LieB2Sit", "       SBATHE_F_Out", "       SitnWait_in_W", "       SitnWait_out_W", "       gnstwall_injurd", "       JMP_Wall1m_180", "       Rail_fall", "       Rail_fall_crawl", "       swt_breach_01", "       swt_breach_02", "       swt_breach_03", "       swt_go", "       swt_lkt", "       swt_sty", "       swt_vent_01", "       swt_vent_02", "       swt_vnt_sht_die", "       swt_vnt_sht_in", "       swt_vnt_sht_loop", "       swt_wllpk_L", "       swt_wllpk_L_back", "       swt_wllpk_R", "       swt_wllpk_R_back", "       swt_wllshoot_in_L", "       swt_wllshoot_in_R", "       swt_wllshoot_out_L", "       swt_wllshoot_out_R", "       ho_ass_slapped", "       LaFin_Player", "       LaFin_Sweet", "       plyr_hndshldr_01", "       sweet_ass_slap", "       sweet_hndshldr_01", "       Sweet_injuredloop", "       Swim_Breast", "       SWIM_crawl", "       Swim_Dive_Under", "       Swim_Glide", "       Swim_jumpout", "       Swim_Tread", "       Swim_Under", "       sword_1", "       sword_2", "       sword_3", "       sword_4", "       sword_block", "       Sword_Hit_1", "       Sword_Hit_2", "       Sword_Hit_3", "       sword_IDLE", "       sword_part", "       TANK_align_LHS", "       TANK_close_LHS", "       TANK_doorlocked", "       TANK_getin_LHS", "       TANK_getout_LHS", "       TANK_open_LHS", "       TAT_ArmL_In_O", "       TAT_ArmL_In_P", "       TAT_ArmL_In_T", "       TAT_ArmL_Out_O", "       TAT_ArmL_Out_P", "       TAT_ArmL_Out_T", "       TAT_ArmL_Pose_O", "       TAT_ArmL_Pose_P", "       TAT_ArmL_Pose_T", "       TAT_ArmR_In_O", "       TAT_ArmR_In_P", "       TAT_ArmR_In_T", "       TAT_ArmR_Out_O", "       TAT_ArmR_Out_P", "       TAT_ArmR_Out_T", "       TAT_ArmR_Pose_O", "       TAT_ArmR_Pose_P", "       TAT_ArmR_Pose_T", "       TAT_Back_In_O", "    "})
        Me.ListBox19.Location = New System.Drawing.Point(3, 19)
        Me.ListBox19.Name = "ListBox19"
        Me.ListBox19.Size = New System.Drawing.Size(764, 160)
        Me.ListBox19.TabIndex = 2
        '
        'ListBox20
        '
        Me.ListBox20.FormattingEnabled = True
        Me.ListBox20.Items.AddRange(New Object() {"       TEC_crouchfire", "       TEC_crouchreload", "       TEC_fire", "       TEC_reload       ", "       tran_gtup", "       tran_hng", "       tran_ouch", "       tran_stmb", "       TRUCK_ALIGN_LHS", "       TRUCK_ALIGN_RHS", "       TRUCK_closedoor_LHS", "       TRUCK_closedoor_RHS", "       TRUCK_close_LHS", "       TRUCK_close_RHS", "       TRUCK_getin_LHS", "       TRUCK_getin_RHS", "       TRUCK_getout_LHS", "       TRUCK_getout_RHS", "       TRUCK_jackedLHS", "       TRUCK_jackedRHS", "       TRUCK_open_LHS", "       TRUCK_open_RHS", "       TRUCK_pullout_LHS", "       TRUCK_pullout_RHS", "       TRUCK_Shuffle", "       UZI_crouchfire", "       UZI_crouchreload", "       UZI_fire", "       UZI_fire_poor", "       UZI_reload", "       VAN_close_back_LHS", "       VAN_close_back_RHS", "       VAN_getin_Back_LHS", "       VAN_getin_Back_RHS", "       VAN_getout_back_LHS", "       VAN_getout_back_RHS", "       VAN_open_back_LHS", "       VAN_open_back_RHS", "       VEND_Drink2_P", "       VEND_Drink_P", "       vend_eat1_P", "       VEND_Eat_P", "       VEND_Use", "       VEND_Use_pt2", "       CAR_jumpin_LHS", "       CAR_jumpin_RHS", "       vortex_getout_LHS", "       vortex_getout_RHS", "       WF_Back", "       WF_drivebyFT", "       WF_drivebyLHS", "       WF_drivebyRHS", "       WF_Fwd", "       WF_getoffBACK", "       WF_getoffLHS", "       WF_getoffRHS", "       WF_hit", "       WF_jumponL", "       WF_jumponR", "       WF_kick", "       WF_Left", "       WF_passenger", "       WF_pushes", "       WF_Ride", "       WF_Right", "       WF_Still       SHP_1H_Lift", "       SHP_1H_Lift_End", "       SHP_1H_Ret", "       SHP_1H_Ret_S", "       SHP_2H_Lift", "       SHP_2H_Lift_End", "       SHP_2H_Ret", "       SHP_2H_Ret_S", "       SHP_Ar_Lift", "       SHP_Ar_Lift_End", "       SHP_Ar_Ret", "       SHP_Ar_Ret_S", "       SHP_G_Lift_In", "       SHP_G_Lift_Out", "       SHP_Tray_In", "       SHP_Tray_Out", "       SHP_Tray_Pose", "       CS_Dead_Guy", "       CS_Plyr_pt1", "       CS_Plyr_pt2", "       CS_Wuzi_pt1", "       CS_Wuzi_pt2", "       Walkstart_Idle_01", "       Wuzi_follow", "       Wuzi_Greet_Plyr", "       Wuzi_Greet_Wuzi", "       Wuzi_grnd_chk", "       Wuzi_stand_loop", "       Wuzi_Walk"})
        Me.ListBox20.Location = New System.Drawing.Point(3, 179)
        Me.ListBox20.Name = "ListBox20"
        Me.ListBox20.Size = New System.Drawing.Size(764, 186)
        Me.ListBox20.TabIndex = 3
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.Label16)
        Me.TabPage8.Controls.Add(Me.Label15)
        Me.TabPage8.Controls.Add(Me.Label14)
        Me.TabPage8.Controls.Add(Me.Label13)
        Me.TabPage8.Controls.Add(Me.ListBox18)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(770, 373)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Explosions"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'ListBox18
        '
        Me.ListBox18.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ListBox18.FormattingEnabled = True
        Me.ListBox18.Items.AddRange(New Object() {"0" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Large", "1" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Normal", "2" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Large", "3" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Large", "4" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Normal", "5" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Normal", "6" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Very Large", "7" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Huge", "8" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Normal", "9" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Normal", "10" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Large", "11" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Small", "12" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Yes" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Very Small", "13" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "No" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "Large"})
        Me.ListBox18.Location = New System.Drawing.Point(3, 28)
        Me.ListBox18.Name = "ListBox18"
        Me.ListBox18.Size = New System.Drawing.Size(764, 342)
        Me.ListBox18.TabIndex = 1
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(3, 12)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(31, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Type"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(92, 12)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(37, 13)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "Visible"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(177, 12)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(55, 13)
        Me.Label15.TabIndex = 4
        Me.Label15.Text = "Does Split"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(291, 12)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(39, 13)
        Me.Label16.TabIndex = 5
        Me.Label16.Text = "Range"
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.ListBox5)
        Me.TabPage7.Controls.Add(Me.ListBox6)
        Me.TabPage7.Controls.Add(Me.ListBox7)
        Me.TabPage7.Controls.Add(Me.ListBox8)
        Me.TabPage7.Controls.Add(Me.ListBox9)
        Me.TabPage7.Controls.Add(Me.ListBox10)
        Me.TabPage7.Controls.Add(Me.ListBox11)
        Me.TabPage7.Controls.Add(Me.ListBox12)
        Me.TabPage7.Controls.Add(Me.ListBox13)
        Me.TabPage7.Controls.Add(Me.ListBox14)
        Me.TabPage7.Controls.Add(Me.ListBox15)
        Me.TabPage7.Controls.Add(Me.ListBox16)
        Me.TabPage7.Controls.Add(Me.ListBox17)
        Me.TabPage7.Controls.Add(Me.Button15)
        Me.TabPage7.Controls.Add(Me.Button14)
        Me.TabPage7.Controls.Add(Me.Button13)
        Me.TabPage7.Controls.Add(Me.Button12)
        Me.TabPage7.Controls.Add(Me.Button11)
        Me.TabPage7.Controls.Add(Me.Button10)
        Me.TabPage7.Controls.Add(Me.Button9)
        Me.TabPage7.Controls.Add(Me.Button8)
        Me.TabPage7.Controls.Add(Me.Button7)
        Me.TabPage7.Controls.Add(Me.Button6)
        Me.TabPage7.Controls.Add(Me.Button5)
        Me.TabPage7.Controls.Add(Me.Button4)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(770, 373)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Objects"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(8, 6)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 1
        Me.Button4.Text = "Weapons"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(89, 6)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 2
        Me.Button5.Text = "Car Parts"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(170, 6)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 3
        Me.Button6.Text = "Fun Stuff"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(251, 6)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 23)
        Me.Button7.TabIndex = 4
        Me.Button7.Text = "Barriers"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(332, 6)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(75, 23)
        Me.Button8.TabIndex = 5
        Me.Button8.Text = "Various"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(413, 6)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(75, 23)
        Me.Button9.TabIndex = 6
        Me.Button9.Text = "Misc"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(494, 6)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(75, 23)
        Me.Button10.TabIndex = 7
        Me.Button10.Text = "Misc 2"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(575, 6)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(75, 23)
        Me.Button11.TabIndex = 8
        Me.Button11.Text = "Misc 3"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(656, 6)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(75, 23)
        Me.Button12.TabIndex = 9
        Me.Button12.Text = "Misc 4"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(8, 35)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(75, 23)
        Me.Button13.TabIndex = 10
        Me.Button13.Text = "Misc 5"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(89, 35)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(75, 23)
        Me.Button14.TabIndex = 11
        Me.Button14.Text = "Misc 6"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(170, 35)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(75, 23)
        Me.Button15.TabIndex = 12
        Me.Button15.Text = "Common"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'ListBox17
        '
        Me.ListBox17.FormattingEnabled = True
        Me.ListBox17.Items.AddRange(New Object() {"4516 - roadblock", "4524 - big roadblock", "4527 - small roadblock", "1459 - breakable small roadblock - police swat thing", "1422 - unbreakable small roadblock", "13667 - monkey man!", "13666 - loop big", "13629 - tv screen", "1593 - stinger", "Pirate Ship from LV = 8493", "Staircase = 6976", "A Shark! = 1608", "The loop from interior stunt stadium = 13592", "9900 - big scyscraper SF", "1600-1609 - fishes", "1598 - ball xD", "9455 - very big land", "11490 - torrenos ranch", "3556 - small blue house", "3557 - small purple house", "3590 - small house", "3608 - big rich house", "3609 - big house", "3608 - big house", "3619 - villa", "3607 - villa", "1431=5 wood boxes", "1432=round table with 3 redchairs", "1433=bar table", "1427=road fold-out thing with light", "1378 - huge crane (port)", "1384 - top part of construction crane", "1383 - crane stand (the tower)", "3872 - floodlight beams", "1655 - jump", "14866 -bed", "3461 - torch (gives flames)", "3243 - teepee", "3279  - area51 tower", "1596 - satelite small", "1278 - stadium light", "1271 - crate", "2780 - smoke machine"})
        Me.ListBox17.Location = New System.Drawing.Point(8, 64)
        Me.ListBox17.Name = "ListBox17"
        Me.ListBox17.Size = New System.Drawing.Size(754, 303)
        Me.ListBox17.TabIndex = 25
        Me.ListBox17.Visible = False
        '
        'ListBox16
        '
        Me.ListBox16.FormattingEnabled = True
        Me.ListBox16.Items.AddRange(New Object() {"2589 - pig (dead)", "2581-2588 - porn stuff (7)", "2868 - candle", "2888 - minigun (fake)", "2886 - VERY old cellphone", "2890 - light ramp", "2781 - bank automat (spell, ATM?)", "2943 - bank automat (destroyed)", "3067 - bank automat (only frame, much destroyed)", "2791 - airport arrive and stuff", "2803-2806 - meat stuff (3)", "2824-2827 - books and paper (3)", "2828 - photos of people", "2892 - spike strip, short", "2899 - spike strip, long (x2)", "2895 - flowers (x2)", "2894 - collegeblock (open)", "2896 - chest", "2902 - coffe thing (small)", "2898 - green carpet (?)", "2903 - bag (wierd, it has an parachute on it)", "9219 - same bag (but without parachute)", "2966 - GPS (2967)", "2905-2908 - body parts (from the mower, the big one)", "2913 - gym stuff (also on 2915, 2916)", "2914 - green flag (capture da flag)", "2920 - stop bar (yellow and black)", "2956 - mini crane! (like cj)", "2958 - Kbeer (that brought the forest down)", "2960 - steel thing (about cj's lenght)", "2961&62 - fire button & text", "2992 - ring (perfect for weddin)", "2993 - green flag (like the 2914) (capture da flag)", "2994 - restaurant thing", "2995-3003 - pool balls (spell?)", "3004 - pool ball hitter (spell?)", "3017 - blue map (rolled)", "3111 - blue map (same,) (but un-rolled)", "3026 - parachute (blue, and laying on the side)", "3027 - weed (small one) (smoking)", "3028 - katana (standing)", "3030 - radio thingy (big)", "3031 - radio reciever", "3038 - christmas lights", "3044 - bigweed", "3053 - magnet (on the heli)", "3056 - horse shoe magnet (spell..)", "3070 - googles (nightvision maybe)", "3074 - big white wall", "3082 - military green thing (small)", "3085 - Wanted list part 1", "3086 - feather (small)", "3087 - Wanted list part 2", "3088 - Wanted list part 3", "3091 - ""line closed"" sign", "3092 - DEAD COPPER (!)", "3096 - repair pickup (!)", "3108 - parachute target (white)", "3110 - A taste of ---- -- come...", "3122 - wierd movement on katana (like the para anim)", "3126 - tattoo tool", "3129 - car door (burned?)", "3131 - parachute (opened up) (falling on ground)", "", "3068 - Stowaway part 1", "3069 - Stowaway part 2", "", "3399 - stair, normal"})
        Me.ListBox16.Location = New System.Drawing.Point(8, 64)
        Me.ListBox16.Name = "ListBox16"
        Me.ListBox16.Size = New System.Drawing.Size(756, 303)
        Me.ListBox16.TabIndex = 26
        Me.ListBox16.Visible = False
        '
        'ListBox15
        '
        Me.ListBox15.FormattingEnabled = True
        Me.ListBox15.Items.AddRange(New Object() {"1971 - kb_flykiller", "1972 - kb_cuntopdisp2", "2060 - CJ_SANDBAG", "2775 - CJ_AIRPRT_MON", "2790 - CJ_ARRIVE_BOARD", "2792 - CJ_AIR_D_1", "2793 - CJ_AIR_D_2", "2794 - CJ_AIR_D_3", "2795 - CJ_AIR_D_4", "2796 - CJ_AIR_D_6", "3265 - ""Will be shot"" sign", "3267 - roof", "3505 - Pinacle Tree", "3890 - lib_street09", "3891 - lib_street08", "3893 - lib_street05", "3894 - lib_street11", "3899 - lib_street04", "3900 - lib_street12", "3910 - trackshad05", "3914 - snowover02", "3919 - lib_main_bistrotop", "3920 - lib_veg3", "3921 - lib_counchs", "3942 - bistrobar", "3943 - mid_staircase", "3944 - bistro_blok", "3961 - Boxkitch", "3962 - lee_Plane07", "3963 - lee_Plane08", "3964 - lee_Plane09", "3965 - lee_Object11", "3967 - AIRPORT_int2", "3968 - AIRPORT_FRONT", "3969 - BAG_BELT2", "3970 - CJ_CUSTOM_BAR", "3971 - CJ_BAG_RECLAIM", "3972 - mon1", "3973 - CJ_BAG_DET", "4504 - cuntw_roadblockld", "4505 - cuntw_roadblock01ld", "4506 - cuntw_roadblock02ld", "4507 - cuntw_roadblock03ld", "4508 - cuntw_roadblock04ld", "4509 - cuntw_roadblock05ld", "4521 - CE_Flintwat01ld", "4522 - CE_Flintintld"})
        Me.ListBox15.Location = New System.Drawing.Point(8, 64)
        Me.ListBox15.Name = "ListBox15"
        Me.ListBox15.Size = New System.Drawing.Size(756, 303)
        Me.ListBox15.TabIndex = 27
        Me.ListBox15.Visible = False
        '
        'ListBox14
        '
        Me.ListBox14.FormattingEnabled = True
        Me.ListBox14.Items.AddRange(New Object() {"  1420 - ac roof unit", "  1421 - 2woodboxes with cardboard 1 on top", "  1422 - construction road-block", "  1423 - red and blue road-block", "  1424 - old metal roadblock", "  1425 - detour sign", "  1426 - bridge walkway", "  1427 - road fold-out thing with light", "  1428 - leaning ladder", "  1429 - ghetto wood tv", "  1430 - recycle-bin closed", "  1431 - 5 wood boxes", "  1432 - round table with 3 redchairs", "  1433 - bar table", "  1434 - single road barricade", "  1435 - single road barricade 2", "  1436 - bridge walkway 2", "  1437 - big leaning ladder", "  1438 - 8 boxes", "  1439 - open dumpster", "  1440 - 5 boxes with 2 trashbags", "  1441 - 5 boxes 1 open and a plank", "  1442 - ghetto unlit trash-can-fire", "  1443 - adult books and video sale sign", "  1444 - ferry sign", "  1445 - burger sign", "  1446 - green picket fence", "  1447 - ghetto chain fence with tin", "  1448 - little cardboard box thing", "  1449 - 2 little cardboardbox things leaning", "  1450 - 2 little cardboardbox things leaning with trashbag", "  1451 - chicken house", "  1452 - 3/4 an out-house", "  1453 - squeezed hay roll", "  1454 - hay roll", "  1455 - Drum/Icecream?", "  1456 - ghetto-fence", "  1457 - ghettodog-house", "  1458 - china cart", "  1459 - construction thing", "  1460 - ghetto-fence2", "  1461 - boat bumper thing", "  1462 - ghetto-wall", "  1463 - wood stack", "  1464 - bridge walkway", "  1465 - construction walkway", "  1466 - construction walkway 2", "  1467 - construction walkway left end", "  1468 - chain-fence", "  1469 - construction walkway-glass", "  1470 - porch corner", "  1471 - porch logn part", "  1472 - ghetto steps", "  1473 - ghetto ramp", "  1474 - ghetto ramp with legs", "  1475 - ghetto ramp with legs on left", "  1476 - ghetto 4th table thing", "  1477 - ghetto ramp with legs on right", "  1478 - mailbox-whitemetal", "  1479 - ghetto overhang", "  1480 - miniwedding thing", "  1481 - bbq grill", "  1482 - ghetto overhang 2", "  1483 - ghetto lowroof", "  1484 - R*beerbottle", "  1485 - BIGGWEED!", "  1486 - big beer", "  1487 - big beer 2", "  1488 - wall beer", "  1489 - NONE", "  1490 - frontyard ballas gangtag", "  1491 - 8sqr door", "  1492 - green door", "  1493 - red ghetto screendoor", "  1494 - blue old door", "  1495 - old blue chain door", "  1496 - blue old barred door", "  1497 - metal bolted door", "  1498 - cjs door", "  1499 - big bolted metal door", "  1500 - barber door", "  1501 - old screen", "  1502 - classic wood door", "  1503 - box with tin as jump", "  1504 - red 6sqr door", "  1505 - blue 6sqr door", "  1506 - white 6sqr door", "  1507 - yellow 6sqr door", "  1508 - wide metal double doors", "  1509 - big beer 3", "  1510 - big concrete/metal dog dish shape", "  1511 - wall beer 2", "  1512 - whiskey bottle", "  1513 - candy bar rack", "  1514 - cash register", "  1515 - lucky dragon triple poker machine", "  1516 - small card-table", "  1517 - sqr beer bottle", "  1518 - tv", "  1519 - construction walkway 3", "  1520 - sqrR*beer", "  1521 - avery construction walkway", "  1522 - store door", "  1523 - cluckin bell swinging door", "  1524 - frontyard ballas gangtag 2", "  1525 - frontyard ballas gangtag 3", "  1526 - sanfierro rifa gangtag", "  1527 - rollin heights ballas gangtag?", "  1528 - seville blvd families", "  1529 - temple drive ballas gangtag", "  1530 - los santos vagos", "  1531 - varrio~los~aztecas gangtag", "  1532 - 247 shopdoor", "  1533 - burger shot door", "  1534 - chunk of warehouse window", "  1535 - safe house door", "  1536 - old push door", "  1537 - tatto door", "  1538 - old unused door", "  1539 - freeway overhang sign", "  1540 - double lane freeway over hang sign", "  1541 - bar beer push thing", "  1542 - soda push dispenser", "  1543 - pissh beer bottle", "  1544 - revolver beer bottle", "  1545 - bar beer push thing 2", "  1546 - big gulp sprunk", "  1547 - pissh label", "  1548 - ice collecter thing for bar", "  1549 - trashcan/ashtray", "  1550 - sack of money from caligula's", "  1551 - big beer 4", "  1552 - weird part of warehouse open door/window", "  1553 - glass foggy window", "  1554 - concrete upside-down piramid", "  1555 - motel room door", "  1556 - yellow metal store-door", "  1557 - fancy door", "  1558 - forklift box", "  1559 - small yellow cone for person", "  1560 - 247 logo door", "  1561 - 247 logo door 2", "  1562 - plane chair no head", "  1563 - plane chair head part", "  1564 - NONE", "  1565 - plane light on ceiling", "  1566 - restraunt door", "  1567 - closet door", "  1568 - chinatown lamp-post", "  1569 - store door", "  1570 - chinatown stand", "  1571 - little metal stand", "  1572 - saveway airport shopping cart", "  1573 - GAMECRASH", "  1574 - full trash can", "  1575 - white sack of cocaine", "  1576 - brown sack of cocaine", "  1577 - yellow sack of cocaine", "  1578 - green sack of cocaine", "  1579 - blue sack of cocaine", "  1580 - red sack of cocaine", "  1581 - Millie's scancard / Chuff security Card: Officer P. Rowe", "  1582 - hot pizza-box", "  1583 - gta3 luigi", "  1584 - gta3 misty", "  1585 - gta3 asuka", "  1586 - ammunation target 2 things gone", "  1587 - metal sqr with two bars sticking out", "  1588 - vice-city ammunation part 1", "  1589 - vice-city ammunation part 2", "  1590 - vice-city ammunation part 3", "  1591 - vice-city ammunation part 4", "  1592 - vice-city ammunation part 5", "  1593 - tire spikes", "  1594 - chess/checkers table with 4 chairs", "  1595 - big satallite dish", "  1596 - small satallite dish", "  1597 - palm tree street planter", "  1598 - beach-ball", "  1599 - yellow fish with blue eyes", "  1600 - rainbow fish", "  1601 - group of rainbow fish", "  1602 - single jellyfish", "  1603 - red jellyfish", "  1604 - rainbow fish", "  1605 - group of yellow fish with blue eyes", "  1606 - group of rainbow fish 2", "  1607 - dolphin", "  1608 - shark", "  1609 - yellow turtle", "  1610 - concretes and castle looking thing", "  1611 - top of this^", "  1612 - sub-marine", "  1613 - role thing", "  1614 - blue sign thing", "  1615 - yellow sign thing", "  1616 - secruity camera", "  1617 - air conditioning-makessmoke", "  1618 - skinning wide airconditioning-makessmoke", "  1619 - wall box thing?", "  1620 - air vent grate", "  1663 - Single chair (SF Driving school chair)"})
        Me.ListBox14.Location = New System.Drawing.Point(8, 64)
        Me.ListBox14.Name = "ListBox14"
        Me.ListBox14.Size = New System.Drawing.Size(756, 303)
        Me.ListBox14.TabIndex = 28
        Me.ListBox14.Visible = False
        '
        'ListBox13
        '
        Me.ListBox13.FormattingEnabled = True
        Me.ListBox13.Items.AddRange(New Object() {"1210 - briefcase w/target circle", "1211 - fire hydrant", "1212 - money packet", "1213 - small octagonal cap ?", "1214 - octagonal concrete post", "1215 - octagonal concrete post with light", "1216 - public phone stand", "1217 - 50 gal drum (plain) with target circle", "1218 - 50 gal drum (toxic) with target circle", "1219 - wood pallet", "1220 - cardboard box (closed)", "1221 - cardboard box (closed)", "1222 - 50 gal drum with glowing coals", "1223 - single lightpost", "1224 - gray crate", "1225 - closed 50 gal drum (toxic)", "1226 - curved single highway lamppost", "1227 - locked green trash bin", "1228 - striped work horse", "1229 - bus stop/no parking/bus sched sign", "1230 - cardboard box (open)", "1231 - short straight double lamppost", "1232 - short straight single lamppost", "1233 - no parking sign", "1234 - phone here sign", "1235 - trash can frame ?", "1236 - big blue trash bin with flies", "1237 - orange & white warning barrel", "1238 - traffic cone", "1239 - info icon", "1240 - heart (health pickup)", "1241 - power pill", "1242 - armor", "1243 - big buoy", "1244 - gas pump", "1245 - slanted wooden ramp", "1246 - small disappearing triangle thingie ?   (looks like shrapnel)", "1247 - bribe", "1248 - gta3 sign", "1249 - mail box", "1250 - big home mail box", "1251 - long horizontal striped pole", "1252 - bomb from GTA3 that blew up the bridge from Portland to Staunton...Thanx t" & _
                        "o Allan", "1253 - Photo Op icon (not visible without camera)...Thanx to Allan", "1254 - skull", "1255 - wooden chaise lounge", "1256 - train station bench", "1257 - bus stop shed", "1258 - mail box", "1259 - huge billboard", "1260 - big billboard", "1261 - small billboard", "1262 - single traffic light", "1263 - dual traffic light", "1264 - larger plastic garbage bag with flies", "1265 - smaller plastic garbage bag with flies", "1266 - big billboard", "1267 - big billboard", "1268 - big highway billboard", "1269 - gray parking meter", "1270 - red parking meter", "1271 - wooden crate", "1272 - blue house icon", "1273 - green house icon", "1274 - money icon ($)", "1275 - blue t-shirt icon", "1276 - TIKI figure with target circle", "1277 - save disk icon", "1278 - tall stadium light", "1279 - wrapped drug bundle", "1280 - long wooden bench", "1281 - picnic table with red & white umbrella", "1282 - striped work horse with light", "1283 - over the street traffic lights", "1284 - over the street traffic lights", "1285 - yellow newspaper vending box", "1286 - white newspaper vending box", "1287 - black newspaper vending box", "1288 - orange newspaper vending box", "1289 - red newspaper vending box", "1290 - double parking lot lamp", "1291 - street mailbox", "1292 - special delivery pickup box", "1293 - red newspaper vending box", "1294 - single parking lot lamp", "1295 - tall single parking lot light", "1296 - tall single parking lot light", "1297 - short single parking lot light (off)", "1298 - short single parking lot light (on)", "1299 - group of 5 cardboard boxes", "1300 - outdoor concrete trashcan", "1301 - large concrete cap with handle", "1302 - generic soda machine", "1303 - boulder (medium)", "1304 - boulder (small)", "1305 - boulder (large)", "1306 - power transformers on utility poles", "1307 - tall utility pole with transformers", "1308 - small utility pole with transformers", "1309 - huge billboard", "1310 - parachute with leg straps", "1311 - over-the-street direction sign", "1312 - over-the-street direction sign", "1313 - 2 skulls icon", "1314 - 2 players icon", "1315 - over-the-street traffic light", "1316 - gray horizontal circle", "1317 - may be another type of checkpoint cylinder (texture missing?)", "1318 - white arrow pointing down", "1319 - parking lot ticket taking post", "1320 - side-road-on-right traffic sign", "1321 - side-road-on-left traffic sign", "1322 - curved-road-ahead traffic sign", "1323 - T-intersection traffic sign", "1324 - 4-way-intersection traffic sign", "1325 - big billboard", "", "Anything immediately below 1210 or above 1325 crashes my server when used with Ad" & _
                        "dStaticPickup..."})
        Me.ListBox13.Location = New System.Drawing.Point(8, 64)
        Me.ListBox13.Name = "ListBox13"
        Me.ListBox13.Size = New System.Drawing.Size(756, 303)
        Me.ListBox13.TabIndex = 29
        Me.ListBox13.Visible = False
        '
        'ListBox12
        '
        Me.ListBox12.FormattingEnabled = True
        Me.ListBox12.Items.AddRange(New Object() {"923 - Packing_carates2", "933 - CJ_CABLEROLL", "944 - Packing_carates04", "1338 - BinNt08_LA", "1372 - CJ_Dump2_LOW", "1415 - DYN_DUMPSTER"})
        Me.ListBox12.Location = New System.Drawing.Point(8, 64)
        Me.ListBox12.Name = "ListBox12"
        Me.ListBox12.Size = New System.Drawing.Size(756, 303)
        Me.ListBox12.TabIndex = 30
        Me.ListBox12.Visible = False
        '
        'ListBox11
        '
        Me.ListBox11.FormattingEnabled = True
        Me.ListBox11.Items.AddRange(New Object() {"384-393 - Clothes based Objects <---Crashes game", "394-397 - Something to do with hands", "301-319 - Cutscene Objects (Like CJ's Suitcase, ETC...) <---?Freeze Game? SAMP-Se" & _
                        "rver crashes?", "5269 - wall of boxes", "17019 - lots of containers (big object)", "1257 - bus stop", "1686 - Fuel distributor", "16776 - Peckers Feed And Seed Chicken", "3345 - Caravan by Abonanded Airport"})
        Me.ListBox11.Location = New System.Drawing.Point(8, 64)
        Me.ListBox11.Name = "ListBox11"
        Me.ListBox11.Size = New System.Drawing.Size(756, 303)
        Me.ListBox11.TabIndex = 31
        Me.ListBox11.Visible = False
        '
        'ListBox10
        '
        Me.ListBox10.FormattingEnabled = True
        Me.ListBox10.Items.AddRange(New Object() {" 3092 = Tied up dead cop", " 2803 = bag of meat", " 2589 = carcus on a hook", " 2590 = hook", " 2804 = Meat", " 2805 = Meat", " 2806 = Meat", " 16410 = grave stones", " 12961 = grave stones 2 (open grave)", " 12986 = well", " 2896 = coffin", " 2905 = leg", " 2906 = arm", " 2907 = torso", " 2908 = head", " 2976 = green gloop (2976 and 3082 are great for a Area 69 Capture the capsule mo" & _
                        "de or something)", " 3082 = ammo capsule", " 3007 = chopcop torso", " 3008 = chopcop right arm", " 3009 = chopcop left arm ", " 3010 = chop cop right leg", " 3011 = chop cop left leg", " 3012 = chop cop head", " 3028 = sword", " 3070 = goggles", " 3071 = dumb bell right", " 3072 = dumb bell left", " 2627 = treadmill", " 2628 = bench 2", " 2629 = bench 1", " 2630 = bike", " 3074 = painting", " 3077 = blackboard(3077,3086,3085,3078,and 3088 would be cool for a script based " & _
                        "on the movie ""60 seconds"")", " 3086 = cross off", " 3085 = 60 seconds list 1", " 3078 = 60 seconds list 2", " 3088 = 60 seconds list 3", " 3108 = base jump target", " 3113 = carrier door", " 3114 = carrier lift 2", " 3115 = carrier lift 1", " 2114 = basketball", " 1318 = Arrow", " 1317 = cylinder", " 1316 = hoop", " 1559 = diamond checkpoint thing"})
        Me.ListBox10.Location = New System.Drawing.Point(8, 64)
        Me.ListBox10.Name = "ListBox10"
        Me.ListBox10.Size = New System.Drawing.Size(756, 303)
        Me.ListBox10.TabIndex = 32
        Me.ListBox10.Visible = False
        '
        'ListBox9
        '
        Me.ListBox9.FormattingEnabled = True
        Me.ListBox9.Items.AddRange(New Object() {"1206 - vending machine <--- Use This = Crash", "1210 - briefcase", "1216 - phone booth", "1219 - palette", "1223 - lamppost", "1341 - ice cream cart", "1342 - noodle stand", "1378 - huge crane", "1384 - top part of construction crane", "1383 - crane stand ", "1543 - bottle of beer", "1562 - white jet seat", "1572 - airport trolley", "1608 - shark", "1609 - turtle", "1612 - submarine (from SF port, huge)", "1622 - security camera", "1684 - construction container", "7386 - heliport"})
        Me.ListBox9.Location = New System.Drawing.Point(8, 64)
        Me.ListBox9.Name = "ListBox9"
        Me.ListBox9.Size = New System.Drawing.Size(756, 303)
        Me.ListBox9.TabIndex = 33
        Me.ListBox9.Visible = False
        '
        'ListBox8
        '
        Me.ListBox8.FormattingEnabled = True
        Me.ListBox8.Items.AddRange(New Object() {"Everything between 966 and 998", "969 - electric fence", "981 - 5 road blocks in a row (from island-access blocking)"})
        Me.ListBox8.Location = New System.Drawing.Point(8, 64)
        Me.ListBox8.Name = "ListBox8"
        Me.ListBox8.Size = New System.Drawing.Size(756, 303)
        Me.ListBox8.TabIndex = 34
        Me.ListBox8.Visible = False
        '
        'ListBox7
        '
        Me.ListBox7.FormattingEnabled = True
        Me.ListBox7.Items.AddRange(New Object() {"2918 - Mine ( If You touch it you jump ALOT ! )  by cmg4life", "1433 - Table", "1484 - Beer Botlle", "1486 - Other Beer Bottle", "1518 - Television", "1655 - Ramp", "1765 - Chair", "1766 - Couch", "1211 - Fire Hydrant", "1209 - Vending Machine", "1227 - Save Disk", "1222 - Barrel (Non Explosive)", "1225 - Barrel (Shoot it to make it explode)", "1340 - Chili Dogs Stand", "2222 - Donuts", "2985 - Mounted Machine Gun", "2964 - Pool Table", "3279 - Area 51 lookout Tower", "3761 - Shelfs", "4563 - Sky Scraper", "8493 - Ship in Las Venturas", "9900 - Star tower (in SF) by blewert", "13592 - Loop the loop", "13594 - Ring (Fun to Jump through with Bike)", "5482-5512 - Roads!"})
        Me.ListBox7.Location = New System.Drawing.Point(8, 64)
        Me.ListBox7.Name = "ListBox7"
        Me.ListBox7.Size = New System.Drawing.Size(756, 303)
        Me.ListBox7.TabIndex = 35
        Me.ListBox7.Visible = False
        '
        'ListBox6
        '
        Me.ListBox6.FormattingEnabled = True
        Me.ListBox6.Items.AddRange(New Object() {"DO NOT USE!!! EVER!!!", "", "974 - Car Door", "975 - Car Bumper", "976 - Car Side Panel", "977 - Car Bonnet", "978 - Car Boot/Trunk", "979 - Car Wheel", "980 - Additional Bodyparts", "981 - More Additional Body Parts"})
        Me.ListBox6.Location = New System.Drawing.Point(8, 64)
        Me.ListBox6.Name = "ListBox6"
        Me.ListBox6.Size = New System.Drawing.Size(756, 303)
        Me.ListBox6.TabIndex = 36
        Me.ListBox6.Visible = False
        '
        'ListBox5
        '
        Me.ListBox5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ListBox5.FormattingEnabled = True
        Me.ListBox5.Items.AddRange(New Object() {"321 - Regular Dildo", "322 - White Dildo", "323 - Vibrator", "324 - Another Vibrator", "325 - Flowers", "326 - Cane", "327 - A box of some kind  <--- No Effect", "328 - A large box of some kind <--- No Effect", "329 - Removed/Non Existant. <--- DO NOT USE", "330 - CJ's Phone", "331 - Brass Knuckles", "332 - Old VC Screwdriver - Removed. <--- DO NOT USE", "333 - Golf Club", "334 - Police Truncheon/Night Stick", "335 - Combat Knife", "336 - Baseball Bat", "337 - Shovel", "338 - Pool Cue", "339 - Katana", "340 - Skateboard - Removed. <--- DO NOT USE", "341 - Chainsaw", "342 - Frag Grenade", "343 - Tear Gas Grenade", "344 - Molotov Cocktail", "345 - Vehicle Missile Launcher <--- Use with caution, very crash prone!", "346 - Colt 45 Pistol", "347 - Silenced Pistol", "348 - Desert Eagle", "349 - Regular Shotgun", "350 - Sawn-Off Shotgun", "351 - Combat Shotgun", "352 - Micro Uzi", "353 - MP5", "354 - Hydra Flare", "355 - AK47 Assault Rifle", "356 - M4 Assault Rifle", "357 - Country Rifle?", "358 - Sniper Rifle", "359 - Rocket Launcher", "360 - Heat Seeking Rocket Launcher", "361 - Flamethrower", "362 - Minigun", "363 - Satchel Charges", "364 - Detonator <---- Seemingly Useless.", "365 - Spray Paint Can", "366 - Fire Extinguisher", "367 - Camera", "368 - Night Vision Goggles", "369 - Infra-Red Goggles", "370 - Jet pack", "371 - Parachute", "372 - Tec-9", "373 - Armour model used in Ammunition (No Effect)"})
        Me.ListBox5.Location = New System.Drawing.Point(3, 67)
        Me.ListBox5.Name = "ListBox5"
        Me.ListBox5.Size = New System.Drawing.Size(764, 303)
        Me.ListBox5.TabIndex = 37
        Me.ListBox5.Visible = False
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.ListBox2)
        Me.TabPage6.Controls.Add(Me.ListBox3)
        Me.TabPage6.Controls.Add(Me.ListBox4)
        Me.TabPage6.Controls.Add(Me.Button3)
        Me.TabPage6.Controls.Add(Me.Button2)
        Me.TabPage6.Controls.Add(Me.Button1)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(770, 373)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Pickups"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 6)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(109, 35)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Pickup Models"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(123, 6)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 35)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Weapon Models"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(238, 6)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(109, 35)
        Me.Button3.TabIndex = 7
        Me.Button3.Text = "Pickup Types"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'ListBox4
        '
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.Items.AddRange(New Object() {"0 " & Global.Microsoft.VisualBasic.ChrW(9) & "Item does not display", "1" & Global.Microsoft.VisualBasic.ChrW(9) & "Not pickupable and no respawn.", "2 " & Global.Microsoft.VisualBasic.ChrW(9) & "Pickupable and respawns after a few minutes", "3 " & Global.Microsoft.VisualBasic.ChrW(9) & "Pickupable, no respawn", "4 " & Global.Microsoft.VisualBasic.ChrW(9) & "Disappears shortly after creation (used for drops?)", "5 " & Global.Microsoft.VisualBasic.ChrW(9) & "Disappears shortly after creation (used for drops?)", "8 " & Global.Microsoft.VisualBasic.ChrW(9) & "pickupable (no effect) - disappears shortly after creation (used for ?)", "9 " & Global.Microsoft.VisualBasic.ChrW(9) & "Blows up on pick up.(Only pickuppable in Vehicle, no respawn)", "10 " & Global.Microsoft.VisualBasic.ChrW(9) & "Blows up on pick up.(Only pickuppable in Vehicle, no respawn)", "11 " & Global.Microsoft.VisualBasic.ChrW(9) & "Blows Up few seconds of creation*", "12 " & Global.Microsoft.VisualBasic.ChrW(9) & "Blows Up few seconds of creation (car explosion? timer is the burning flame?)" & _
                        "", "13 " & Global.Microsoft.VisualBasic.ChrW(9) & "Slowly descends in Z and eventually goes through the floor (parachute?)X", "14 " & Global.Microsoft.VisualBasic.ChrW(9) & "Only pickupable when in Vehicle (used for bribes)", "15 " & Global.Microsoft.VisualBasic.ChrW(9) & "Pickupable, no respawn", "16-18 " & Global.Microsoft.VisualBasic.ChrW(9) & "Not pickupable", "19 " & Global.Microsoft.VisualBasic.ChrW(9) & "Pickupable with no effect (Information icon?)", "20,21 " & Global.Microsoft.VisualBasic.ChrW(9) & "Not pickupable", "22 " & Global.Microsoft.VisualBasic.ChrW(9) & "Pickupable, no respawn", "23      Pickupable, doesn't disappear on pickup", "24+ " & Global.Microsoft.VisualBasic.ChrW(9) & "Not pickupable"})
        Me.ListBox4.Location = New System.Drawing.Point(6, 49)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.Size = New System.Drawing.Size(758, 316)
        Me.ListBox4.TabIndex = 8
        Me.ListBox4.Visible = False
        '
        'ListBox3
        '
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.Items.AddRange(New Object() {"321 - Regular Dildo", "322 - White Dildo", "323 - Vibrator", "324 - Another Vibrator", "325 - Flowers", "326 - Cane", "330 - CJ's Phone", "331 - Brass Knuckles", "333 - Golf Club", "334 - Police Trungeon/Night Stick (Depending on where you're from)", "335 - Combat Knife", "336 - Baseball Bat", "337 - Shovel", "338 - Pool Cue", "339 - Katana", "341 - Chainsaw", "342 - Frag Grenade", "343 - Tear Gas Grenade", "344 - Molotov Cocktail", "346 - Colt 45 Pistol", "347 - Colt 45 Pistol (W/Silencer)", "348 - Desert Eagle", "349 - Regular Shotgun?", "350 - Sawn-Off Shotgun", "351 - SPAZ-12 Shotgun", "352 - Mac-10 (Or Micro-UZI)", "353 - MP5", "354 - Hydra Flare", "355 - AK47 Assault Rifle", "356 - M4 Assault Rifle", "357 - Country Rifle?", "358 - Sniper Rifle", "359 - Rocket Launcher", "360 - Heat Seeking Rocket Launcher", "361 - Flamethrower", "362 - Minigun", "363 - Satchel Charges", "364 - Detonator <---- Seemingly Useless.", "365 - Spray Paint Can", "366 - Fire Extinguisher", "367 - Camera", "368 - Night Vision Goggles", "369 - Infra-Red Goggles", "370 - Jet pack", "371 - Parachute", "372 - Tec-9"})
        Me.ListBox3.Location = New System.Drawing.Point(6, 49)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(758, 316)
        Me.ListBox3.TabIndex = 9
        Me.ListBox3.Visible = False
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Items.AddRange(New Object() {"1210 - briefcase w/target circle", "1211 - fire hydrant", "1212 - money packet", "1213 - small octagonal cap ?", "1214 - octagonal concrete post", "1215 - octagonal concrete post w/light", "1216 - public phone stand", "1217 - 50 gal drum (plain) w/target circle", "1218 - 50 gal drum (toxic) w/target circle", "1219 - wood pallet", "1220 - cardboard box (closed)", "1221 - cardboard box (closed)", "1222 - 50 gal drum w/glowing coals", "1223 - single lightpost", "1224 - gray crate", "1225 - closed 50 gal drum (toxic)", "1226 - curved single highway lamppost", "1227 - locked green trash bin", "1228 - striped work horse", "1229 - bus stop/no parking/bus sched sign", "1230 - cardboard box (open)", "1231 - short straight double lamppost", "1232 - short straight single lamppost", "1233 - no parking sign", "1234 - phone here sign", "1235 - trash can frame ?", "1236 - big blue trash bin w/flies", "1237 - orange & white warning barrel", "1238 - traffic cone", "1239 - info icon", "1240 - heart (health pickup)", "1241 - power pill", "1242 - armor", "1243 - big buoy", "1244 - gas pump", "1245 - slanted wooden ramp", "1246 - small disappearing triangle thingie ?   (looks like shrapnel)", "1247 - bribe", "1248 - gtaIII sign", "1249 - mail box", "1250 - big home mail box", "1251 - long horizontal striped pole", "1252 - bomb from GTA3 that blew up the bridge from Portland to Staunton...Thanx t" & _
                        "o Allan", "1253 - Photo Op icon (not visible without camera)...Thanx to Allan", "1254 - skull", "1255 - wooden chaise lounge", "1256 - train station bench", "1257 - bus stop shed", "1258 - mail box", "1259 - huge billboard", "1260 - big billboard", "1261 - small billboard", "1262 - single traffic light", "1263 - dual traffic light", "1264 - larger plastic garbage bag w/flies", "1265 - smaller plastic garbage bag w/flies", "1266 - big billboard", "1267 - big billboard", "1268 - big highway billboard", "1269 - gray parking meter", "1270 - red parking meter", "1271 - wooden crate", "1272 - blue house icon", "1273 - green house icon", "1274 - money icon ($)", "1275 - blue t-shirt icon", "1276 - TIKI figure w/target circle", "1277 - save disk icon", "1278 - tall stadium light", "1279 - wrapped drug bundle", "1280 - long wooden bench", "1281 - picnic table w/red & white umbrella", "1282 - striped work horse w/light", "1283 - over the street traffic lights", "1284 - over the street traffic lights", "1285 - yellow newspaper vending box", "1286 - white newspaper vending box", "1287 - black newspaper vending box", "1288 - orange newspaper vending box", "1289 - red newspaper vending box", "1290 - double parking lot lamp", "1291 - street mailbox", "1292 - special delivery pickup box", "1293 - red newspaper vending box", "1294 - single parking lot lamp", "1295 - tall single parking lot light", "1296 - tall single parking lot light", "1297 - short single parking lot light (off)", "1298 - short single parking lot light (on)", "1299 - group of 5 cardboard boxes", "1300 - outdoor concrete trashcan", "1301 - large concrete cap w/handle", "1302 - generic soda machine", "1303 - boulder (medium)", "1304 - boulder (small)", "1305 - boulder (large)", "1306 - power transformers on utility poles", "1307 - tall utility pole w/transformers", "1308 - small utility pole w/transformers", "1309 - huge billboard", "1310 - parachute with leg straps", "1311 - over-the-street direction sign", "1312 - over-the-street direction sign", "1313 - 2 skulls icon", "1314 - 2 players icon", "1315 - over-the-street traffic light", "1316 - gray horizontal circle", "1317 - may be another type of checkpoint cylinder (texture missing?)...Thanx to A" & _
                        "llan", "1318 - white arrow pointing down", "1319 - parking lot ticket taking post", "1320 - side-road-on-right traffic sign", "1321 - side-road-on-left traffic sign", "1322 - curved-road-ahead traffic sign", "1323 - T-intersection traffic sign", "1324 - 4-way-intersection traffic sign", "1325 - big billboard", "1559 - small enterable house icon (used for plane trips in airports in single pla" & _
                        "yer)Thanks to [LSB]TheGame"})
        Me.ListBox2.Location = New System.Drawing.Point(6, 49)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(756, 316)
        Me.ListBox2.TabIndex = 10
        Me.ListBox2.Visible = False
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.ListBox22)
        Me.TabPage5.Controls.Add(Me.Label18)
        Me.TabPage5.Controls.Add(Me.PictureBox2)
        Me.TabPage5.Controls.Add(Me.ComboBox1)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(770, 373)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "GameText"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Style 0", "Style 1", "Style 2", "Style 3", "Style 4", "Style 5", "Style 6"})
        Me.ComboBox1.Location = New System.Drawing.Point(354, 6)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 1
        Me.ComboBox1.Text = "Style 0"
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(202, 33)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(446, 282)
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(51, 14)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(91, 13)
        Me.Label18.TabIndex = 3
        Me.Label18.Text = "GameText Strings"
        '
        'ListBox22
        '
        Me.ListBox22.FormattingEnabled = True
        Me.ListBox22.Items.AddRange(New Object() {"~N~ - New line", "~R~ - Red", "~G~ - Green", "~B~ - Blue", "~W~ - White", "~Y~ - Yellow", "~P~ - Purple"})
        Me.ListBox22.Location = New System.Drawing.Point(37, 33)
        Me.ListBox22.Name = "ListBox22"
        Me.ListBox22.Size = New System.Drawing.Size(120, 95)
        Me.ListBox22.TabIndex = 4
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.PictureBox1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(770, 373)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Car Colors"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = Nothing
        Me.PictureBox1.Location = New System.Drawing.Point(174, 29)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(417, 316)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label12)
        Me.TabPage3.Controls.Add(Me.ListBox1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(770, 373)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Weather"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"    * 0 to 7 = different versions of blue skies/clouds", "    * 08 = stormy", "    * 09 = cloudy and foggy", "    * 10 = clear blue sky (falls into 0-7 category)", "    * 11 = scorching hot (Los Santos heat waves)", "    * 12 to 15 = very dull, colorless, hazy", "    * 16 = dull, cloudy, rainy", "    * 17 to 18 = scorching hot", "    * 19 = sandstorm", "    * 20 = foggy/greenish", "    * 21 = very dark, gradiented skyline, purple", "    * 22 = very dark, gradiented skyline, green", "    * 23 to 26 = variations of pale orange", "    * 27 to 29 = variations of fresh blue", "    * 30 to 32 = variations of dark, cloudy, teal", "    * 33 = dark, cloudy, brown", "    * 34 = blue/purple, regular", "    * 35 = dull brown", "    * 36 to 38 = bright, foggy, orange", "    * 39 = extremely bright", "    * 40 to 42 = blue/purple cloudy", "    * 43 = dark toxic clouds", "    * 44 = black/white sky", "    * 45 = black/purple sky "})
        Me.ListBox1.Location = New System.Drawing.Point(3, 28)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(764, 342)
        Me.ListBox1.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(339, 12)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(69, 13)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Weather ID's"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.SoundBox)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(770, 373)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Sounds"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(8, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(52, 16)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Sound"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(391, 9)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(23, 16)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "ID"
        '
        'SoundBox
        '
        Me.SoundBox.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.SoundBox.FormattingEnabled = True
        Me.SoundBox.Items.AddRange(New Object() {"SOUND_CEILING_VENT_LAND " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1002", "SOUND_BONNET_DENT " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1009", "SOUND_WHEEL_OF_FORTUNE_CLACKER " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1027", "SOUND_SHUTTER_DOOR_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1035", "SOUND_SHUTTER_DOOR_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1036", "SOUND_PARACHUTE_OPEN " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1039", "SOUND_AMMUNATION_BUY_WEAPON " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1052", "SOUND_AMMUNATION_BUY_WEAPON_DENIED " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1053", "SOUND_SHOP_BUY " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1054", "SOUND_SHOP_BUY_DENIED " & Global.Microsoft.VisualBasic.ChrW(9) & "                                " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1055", "SOUND_RACE_321 " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1056", "SOUND_RACE_GO " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1057", "SOUND_PART_MISSION_COMPLETE " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1058", "SOUND_GOGO_TRACK_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1062 (music)", "SOUND_GOGO_TRACK_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1063 (music)", "SOUND_DUAL_TRACK_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1068 (music)", "SOUND_DUAL_TRACK_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1069 (music)", "SOUND_BEE_TRACK_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1076 (music)", "SOUND_BEE_TRACK_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1077 (music)", "SOUND_ROULETTE_ADD_CASH " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1083", "SOUND_ROULETTE_REMOVE_CASH " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1084", "SOUND_ROULETTE_NO_CASH " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1085", "SOUND_AWARD_TRACK_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1097 (music)", "SOUND_AWARD_TRACK_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1098 (music)", "SOUND_PUNCH_PED " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1130", "SOUND_AMMUNATION_GUN_COLLISION " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1131", "SOUND_CAMERA_SHOT " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1132", "SOUND_BUY_CAR_MOD " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1133", "SOUND_BUY_CAR_RESPRAY " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1134", "SOUND_BASEBALL_BAT_HIT_PED " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1135", "SOUND_STAMP_PED " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1136", "SOUND_CHECKPOINT_AMBER " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1137", "SOUND_CHECKPOINT_GREEN " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1138", "SOUND_CHECKPOINT_RED " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1139", "SOUND_CAR_SMASH_CAR " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1140", "SOUND_CAR_SMASH_GATE " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1141", "SOUND_OTB_TRACK_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1142", "SOUND_OTB_TRACK_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1143", "SOUND_PED_HIT_WATER_SPLASH " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1144", "SOUND_RESTAURANT_TRAY_COLLISION " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1145", "SOUND_SWEETS_HORN " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1147", "SOUND_MAGNET_VEHICLE_COLLISION " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1148", "SOUND_PROPERTY_PURCHASED " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1149", "SOUND_PICKUP_STANDARD " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1150", "SOUND_GARAGE_DOOR_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1153", "SOUND_GARAGE_DOOR_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1154", "SOUND_PED_COLLAPSE " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1163", "SOUND_SHUTTER_DOOR_SLOW_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1165", "SOUND_SHUTTER_DOOR_SLOW_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1166", "SOUND_RESTAURANT_CJ_PUKE " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1169", "SOUND_DRIVING_AWARD_TRACK_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1183 (music)", "SOUND_DRIVING_AWARD_TRACK_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1184", "SOUND_BIKE_AWARD_TRACK_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1185 (music)", "SOUND_BIKE_AWARD_TRACK_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1186", "SOUND_PILOT_AWARD_TRACK_START " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1187 (music)", "SOUND_PILOT_AWARD_TRACK_STOP " & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "1188"})
        Me.SoundBox.Location = New System.Drawing.Point(3, 28)
        Me.SoundBox.Name = "SoundBox"
        Me.SoundBox.Size = New System.Drawing.Size(764, 342)
        Me.SoundBox.TabIndex = 4
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.PictureBox3)
        Me.TabPage1.Controls.Add(Me.Button35)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Helicopters)
        Me.TabPage1.Controls.Add(Me.TextBox2)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.BicycleBox)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Trailers)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.TrainBox)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.MonsterBox)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.CarBox)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.BoatBox)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.PlaneBox)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.BikesBox)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(770, 373)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Vehicles"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'BikesBox
        '
        Me.BikesBox.FormattingEnabled = True
        Me.BikesBox.Items.AddRange(New Object() {"NRG-500", "Faggio", "FCR-900", "PCJ-600", "Freeway", "BF-400", "Pizzaboy", "Wayfarer", "CopBike", "Sanchez", "Quad"})
        Me.BikesBox.Location = New System.Drawing.Point(3, 25)
        Me.BikesBox.Name = "BikesBox"
        Me.BikesBox.Size = New System.Drawing.Size(120, 160)
        Me.BikesBox.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Bikes"
        '
        'PlaneBox
        '
        Me.PlaneBox.FormattingEnabled = True
        Me.PlaneBox.Items.AddRange(New Object() {"Hydra", "Rustler", "Dodo", "Nevada", "Stuntplane", "Cropdust", "AT-400", "Andromeda", "Beagle", "Vortex", "RC Barron", "Skimmer", "Shamal"})
        Me.PlaneBox.Location = New System.Drawing.Point(129, 25)
        Me.PlaneBox.Name = "PlaneBox"
        Me.PlaneBox.Size = New System.Drawing.Size(120, 160)
        Me.PlaneBox.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(164, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Planes"
        '
        'BoatBox
        '
        Me.BoatBox.FormattingEnabled = True
        Me.BoatBox.Items.AddRange(New Object() {"CoastGuard", "Dinghy", "Jetmax", "Launch", "Marquis", "Predator", "Reefer", "Speeder", "Squalo", "Tropic"})
        Me.BoatBox.Location = New System.Drawing.Point(255, 25)
        Me.BoatBox.Name = "BoatBox"
        Me.BoatBox.Size = New System.Drawing.Size(120, 160)
        Me.BoatBox.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(294, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Boats"
        '
        'CarBox
        '
        Me.CarBox.FormattingEnabled = True
        Me.CarBox.Items.AddRange(New Object() {"Admiral", "Alpha", "Ambulan", "Baggage", "Bandito", "Banshee", "Barracks", "Benson", "Bfinject", "Blade", "Blistac", "Bloodra", "Bobcat", "Boxburg", "Boxville", "Bravura", "Broadway", "Buccanee", "Buffalo", "Bullet", "Burrito", "Bus", "Cabbie", "Caddy", "Cadrona", "Camper", "Cement", "Cheetah", "Clover", "Club", "Coach", "Combine", "Comet", "CopCarla", "CopCarru", "CopCarsf", "CopCarvg", "Cft30", "Cozer", "Elegant", "Elegy", "Emperor", "Enforcer", "Esperant", "Euros", "Fbiranch", "Fbitruck", "Feltze", "Firela", "Firetruck", "Flash", "Flatbed", "Forklift", "Fortune", "Glendale", "Glenshit", "Greenwoo", "Hermes", "Hotdog", "Hotknife", "Hotrina", "Hotrinb", "Hotring", "Huntley", "Hustler", "Infernus", "Intruder", "Jester", "Journey", "Kart", "Landstal", "Linerun", "Majestic", "Manana", "Merit", "Mesa", "Moonbeam", "Mowerr", "Mrwhoop", "Mule", "Nebula", "Newsvan", "Oceanic", "Packer", "Patriot", "Peren", "Petro", "Phoenix", "Picador", "Pony", "Premier", "Previon", "Primo", "Rancher", "Rcbandit", "Rccam", "Rctiger", "Rdtrain", "Regina", "Remingtn", "Rhino", "Rnchlure", "Romero", "Rumpo", "Sabre", "Sadler", "Sadlshit", "Sandking", "Savanna", "Securica", "Sentinel", "Slamvan", "Solair", "Stafford", "Stallion", "Stratum", "Stretch", "Sultan", "Sunrise", "Supergt", "Swatvan", "Sweeper", "Tahoma", "Tampa", "Taxi", "Topfun", "Tornado", "Towtruck", "Tractor", "Trash", "Tug", "Turismo", "Uranus", "Utility", "Vincent", "Virgo", "Voodoo", "Walton", "Washing", "Willard", "Windsor", "Yankee", "Yosemite", "Zr350"})
        Me.CarBox.Location = New System.Drawing.Point(381, 25)
        Me.CarBox.Name = "CarBox"
        Me.CarBox.Size = New System.Drawing.Size(120, 160)
        Me.CarBox.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(422, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Cars"
        '
        'MonsterBox
        '
        Me.MonsterBox.FormattingEnabled = True
        Me.MonsterBox.Items.AddRange(New Object() {"Dumper", "Duneride", "Monster", "MonsterA", "MonsterB"})
        Me.MonsterBox.Location = New System.Drawing.Point(507, 25)
        Me.MonsterBox.Name = "MonsterBox"
        Me.MonsterBox.Size = New System.Drawing.Size(120, 160)
        Me.MonsterBox.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(523, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Monster Trucks"
        '
        'TrainBox
        '
        Me.TrainBox.FormattingEnabled = True
        Me.TrainBox.Items.AddRange(New Object() {"Freibox", "Freiflat", "Freight", "Streak", "Streakc", "Tram"})
        Me.TrainBox.Location = New System.Drawing.Point(633, 25)
        Me.TrainBox.Name = "TrainBox"
        Me.TrainBox.Size = New System.Drawing.Size(120, 160)
        Me.TrainBox.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(671, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Trains"
        '
        'Trailers
        '
        Me.Trailers.FormattingEnabled = True
        Me.Trailers.Items.AddRange(New Object() {"Artict1", "Artict2", "Artict3", "Bagboxa", "Bagboxb", "Farmtr1", "Petrotr", "Tugstair", "Utiltr1"})
        Me.Trailers.Location = New System.Drawing.Point(3, 204)
        Me.Trailers.Name = "Trailers"
        Me.Trailers.Size = New System.Drawing.Size(120, 160)
        Me.Trailers.TabIndex = 14
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(33, 188)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Trailers"
        '
        'BicycleBox
        '
        Me.BicycleBox.FormattingEnabled = True
        Me.BicycleBox.Items.AddRange(New Object() {"Bike", "BMX", "Mountain Bike"})
        Me.BicycleBox.Location = New System.Drawing.Point(129, 204)
        Me.BicycleBox.Name = "BicycleBox"
        Me.BicycleBox.Size = New System.Drawing.Size(120, 160)
        Me.BicycleBox.TabIndex = 16
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(157, 188)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Bicycles"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(591, 239)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(162, 20)
        Me.TextBox1.TabIndex = 18
        Me.TextBox1.Text = "Vehicle Name"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(591, 265)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(162, 20)
        Me.TextBox2.TabIndex = 19
        Me.TextBox2.Text = "VehicleID"
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Helicopters
        '
        Me.Helicopters.FormattingEnabled = True
        Me.Helicopters.Items.AddRange(New Object() {"Cargobob" & Global.Microsoft.VisualBasic.ChrW(9), "Hunter", "Leviathn", "Maverick", "Polmav", "Raindanc", "Rcgoblin", "Rcraider", "Seasparr", "Sparrow", "Vcnmav"})
        Me.Helicopters.Location = New System.Drawing.Point(255, 204)
        Me.Helicopters.Name = "Helicopters"
        Me.Helicopters.Size = New System.Drawing.Size(120, 160)
        Me.Helicopters.TabIndex = 20
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(283, 188)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 13)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Helicopters"
        '
        'Button35
        '
        Me.Button35.Location = New System.Drawing.Point(633, 291)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(75, 23)
        Me.Button35.TabIndex = 22
        Me.Button35.Text = "Find"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.InitialImage = Nothing
        Me.PictureBox3.Location = New System.Drawing.Point(381, 204)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(204, 121)
        Me.PictureBox3.TabIndex = 23
        Me.PictureBox3.TabStop = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.Controls.Add(Me.TabPage11)
        Me.TabControl1.Controls.Add(Me.TabPage12)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(778, 399)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.Label19)
        Me.TabPage12.Controls.Add(Me.TextBox4)
        Me.TabPage12.Controls.Add(Me.Button19)
        Me.TabPage12.Controls.Add(Me.Button18)
        Me.TabPage12.Controls.Add(Me.Button17)
        Me.TabPage12.Controls.Add(Me.Button16)
        Me.TabPage12.Controls.Add(Me.WebBrowser1)
        Me.TabPage12.Location = New System.Drawing.Point(4, 22)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage12.Size = New System.Drawing.Size(770, 373)
        Me.TabPage12.TabIndex = 11
        Me.TabPage12.Text = "Download"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(-4, 6)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(794, 41)
        Me.WebBrowser1.TabIndex = 0
        Me.WebBrowser1.Url = New System.Uri("http://www.jatochnietdan.info", System.UriKind.Absolute)
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(8, 77)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(191, 76)
        Me.Button16.TabIndex = 1
        Me.Button16.Text = "Client Download"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(571, 77)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(191, 76)
        Me.Button17.TabIndex = 2
        Me.Button17.Text = "Windows Server Download"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(571, 159)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(191, 76)
        Me.Button18.TabIndex = 3
        Me.Button18.Text = "Linux Server Download(libstdc++5) "
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(571, 241)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(191, 76)
        Me.Button19.TabIndex = 4
        Me.Button19.Text = "Linux Server Download(libstdc++6) "
        Me.Button19.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Maiandra GD", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(269, 77)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(217, 96)
        Me.TextBox4.TabIndex = 5
        Me.TextBox4.Text = resources.GetString("TextBox4.Text")
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Porky's", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(59, 156)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(90, 17)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "Windows Only"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(778, 399)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "SA-MP Script King"
        Me.TabPage11.ResumeLayout(False)
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage12.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents ListBox21 As System.Windows.Forms.ListBox
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Callbacks As System.Windows.Forms.ListBox
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents ListBox20 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox19 As System.Windows.Forms.ListBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents ListBox18 As System.Windows.Forms.ListBox
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents ListBox5 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox6 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox7 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox8 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox9 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox10 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox11 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox12 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox13 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox14 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox15 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox16 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox17 As System.Windows.Forms.ListBox
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox4 As System.Windows.Forms.ListBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents ListBox22 As System.Windows.Forms.ListBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents SoundBox As System.Windows.Forms.ListBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Helicopters As System.Windows.Forms.ListBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents BicycleBox As System.Windows.Forms.ListBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Trailers As System.Windows.Forms.ListBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TrainBox As System.Windows.Forms.ListBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents MonsterBox As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CarBox As System.Windows.Forms.ListBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents BoatBox As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PlaneBox As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BikesBox As System.Windows.Forms.ListBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage12 As System.Windows.Forms.TabPage
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label

End Class
