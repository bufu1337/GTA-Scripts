﻿Public Class Form1
    Dim Ary() As String = {"522", "462", "521", "461", "463", "581", "448", "586", "523", "468", "471"}
    Dim Pictures() As String = {"http://www.crazyhost.info/images/518281GameText0.JPG", "http://www.crazyhost.info/images/441416GameText1.JPG", "http://www.crazyhost.info/images/293313GameText2.JPG", "http://www.crazyhost.info/images/911785GameText3.JPG", "http://www.crazyhost.info/images/157778GameText4.JPG", "http://www.crazyhost.info/images/540504GameText5.JPG", "http://www.crazyhost.info/images/193805GameText6.JPG"}
    Dim Pickup() As String = {"ListBox2", "ListBox3", "ListBox4"}
    Dim Ary2() As String = {"406", "573", "444", "556", "557"}
    Dim Ary3() As String = {"509", "481", "510"}
    Dim Ary4() As String = {"590", "569", "537", "538", "570", "449"}
    Dim Ary5() As String = {"435", "450", "591", "606", "607", "610", "584", "608", "611"}
    Dim Ary6() As String = {"520", "476", "593", "553", "513", "512", "577", "592", "511", "539", "464", "460", "519"}
    Dim Ary7() As String = {"472", "473", "493", "595", "484", "430", "453", "452", "446", "454"}
    Dim Ary8() As String = {"445", "602", "416", "485", "568", "429", "433", "499", "424", "536", "496", "504", "422", "609", "498", "401", "575", "518", "402", "541", "482", "431", "438", "457", "527", "483", "524", "415", "542", "589", "437", "532", "480", "596", "599", "597", "598", "578", "486", "507", "562", "585", "427", "419", "587", "490", "528", "533", "544", "407", "565", "455", "530", "526", "466", "604", "492", "474", "588", "434", "502", "503", "494", "579", "545", "411", "546", "559", "508", "571", "400", "403", "517", "410", "551", "500", "418", "572", "423", "414", "516", "582", "467", "443", "470", "404", "514", "603", "600", "413", "426", "436", "547", "489", "441", "594", "564", "515", "479", "534", "432", "505", "442", "440", "475", "543", "605", "495", "567", "428", "405", "535", "458", "580", "439", "561", "409", "560", "550", "506", "601", "574", "566", "549", "420", "459", "576", "525", "531", "408", "583", "451", "558", "552", "540", "491", "412", "578", "421", ",529", "555", "456", "554", "477"}
    Dim Ary9() As String = {"548", "425", "417", "487", "497", "563", "501", "465", "447", "469", "488"}
    Dim Calls() As String = {"public OnGameModeInit()", "public OnGameModeExit()", "public OnFilterScriptInit()", "public OnFilterScriptExit()", "public OnPlayerConnect(playerid)", "public OnPlayerDisconnect(playerid,reason)", "public OnPlayerSpawn(playerid)", "public OnPlayerDeath(playerid,killerid,reason)", "public OnVehicleSpawn(vehicleid)", "public OnVehicleDeath(vehicleid,killerid)", "public OnPlayerText(playerid,text[])", "public OnPlayerCommandText(playerid,cmdtext[])", "public OnPlayerInfoChange(playerid)", "public OnPlayerRequestClass(playerid,classid)", "public OnPlayerEnterVehicle(playerid,vehicleid)", "public OnPlayerExitVehicle(playerid,vehicleid)", "public OnPlayerStateChange(playerid,newstate,oldstate)", "public OnPlayerEnterCheckpoint(playerid)", "public OnPlayerLeaveCheckpoint(playerid)", "public OnPlayerEnterRaceCheckpoint(playerid)", "public OnPlayerLeaveRaceCheckpoint(playerid)", "public OnRconCommand(cmd[])", "public OnPlayerPrivmsg(playerid,recieverid,text[])", "public OnPlayerRequestSpawn(playerid)", "public OnObjectMoved(objectid)", "public OnPlayerObjectMoved(playerid,objectid)", "public OnPlayerPickUpPickup(playerid,pickupid)", "public OnVehiclePaintjob(vehicleid,paintjobid)", "public OnVehicleRespray(vehicleid,color1,color2)", "public OnVehicleMod(vehicleid,componentid)", "public OnPlayerSelectedMenuRow(playerid,row)", "public OnPlayerExitedMenu(playerid)", "public OnPlayerInteriorChange(playerid,newinteriorid,oldinteriorid)", "public OnPlayerKeyStateChange(playerid,newkeys,oldkeys)"}
    Private Sub BikesBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BikesBox.SelectedIndexChanged
        TextBox1.Text = BikesBox.SelectedItem()
        TextBox2.Text = Ary(BikesBox.SelectedIndex)
        PictureBox3.ImageLocation = "http://www.jatochnietdan.info/Vehicle_" + Ary(BikesBox.SelectedIndex) + ".jpg"
    End Sub

    Private Sub PlaneBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlaneBox.SelectedIndexChanged
        TextBox1.Text = PlaneBox.SelectedItem()
        TextBox2.Text = Ary6(PlaneBox.SelectedIndex)
        PictureBox3.ImageLocation = "http://www.jatochnietdan.info/Vehicle_" + Ary6(PlaneBox.SelectedIndex) + ".jpg"
    End Sub

    Private Sub BoatBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BoatBox.SelectedIndexChanged
        TextBox1.Text = BoatBox.SelectedItem()
        TextBox2.Text = Ary7(BoatBox.SelectedIndex)
        PictureBox3.ImageLocation = "http://www.jatochnietdan.info/Vehicle_" + Ary7(BoatBox.SelectedIndex) + ".jpg"
    End Sub

    Private Sub CarBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CarBox.SelectedIndexChanged
        TextBox1.Text = CarBox.SelectedItem()
        TextBox2.Text = Ary8(CarBox.SelectedIndex)
        PictureBox3.ImageLocation = "http://www.jatochnietdan.info/Vehicle_" + Ary8(CarBox.SelectedIndex) + ".jpg"
    End Sub

    Private Sub MonsterBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MonsterBox.SelectedIndexChanged
        TextBox1.Text = MonsterBox.SelectedItem()
        TextBox2.Text = Ary2(MonsterBox.SelectedIndex)
        PictureBox3.ImageLocation = "http://www.jatochnietdan.info/Vehicle_" + Ary2(MonsterBox.SelectedIndex) + ".jpg"
    End Sub

    Private Sub TrainBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrainBox.SelectedIndexChanged
        TextBox1.Text = TrainBox.SelectedItem()
        TextBox2.Text = Ary4(TrainBox.SelectedIndex)
        PictureBox3.ImageLocation = "http://www.jatochnietdan.info/Vehicle_" + Ary4(TrainBox.SelectedIndex) + ".jpg"
    End Sub

    Private Sub Trailers_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Trailers.SelectedIndexChanged
        TextBox1.Text = Trailers.SelectedItem()
        TextBox2.Text = Ary5(Trailers.SelectedIndex)
        PictureBox3.ImageLocation = "http://www.jatochnietdan.info/Vehicle_" + Ary5(Trailers.SelectedIndex) + ".jpg"
    End Sub

    Private Sub BicycleBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BicycleBox.SelectedIndexChanged
        TextBox1.Text = BicycleBox.SelectedItem()
        TextBox2.Text = Ary3(BicycleBox.SelectedIndex)
        PictureBox3.ImageLocation = "http://www.jatochnietdan.info/Vehicle_" + Ary3(BicycleBox.SelectedIndex) + ".jpg"
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        PictureBox2.ImageLocation = Pictures(ComboBox1.SelectedIndex)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ListBox3.Visible = True
        ListBox4.Visible = False
        ListBox2.Visible = False
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        ListBox3.Visible = False
        ListBox4.Visible = True
        ListBox2.Visible = False
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        ListBox5.Visible = True
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        ListBox5.Visible = False
        ListBox6.Visible = True
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = True
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = True
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = True
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = True
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = True
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = True
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = True
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = True
        ListBox15.Visible = False
        ListBox16.Visible = False
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = True
        ListBox16.Visible = False
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        ListBox5.Visible = False
        ListBox6.Visible = False
        ListBox7.Visible = False
        ListBox8.Visible = False
        ListBox9.Visible = False
        ListBox10.Visible = False
        ListBox11.Visible = False
        ListBox12.Visible = False
        ListBox13.Visible = False
        ListBox14.Visible = False
        ListBox15.Visible = False
        ListBox16.Visible = True
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ListBox3.Visible = False
        ListBox4.Visible = False
        ListBox2.Visible = True
    End Sub

    Private Sub Callbacks_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Callbacks.SelectedIndexChanged
        TextBox1.Text = Callbacks.SelectedItem()
        TextBox3.Text = Calls(Callbacks.SelectedIndex)
    End Sub

    Private Sub Helicopters_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Helicopters.SelectedIndexChanged
        TextBox1.Text = Helicopters.SelectedItem()
        TextBox2.Text = Ary9(Helicopters.SelectedIndex)
        PictureBox3.ImageLocation = "http://www.jatochnietdan.info/Vehicle_" + Ary9(Helicopters.SelectedIndex) + ".jpg"
    End Sub

    Private Sub Button35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button35.Click
        BikesBox.SelectedItem = TextBox1.Text
        PlaneBox.SelectedItem = TextBox1.Text
        Helicopters.SelectedItem = TextBox1.Text
        CarBox.SelectedItem = TextBox1.Text
        Trailers.SelectedItem = TextBox1.Text
        BicycleBox.SelectedItem = TextBox1.Text
        PlaneBox.SelectedItem = TextBox1.Text
        MonsterBox.SelectedItem = TextBox1.Text
        BoatBox.SelectedItem = TextBox1.Text
        TrainBox.SelectedItem = TextBox1.Text
    End Sub


    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        WebBrowser1.Navigate("www.jatochnietdan.info/SA-MP.exe")
    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        WebBrowser1.Navigate("www.jatochnietdan.info/SA-MPWindowsServer.zip")
    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        WebBrowser1.Navigate("www.jatochnietdan.info/SA-MPLinux++5.tar.gz")
    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click
        WebBrowser1.Navigate("www.jatochnietdan.info/SA-MPLinux++6.tar.gz")
    End Sub
End Class

