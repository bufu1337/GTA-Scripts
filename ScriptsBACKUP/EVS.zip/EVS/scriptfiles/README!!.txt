The "streamvehicles.v" file is epty, you can either use a text editor to open it and paste all your vehicles in
OR
Use the file generator provided (recommended for new scripters)