To use the file generator, just highlight all the "AddStaticVehicle"s and cut them out (CTRL+X)
then open the generator and click paste.

Everything will be in the textbox then click "Save Output File" then brouse to your servers scriptfilee and save it there.

IMPORTANT: If you wish to use a different file/extension than "streamvehicles.v" make sure you change it in the include.