Drift Points Counter .:OWNAGE EDITION:. by Abhinav

I took the Luby's "Drift points Counter" and Transformed it.
As a Result, I am releasing this FilterScript with new features added (BUGS FREE).

Features :
Need For Speed Underground like Drifting system and interface.
Bonus (Upto 5x)
Cash after Drift.
No Commands needed.
TextDraws used.
Drift points are Canceled when crashed. (Sometimes, little crashes are ignored)
Easy Tweaking/Customisation of code. (#defines - for Colors and TextDraw position)

Credits:
99% Luby - For such a awesome and methematical base script.
1% Abhinav(me) - Cool Transformation and new features.

Bonus System:
1x - Drift Points below 500
2x - Drift Points between 500 and 1000
3x - Drift Points between 1000 and 1700
4x - Drift Points between 1700 and 2500
5x - Drift Points 2500 and above

Cash :
Cash = Drift Points x Bonus

Bug Fixes:
No Drifting Points below 70 - REASON : Because it goes sometimes upto 70 when crashes a pole or a wall.
No Drifting Points above 10000 - REASON: If you teleport, sometimes it takes it as a drift and gives gives cash for it.

Bugs:
No known bugs.(YET) - (Tell me if you found any)

