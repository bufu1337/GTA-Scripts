                         _____               _ _
                        |  _  \             | | |
                        | | | |___  __ _  __| | |_   _
                        | | | / _ \/ _` |/ _` | | | | |
                        | |/ /  __/ (_| | (_| | | |_| |
                        |___/ \___|\__,_|\__,_|_|\__, |
                                                  __/ |
                                                 |___/
        _____                 _     _             _   _
       /  __ \               | |   (_)           | | (_)
       | /  \/ ___  _ __ ___ | |__  _ _ __   __ _| |_ _  ___  _ __  ___
       | |    / _ \| '_ ` _ \| '_ \| | '_ \ / _` | __| |/ _ \| '_ \/ __|
       | \__/\ (_) | | | | | | |_) | | | | | (_| | |_| | (_) | | | \__ \
        \____/\___/|_| |_| |_|_.__/|_|_| |_|\__,_|\__|_|\___/|_| |_|___/
                ___  _   _             _                        _
               / _ \| | | |           | |                      | |
              / /_\ \ |_| |_ __ _  ___| | __     __ _ _ __   __| |
              |  _  | __| __/ _` |/ __| |/ /    / _` | '_ \ / _` |
              | | | | |_| || (_| | (__|   <    | (_| | | | | (_| |
              \_| |_/\__|\__\__,_|\___|_|\_\    \__,_|_| |_|\__,_|


                        ______      __               _
                        |  _  \    / _|             | |
                        | | | |___| |_ ___ _ __   __| |
                        | | | / _ \  _/ _ \ '_ \ / _` |
                        | |/ /  __/ ||  __/ | | | (_| |
                        |___/ \___|_| \___|_| |_|\__,_|


------------------------------------------------------------------------------------

By Raekwon & Devastator


People who contributed for this gamemode: Killadel Rydaz, DracoBlue, mabako, Boylett, G-sTyLeZzZ, Rafs, ILuSioN

------------------------------------------------------------------------------------

A. Gamemode Use

	- Please do not mirror these files without permission.


B. DOCUMENTATION

	- All help and documentation files are located in the "documentation" folder.

D. Information

	- This gamemode comes as is with no warranty or gaurantee.
	- If you find a bug please report it.
	- Feel free to make suggestions and share ideas.