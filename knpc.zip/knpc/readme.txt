INSTALLATION:
1. Install JaTochNietDan's FileManager plugin - http://forum.sa-mp.com/showthread.php?t=92246
2. Copy knpc.amx into your filterscripts folder
3. Copy files from npcmodes in this archive to your npcmodes folder
4. Add knpc into 'filterscripts' line to your server.cfg

COMMANDS:
/knpc [ID 0-50] - start/stop recording npc (PLAYER_RECORDING_TYPE will depend on your current state (on foot/driver)
/knpclist -show list of currently connected NPC's
/kremove [ID 0-50] - remove NPC (or use '/kremove all' to remove all NPC's)
/knpchelp - show list of commands
/knicks - show nicknames above npc's