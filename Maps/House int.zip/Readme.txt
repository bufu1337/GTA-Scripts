_____________________________________________
www.fmodding.eu - allalaadimiste andmebaas

Mapi v�ljastamine ilma autori loata on keelatud!
Mapi originaal autor on Falenone
_____________________________________________

Map; House
Objekte; 283
T��p; Interj��r / Maja
Telepordi koordinaadid; 1881.2446289063,-1712.7084960938,1719.0504150391

Map on MTA formaadis ja seda saab ilma konvertimata MTAs avada (MTA versioon 1.0 - *)
MTA Race's avamiseks tuleb map ennem �mber konvertida.
