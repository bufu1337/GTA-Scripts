

                         EAZY PEEZY
			------------



-----------------------------------------------------------------------------------------

First of all. I will not take credit of this. The only thing I have done is
inlcude all the functions. That's it Thank You People for using this
Best Regards

-----------------------------------------------------------------------------------------



On the very top of your script, write this

#include <peezy>

Enjoy

Functions:
===========


CagePlayer(playerid)
UnCagePlayer(playerid)
SendClientMessageToAllEx(exception, color, const message[])
GetVehicleDriver(vehicleid)
Admin(msg[])
IsPlayerInInvalidNosVehicle(playerid,vehicleid)
CheckPlayerName(const name[])
IsABoat(carid)
RPName(name[],ret_first[],ret_last[])
GetVehicleName(modelid,name[],namesize)
GetObjectToPlayerDistance(playerid, objectid)
GetDistanceFromPlayerToVehicle(playerid, vehicleid)
GetVehiclePlayerID(vehicleid)
GetDistanceBetweenVehicles(vehicleid, vehicleid2)
GetDistanceBetweenPlayers(playerid, playerid2)
GetPlayerVehicleModel(playerid)
SafeKill(playerid)
RemovePlayerWeapon(playerid, weaponid)
GiveAllMoneyHealthArmour(money, Float:health, Float:armour)
GetVehicleName(modelid,name[],namesize)
GetUserIP(playerid)
IsAGirlFriendSkin(skinid)
IsAAztecaSkin(skinid)
IsAVagosSkin(skinid)
IsAGroveSkin(skinid)
IsABallasSkin(skinid)
IsAMeleeWeapon(weaponid)
ShowSubtitle(playerid, text[], time = 5000, override = 1)
HideSubtitle(playerid)
TeleportPlayerToPlayer(player, player2)



V2
----

RangeBan(playerid)
IsInFourDoor(playerid)
isdigit(c)
isspace(c)
GetCentury()
isprint(c)
CelsiusToFahrenheit(degrees)
FahrenheitToCelsius(degrees)
CelsiusToKelvin(degrees)
KelvinToCelsius(degrees)
GetPlayerFullname(partofname[])
SetVehicleSpeed(vehicleid, Float:Speed)
Teleport(playerid, Float:X, Float:Y, Float:Z)
CrashPlayer(playerid)
GetAveragePing()
ChangeTextDrawColorForAll(Text:txtid, color)
ChangeTextDrawColorForPlayer(playerid, Text:txtid, color)
CreateTextDrawForAll()
SetPlayerBlind(playerid,toggle)
DoesPlayerHaveAnyWeapon(playerid)
DoesPlayerHaveWeapon(playerid, weaponid, slot)
SetObjectFacePoint(objectid,Float:X,Float:Y)
SaveStringToFile(content[], filename[])
LineCount(filepath[])
GetXYInFrontOfPlayer(playerid, &Float:x, &Float:y, Float:distance)
sortWords(words[][], A_to_Z, size = sizeof(words))
IsPlayerOnFoot(playerid)
IsPlayerAlive(playerid)
IsPlayerSpawned()
SpawnVehicle(playerid, vehicleid, color1, color2)
TeleportVehicle(vehicleid, Float:x, Float:y, Float:z, Float:a, Int, World)
TeleportVehicleEx(vehicleid, Float:x, Float:y, Float:z, Int, World)
FileRename(fileorigem[],filerename[])
CreateQuadrateFromPos(Float:x,Float:y,Float:distance)

==========
